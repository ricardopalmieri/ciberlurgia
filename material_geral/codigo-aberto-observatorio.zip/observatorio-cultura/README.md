# Observatório da Cultura Municipal — Sarau na Quebrada (código aberto)

Cópia livre do código e das bases públicas do site https://sarau-na-quebrada.lovable.app.
Você pode baixar, estudar, alterar e reutilizar (licença MIT — veja `LICENSE`).

> **Importante:** baixar este pacote cria a SUA cópia. Alterar a cópia não muda o site
> publicado; editar o site oficial exige acesso de manutenção concedido pelo Sarau na Quebrada.
> Para sugerir mudanças no site oficial, veja `COMO-CONTRIBUIR.md`.

## O que tem aqui
- `src/` — páginas (`src/routes`), componentes e dados (`src/lib`).
- `dados/` — bases públicas em JSON/CSV exportadas de `src/lib` (listas vazias = ainda não verificado, nunca "zero").
- `tests/` e `src/test/` — testes.
- `scripts/gerar-pacote.mjs` — gera este ZIP de novo.
- `SHA256SUMS.txt` — conferência de integridade dos arquivos.

Não há banco de dados online: todos os dados ficam em arquivos dentro de `src/lib`.

## Instalar e rodar
1. Instale o [Bun](https://bun.sh) (ou Node.js 20+).
2. `bun install`
3. `bun run dev` e abra http://localhost:8080
4. Testes: `bunx vitest run`

## Editar
- Textos e telas: arquivos em `src/routes/` (ex.: `grande-abc.tsx`, `acervo.tsx`).
- Dados: `src/lib/*.ts`. Só cadastre registro com fonte oficial, link e data.
- Imagens e vídeos não vêm no pacote: coloque os seus em `public/` (ex.: `public/fusca-sarau.png`) ou troque as referências.

## Publicar a sua cópia
`bun run build` gera a versão final. Pode publicar em qualquer serviço compatível
com TanStack Start (ex.: Cloudflare), ou importar o código num projeto Lovable.
Use outro nome/endereço para não ser confundido com o site oficial.

## Gerar o ZIP de novo
`bun scripts/gerar-pacote.mjs` (precisa do comando `zip`).
