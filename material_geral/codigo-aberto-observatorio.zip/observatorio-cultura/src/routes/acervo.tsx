import { createFileRoute, Link } from "@tanstack/react-router";

// Vídeos já hospedados (não remover).
const VIDEO_EP1 = "/__l5e/assets-v1/f2892c45-59ab-4dca-a3b0-21b1304c67e0/episodio1-cultura-viva.mp4";
const VIDEO_EP2 = "/__l5e/assets-v1/1ff096f7-264c-4feb-82c4-798df0d1c7d1/episodio2-neri-piquena.mp4";

type Midia = { rotulo: string; video?: string; arquivoEsperado: string };
type Obra = { id: string; titulo: string; capa?: string; sinopse?: string; midias: Midia[] };
type Serie = { id: string; nome: string; apresentacao: string; obras: Obra[] };

// Para publicar um vídeo: preencha "video" com a URL do arquivo hospedado.
// Campos sem "video" aparecem como espaço reservado para anexar o MP4.
const SERIES: Serie[] = [
  {
    id: "potencia-de-antonio",
    nome: "A Potência de Antônio",
    apresentacao: "Série de animação inspirada no pensamento de Milton Santos.",
    obras: [
      { id: "antonio-autonomia", titulo: "Antônio — A Autonomia", midias: [{ rotulo: "Episódio completo", arquivoEsperado: "antonio-autonomia.mp4" }] },
      {
        id: "antonio-empoderamento",
        titulo: "Antônio — Empoderamento",
        midias: [
          { rotulo: "1º Trailer", arquivoEsperado: "antonio-empoderamento-trailer.mp4" },
          { rotulo: "2º Episódio completo", arquivoEsperado: "antonio-empoderamento.mp4" },
        ],
      },
    ],
  },
  {
    id: "neri-piquena-glaucia",
    nome: "Neri, Piquena e Gláucia / Cultura Viva",
    apresentacao: "As aventuras da turma atrás das políticas culturais do município.",
    obras: [
      { id: "cultura-viva-1", titulo: "Cultura Viva — Episódio 1", capa: "/fusca-sarau.png", midias: [{ rotulo: "Episódio completo", video: VIDEO_EP1, arquivoEsperado: "episodio1-cultura-viva.mp4" }] },
      { id: "neri-piquena-plano", titulo: "As aventuras de Neri e Piquena atrás do Plano Municipal de Cultura", capa: "/fusca-sarau.png", midias: [{ rotulo: "Episódio 1", video: VIDEO_EP1, arquivoEsperado: "episodio1-cultura-viva.mp4" }] },
      { id: "neri-piquena-conselho", titulo: "Neri e Piquena atrás do Conselho de Política Cultural", capa: "/fusca-sarau.png", midias: [{ rotulo: "Episódio 2", video: VIDEO_EP2, arquivoEsperado: "episodio2-neri-piquena.mp4" }] },
    ],
  },
];

export const Route = createFileRoute("/acervo")({
  head: () => ({
    meta: [
      { title: "Acervo Audiovisual — Sarau na Quebrada" },
      { name: "description", content: "Séries A Potência de Antônio e Neri, Piquena e Gláucia / Cultura Viva para assistir." },
      { property: "og:type", content: "website" },
      { property: "og:title", content: "Acervo Audiovisual — Sarau na Quebrada" },
      { property: "og:description", content: "Séries A Potência de Antônio e Neri, Piquena e Gláucia / Cultura Viva para assistir." },
      { property: "og:image", content: "https://sarau-na-quebrada.lovable.app/compartilhar-fusca.jpg" },
      { name: "twitter:image", content: "https://sarau-na-quebrada.lovable.app/compartilhar-fusca.jpg" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Acervo,
});

const AM = "#f2c230";
const btn = { display: "inline-block", background: AM, color: "#111313", padding: "10px 16px", borderRadius: 999, fontWeight: 700, textDecoration: "none" } as const;

function Player({ m, obra }: { m: Midia; obra: Obra }) {
  return (
    <div style={{ marginTop: 10 }}>
      <p style={{ margin: "0 0 6px", fontWeight: 700, color: AM, fontSize: 14 }}>▶ {m.rotulo}</p>
      {m.video ? (
        <video controls playsInline preload="metadata" poster={obra.capa} src={m.video}
          aria-label={`${m.rotulo}: ${obra.titulo}`}
          style={{ width: "100%", aspectRatio: "16/9", borderRadius: 10, background: "#000" }} />
      ) : (
        <div role="note" style={{ aspectRatio: "16/9", borderRadius: 10, border: `2px dashed ${AM}`, display: "grid", placeItems: "center", textAlign: "center", padding: 12 }}>
          <div>
            <div style={{ fontSize: 28 }}>🎬</div>
            <strong>Vídeo pendente — ainda não enviado</strong>
            <div style={{ fontSize: 13, opacity: 0.8, marginTop: 4 }}>Arquivo aguardado: {m.arquivoEsperado}</div>
          </div>
        </div>
      )}
    </div>
  );
}

function Acervo() {
  return (
    <main style={{ minHeight: "100vh", background: "#111313", color: "#f4efe6", fontFamily: "system-ui, sans-serif", padding: "24px 16px 60px" }}>
      <div style={{ maxWidth: 1100, margin: "0 auto" }}>
        <div style={{ display: "flex", gap: 16, flexWrap: "wrap" }}>
          <Link to="/" style={{ color: AM, textDecoration: "none" }}>← Voltar ao Observatório</Link>
          <Link to="/agenda" style={{ color: AM, textDecoration: "none" }}>📅 Agenda Cultural</Link>
        </div>
        <p style={{ letterSpacing: 3, color: AM, marginTop: 20, fontSize: 13 }}>SARAU NA QUEBRADA</p>
        <h1 style={{ fontSize: "clamp(28px, 6vw, 40px)", margin: "4px 0 20px" }}>Acervo Audiovisual</h1>
        <nav aria-label="Séries" style={{ display: "flex", flexWrap: "wrap", gap: 8, marginBottom: 24 }}>
          {SERIES.map((s) => <a key={s.id} href={`#${s.id}`} style={btn}>{s.nome}</a>)}
        </nav>
        {SERIES.map((s) => (
          <section key={s.id} id={s.id} aria-labelledby={`${s.id}-t`} style={{ marginBottom: 36 }}>
            <h2 id={`${s.id}-t`} style={{ fontSize: 26, margin: "0 0 4px" }}>{s.nome}</h2>
            <p style={{ margin: "0 0 14px", opacity: 0.85 }}>{s.apresentacao}</p>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(min(100%, 300px), 1fr))", gap: 16 }}>
              {s.obras.map((o) => (
                <article key={o.id} style={{ background: "#1d2020", border: `2px solid ${AM}`, borderRadius: 14, padding: 18 }}>
                  <h3 style={{ fontSize: 19, margin: 0 }}>{o.titulo}</h3>
                  {o.sinopse && <p style={{ opacity: 0.85 }}>{o.sinopse}</p>}
                  {o.midias.map((m) => <Player key={m.rotulo} m={m} obra={o} />)}
                </article>
              ))}
            </div>
          </section>
        ))}
      </div>
    </main>
  );
}
