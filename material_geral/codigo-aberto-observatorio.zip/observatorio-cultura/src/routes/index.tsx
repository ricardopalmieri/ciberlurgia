import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect } from "react";
import ep1 from "../assets/episodio1.asset.json";
import ep2 from "../assets/episodio2.asset.json";
import "../sarau.css";

const EP1_URL = ep1.url;
const EP2_URL = ep2.url;

const BODY_HTML = "<div id=\"observatory\" hidden inert><header><img class=\"brand-logo\" src=\"/sarau-na-quebrada.png\" alt=\"Sarau na Quebrada \u2014 Periferia organizada\"><strong>Observat\u00f3rio da Cultura Municipal</strong><div class=\"car-scene\"><img class=\"car-art\" src=\"/fusca-sarau.png\" alt=\"Fusca do Sarau na Quebrada\"><div class=\"smoke\" aria-hidden=\"true\"><i></i><i></i><i></i></div></div><span>CONTROLE SOCIAL \u00b7 VERS\u00c3O INICIAL</span></header><main><div class=\"live-controls\"><button type=\"button\" class=\"episode-two\">\u25b6 S\u00e9rie Neri e Piquena</button><button id=\"back-door\" class=\"secondary\" type=\"button\">Voltar ao Fusca</button><button id=\"install\" type=\"button\">Instalar aplicativo</button><button id=\"share\" class=\"secondary\" type=\"button\">Compartilhar</button><button id=\"motor\" type=\"button\" aria-pressed=\"false\">Ligar som do Fusca</button><button id=\"motion\" class=\"secondary\" type=\"button\" aria-pressed=\"false\">Pausar anima\u00e7\u00e3o</button><button id=\"register\" type=\"button\">Cadastro \u00danico da Cultura</button></div><h1>Como est\u00e1 a cultura no seu munic\u00edpio?</h1><p class=\"intro\">Consulte a estrutura de acompanhamento e veja quais documentos s\u00e3o necess\u00e1rios para verificar compromissos, recursos e participa\u00e7\u00e3o.</p><form class=\"search\" id=\"search\"><div class=\"field\"><label for=\"city\">2. Digite ou escolha a cidade</label><input id=\"city\" list=\"city-options\" autocomplete=\"off\" value=\"Santo Andr\u00e9\" required maxlength=\"100\" placeholder=\"Ex.: Santo Andr\u00e9\"><datalist id=\"city-options\"></datalist></div><div class=\"field uf\"><label for=\"uf\">1. Escolha o estado</label><select id=\"uf\" required></select></div><button type=\"submit\">Ver ficha da cidade</button></form><div class=\"quick-cities\"><span class=\"small\">Escolha r\u00e1pida</span><div id=\"city-chips\" class=\"chips\"></div><p class=\"small\">Sugest\u00f5es iniciais. Voc\u00ea tamb\u00e9m pode digitar qualquer munic\u00edpio do Brasil.</p></div><p id=\"error\" role=\"alert\"></p><div class=\"notice\"><strong>Base em constru\u00e7\u00e3o.</strong> Esta vers\u00e3o organiza a fiscaliza\u00e7\u00e3o, mas ainda n\u00e3o consulta bases oficiais automaticamente. As fichas est\u00e3o sem dados apurados. Aus\u00eancia de informa\u00e7\u00e3o aqui n\u00e3o significa aus\u00eancia de pol\u00edtica no munic\u00edpio.</div><div class=\"heading\"><div><h2 id=\"municipality\">Santo Andr\u00e9 \u00b7 SP</h2><p class=\"small\">Ficha inicial \u00b7 Nenhum documento verificado</p></div><button class=\"secondary\" id=\"print\">Imprimir ficha</button><button class=\"secondary\" id=\"download\">Baixar ficha</button></div><p id=\"feedback\" role=\"status\" class=\"small\"></p><section class=\"panel\"><h3>Legisla\u00e7\u00e3o municipal</h3><p>Pesquise leis do sistema, conselho, plano e fundo da cidade selecionada. Os links abrem uma busca externa, n\u00e3o uma base de leis j\u00e1 conferidas.</p><div class=\"links\" id=\"laws\"></div></section><section class=\"panel\"><h3>Visitas e curtidas</h3><p id=\"visits\" class=\"small\"></p><button id=\"like\" type=\"button\" aria-pressed=\"false\">Curtir esta ferramenta</button><p id=\"likes\" class=\"small\" role=\"status\"></p><p class=\"small\">Nesta etapa, estes registros ficam apenas neste navegador. Ainda n\u00e3o h\u00e1 contador p\u00fablico de todos os visitantes.</p></section><div class=\"grid\" id=\"cards\" style=\"margin-top:24px\"></div><section class=\"panel\" id=\"detail\" aria-live=\"polite\"></section><div class=\"method\"><section class=\"panel\"><h3>Como uma informa\u00e7\u00e3o ser\u00e1 confirmada</h3><p>Cada registro dever\u00e1 ter fonte p\u00fablica, documento, per\u00edodo de refer\u00eancia e data de verifica\u00e7\u00e3o. Exist\u00eancia em lei e funcionamento ser\u00e3o avaliados separadamente.</p><p><strong>Previsto em lei:</strong> h\u00e1 documento que cria a pol\u00edtica.<br><strong>Funcionamento comprovado:</strong> h\u00e1 evid\u00eancia de atividade no per\u00edodo.<br><strong>Pendente de verifica\u00e7\u00e3o:</strong> ainda faltam documentos.<br><strong>Informa\u00e7\u00e3o desatualizada:</strong> a evid\u00eancia precisa ser renovada.</p></section><section class=\"panel\"><h3>Uma ficha para cada meta do plano</h3><p>O acompanhamento ter\u00e1 compromisso, indicador, prazo, respons\u00e1vel, or\u00e7amento previsto, valor executado e resultado documentado.</p><p>Antes de classificar uma meta como cumprida ou atrasada, ser\u00e1 necess\u00e1rio conferir seu prazo e as evid\u00eancias. Propostas da sociedade civil tamb\u00e9m dever\u00e3o ter devolutiva registrada.</p></section></div><footer>As marca\u00e7\u00f5es do roteiro servem apenas para organizar sua confer\u00eancia nesta sess\u00e3o. Elas n\u00e3o comprovam a situa\u00e7\u00e3o do munic\u00edpio e n\u00e3o s\u00e3o enviadas a uma base p\u00fablica.</footer></main></div><dialog id=\"install-help\"><h2>Instalar Sarau Cultura</h2><p id=\"install-instructions\">No Android, abra este link no Chrome e use o menu \u22ee \u2192 Instalar aplicativo ou Adicionar \u00e0 tela inicial. No iPhone, abra no Safari e use Compartilhar \u2192 Adicionar \u00e0 Tela de In\u00edcio.</p><p>O aplicativo mostra a mesma ferramenta e usa o \u00edcone do Fusquinha. As buscas externas precisam de internet.</p><button id=\"close-install\" type=\"button\">Fechar</button></dialog><dialog id=\"registration\"><h2>Cadastro \u00danico da Cultura</h2><p>Proposta de cadastro comunit\u00e1rio do Observat\u00f3rio. N\u00e3o substitui cadastros oficiais e n\u00e3o garante acesso a benef\u00edcios ou editais.</p><p><strong>Google Forms ainda n\u00e3o conectado.</strong> A cria\u00e7\u00e3o aguarda acesso \u00e0 conta Google respons\u00e1vel. Nenhum dado ser\u00e1 coletado nesta tela.</p><h3>Campos propostos</h3><ul><li>Nome ou nome art\u00edstico</li><li>Munic\u00edpio e estado</li><li>Bairro ou territ\u00f3rio de atua\u00e7\u00e3o</li><li>\u00c1rea cultural e descri\u00e7\u00e3o da atua\u00e7\u00e3o</li><li>Agente cultural, coletivo, espa\u00e7o ou Ponto de Cultura</li><li>Contato opcional para retorno</li><li>Interesse em participar de f\u00f3runs e acompanhar pol\u00edticas culturais</li></ul><p>Antes da coleta, o formul\u00e1rio dever\u00e1 informar quem administra os dados, sua finalidade e como solicitar corre\u00e7\u00e3o ou exclus\u00e3o. Contatos n\u00e3o devem aparecer na consulta p\u00fablica.</p><button id=\"close-registration\" type=\"button\">Fechar</button></dialog><dialog id=\"episode-two-dialog\" aria-labelledby=\"episode-two-heading\"><h2 id=\"episode-two-heading\">Epis\u00f3dio 2 \u2014 Neri e Piquena atr\u00e1s do Conselho de Pol\u00edtica Cultural</h2><video id=\"episode-two-video\" controls playsinline preload=\"none\"><source src=\"__EP2__\" type=\"video/mp4\">Seu navegador n\u00e3o conseguiu abrir o v\u00eddeo.</video><button type=\"button\" id=\"episode-two-close\">Fechar v\u00eddeo</button></dialog><dialog id=\"series-dialog\" aria-labelledby=\"series-title\" style=\"width:min(92vw,520px);border-radius:14px;border:1px solid #a9c8cf;padding:22px\"><h2 id=\"series-title\">S\u00e9rie Neri e Piquena</h2><p>As aventuras de Neri e Piquena no Sarau na Quebrada.</p><button id=\"watch-episode-one\" type=\"button\" style=\"font-size:14px;width:100%;text-align:left;margin-bottom:10px\">\u25b6 Epis\u00f3dio 1 \u2014 Atr\u00e1s do Plano Municipal de Cultura</button><button id=\"watch-episode-two\" type=\"button\" style=\"font-size:14px;width:100%;text-align:left\">\u25b6 Epis\u00f3dio 2 \u2014 Atr\u00e1s do Conselho de Pol\u00edtica Cultural</button><button id=\"close-series\" class=\"secondary\" type=\"button\" style=\"margin-top:12px;font-size:14px\">Fechar</button></dialog>";

const INLINE_JS = "(function(){const epDialog=document.getElementById('episode-two-dialog'),epVideo=document.getElementById('episode-two-video');document.querySelectorAll('.episode-two').forEach(b=>b.addEventListener('click',()=>{document.getElementById(\"series-dialog\").showModal();}));document.getElementById('episode-two-close').addEventListener('click',()=>epDialog.close());epDialog.addEventListener('close',()=>epVideo.pause());\nfunction watchSeriesEpisode(number){epVideo.pause();document.getElementById('episode-two-heading').textContent=number===1?'Epis\u00f3dio 1 \u2014 As aventuras de Neri e Piquena atr\u00e1s do Plano Municipal de Cultura':'Epis\u00f3dio 2 \u2014 Neri e Piquena atr\u00e1s do Conselho de Pol\u00edtica Cultural';epVideo.querySelector('source').src=number===1?EP1_URL:EP2_URL;epVideo.load();document.getElementById('series-dialog').close();epDialog.showModal();}document.getElementById('watch-episode-one').onclick=()=>watchSeriesEpisode(1);document.getElementById('watch-episode-two').onclick=()=>watchSeriesEpisode(2);document.getElementById('close-series').onclick=()=>document.getElementById('series-dialog').close();})();";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Sarau na Quebrada — Observatório da Cultura" },
      {
        name: "description",
        content:
          "Acompanhe plano, fundo, conselho, orçamento e participação social na cultura do seu município.",
      },
      { name: "theme-color", content: "#111313" },
      { property: "og:type", content: "website" },
      { property: "og:title", content: "Sarau na Quebrada" },
      {
        property: "og:description",
        content:
          "Cultura, memória e participação — periferia organizada!",
      },
      { property: "og:url", content: "https://sarau-na-quebrada.lovable.app/" },
      {
        property: "og:image",
        content: "https://sarau-na-quebrada.lovable.app/compartilhar-fusca.jpg",
      },
      { property: "og:image:width", content: "1200" },
      { property: "og:image:height", content: "630" },
      {
        name: "twitter:image",
        content: "https://sarau-na-quebrada.lovable.app/compartilhar-fusca.jpg",
      },


      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: "Sarau na Quebrada — Observatório da Cultura" },
      {
        name: "twitter:description",
        content: "Acompanhe políticas culturais e participação no seu município.",
      },
    ],
    links: [
      { rel: "icon", href: "/icon-192.png" },
      { rel: "apple-touch-icon", href: "/icon-192.png" },
      { rel: "manifest", href: "/manifest.webmanifest" },
      { rel: "canonical", href: "https://sarau-na-quebrada.lovable.app/" },
    ],

  }),
  component: ObservatorioPage,
});

function ObservatorioPage() {
  useEffect(() => {
    document.body.classList.add("at-door");

    const win = window as unknown as { EP1_URL: string; EP2_URL: string };
    win.EP1_URL = EP1_URL;
    win.EP2_URL = EP2_URL;

    const appScript = document.createElement("script");
    appScript.src = "/app.js";
    appScript.defer = true;
    document.body.appendChild(appScript);

    const inlineScript = document.createElement("script");
    inlineScript.textContent = INLINE_JS;
    document.body.appendChild(inlineScript);

    if ("serviceWorker" in navigator) {
      navigator.serviceWorker.register("/sw.js").catch(() => {});
    }

    return () => {
      document.body.classList.remove("at-door");
      appScript.remove();
      inlineScript.remove();
    };
  }, []);

  return (
    <>
      <section id="entrance" aria-label="Entrada do Sarau na Quebrada">
        <div className="entry-title">
          <p className="entry-eyebrow">SARAU NA QUEBRADA</p>
          <h1>Observatório da Cultura Municipal</h1>
          <p className="entry-lead">A cultura tem lugar. Entre nessa roda.</p>
        </div>

        <div className="entry-car">
          <img
            src="/fusca-sarau.png"
            alt="Fusca do Sarau na Quebrada. Toque na porta para entrar no Observatório."
          />
          <div className="door-pointer" aria-hidden="true">
            <svg viewBox="0 0 48 64" width="48" height="64">
              <path
                d="M24 4v43M8 33l16 19 16-19"
                fill="none"
                stroke="currentColor"
                strokeWidth="8"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          </div>
          <button
            id="car-door"
            type="button"
            aria-label="Entrar no Observatório pela porta do Fusca"
          ></button>
          <div className="smoke" aria-hidden="true">
            <i></i>
            <i></i>
            <i></i>
          </div>
        </div>

        <nav className="entry-main" aria-label="Seções principais">
          <Link to="/acervo" className="entry-btn">
            Arquivo
          </Link>
          <Link to="/marco-regulatorio" className="entry-btn entry-btn-wide">
            Marco Regulatório e Democracia Cultural
          </Link>
        </nav>

        <div className="entry-secondary">
          <button id="enter-site" type="button">
            Entrar no Observatório
          </button>
          <button type="button" className="episode-two">
            ▶ Série Neri e Piquena
          </button>
          <Link to="/codigo-aberto" className="entry-text-link">
            Código aberto
          </Link>
          <Link to="/agenda" className="entry-text-link">
            📅 Agenda
          </Link>
          <Link to="/grande-abc" className="entry-text-link">
            🏙️ Grande ABC
          </Link>
        </div>

        <p className="entry-hint">Plano · Fundo · Conselho · Participação</p>
      </section>

      <div id="sarau-root" dangerouslySetInnerHTML={{ __html: BODY_HTML }} />
    </>
  );
}
