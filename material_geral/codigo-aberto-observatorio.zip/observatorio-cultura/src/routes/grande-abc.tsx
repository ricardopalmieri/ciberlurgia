import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { ResultadosPNAB } from "@/components/ResultadosPNAB";
import { CIDADES_ABC, ETAPAS, corDa, fichasDa, totalPrevisto, moedaABC, type CidadeABC, type Ficha, type Cor } from "@/lib/abc";

export const Route = createFileRoute("/grande-abc")({
  head: () => ({
    meta: [
      { title: "Observatório da Cultura — Grande ABC | Sarau na Quebrada" },
      { name: "description", content: "Acompanhe a cultura nas sete cidades do Grande ABC: decisões, plano, dinheiro e resultados, só com documento oficial." },
      { property: "og:title", content: "Observatório da Cultura — Grande ABC" },
      { property: "og:description", content: "Rastreie o dinheiro da cultura no Grande ABC, da participação ao resultado." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: GrandeABC,
});

type Aba = "cidade" | "bairro" | "decisoes" | "plano" | "dinheiro" | "projetos" | "como" | "pnab";
const ABAS: { id: Aba; nome: string }[] = [
  { id: "cidade", nome: "Escolha sua cidade" }, { id: "bairro", nome: "Meu bairro" }, { id: "decisoes", nome: "Decisões públicas" },
  { id: "plano", nome: "Plano de Cultura" }, { id: "dinheiro", nome: "Dinheiro da cultura" }, { id: "projetos", nome: "Projetos e Resultados" },
  { id: "como", nome: "Como funciona" },
  { id: "pnab", nome: "Resultados PNAB" },
];
const COR: Record<Cor, { bg: string; txt: string }> = {
  verde: { bg: "#d9f2dd", txt: "Documentado" }, amarelo: { bg: "#fff3b0", txt: "Parcial" }, vermelho: { bg: "#ffd9d6", txt: "Sem documentação" },
};
const box = { border: "2px solid #111", borderRadius: 12, padding: 14, margin: "12px 0", background: "#fff" } as const;
const campo = { background: "#fff", color: "#111", border: "2px solid #111", borderRadius: 10, padding: "10px", fontSize: 16, width: "100%" } as const;
const ND = <strong>N/D</strong>;

function Selo({ c }: { c: Cor }) {
  return <span style={{ background: COR[c].bg, border: "2px solid #111", borderRadius: 999, padding: "2px 10px", fontSize: 13, fontWeight: 800 }}>{COR[c].txt}</span>;
}

function FichaCard({ f }: { f: Ficha }) {
  const c = corDa(f);
  return (
    <article style={box} aria-labelledby={`f-${f.id}`}>
      <h3 id={`f-${f.id}`} style={{ margin: "0 0 6px", fontSize: 18 }}>{f.titulo}</h3>
      <p style={{ margin: "0 0 8px", fontSize: 14 }}>{f.cidade} · Bairro: {f.bairro ?? ND} · <Selo c={c} /></p>
      <ol style={{ paddingLeft: 20, margin: 0, fontSize: 15 }}>
        {ETAPAS.map((e) => {
          const v = f.valores[e.id as keyof Ficha["valores"]];
          const t = f.etapas[e.id];
          return <li key={e.id} style={{ padding: "4px 0", borderBottom: "1px solid #ddd" }}>
            <strong>{e.nome}:</strong> {v != null ? moedaABC(v) : null}{v != null && t ? " — " : ""}{t ?? (v == null ? ND : null)}
            {e.id === "previsto" && v != null && <em> (previsto ≠ pago)</em>}
          </li>;
        })}
      </ol>
      <p style={{ margin: "8px 0 0", fontSize: 14 }}><strong>Fonte documental:</strong> <a href={f.link} target="_blank" rel="noopener noreferrer" style={{ color: "#111", fontWeight: 700 }}>{f.fonte} ↗</a> · {f.data}</p>
    </article>
  );
}

function Vazio({ children }: { children: React.ReactNode }) {
  return <p role="status" style={{ ...box, borderStyle: "dashed", fontSize: 15 }}>{children}</p>;
}

function GrandeABC() {
  const [aba, setAba] = useState<Aba>("cidade");
  const [cidade, setCidade] = useState<CidadeABC | "">("");
  const [bairro, setBairro] = useState("");
  const [busca, setBusca] = useState<{ c: CidadeABC | ""; b: string } | null>(null);
  const res = busca ? fichasDa(busca.c, busca.b) : [];
  const nomeCidade = cidade || "nenhuma cidade escolhida";
  const fichasCidade = cidade ? fichasDa(cidade) : [];

  return (
    <main className="mr abc-pnab-theme" style={{ background: "#fff", color: "#111", minHeight: "100vh", padding: "16px", maxWidth: 980, margin: "0 auto", fontFamily: "system-ui, sans-serif" }}>
      <nav aria-label="Atalhos" style={{ display: "flex", gap: 12, flexWrap: "wrap", fontSize: 14, marginBottom: 8 }}>
        <Link to="/" style={{ color: "#111" }}>← Início</Link>
        <Link to="/marco-regulatorio" style={{ color: "#111" }}>Marco Regulatório e Democracia Cultural</Link>
        <Link to="/acervo" style={{ color: "#111" }}>Arquivo</Link>
        <Link to="/codigo-aberto" style={{ color: "#111" }}>Código aberto · Baixar código-fonte e bases (ZIP)</Link>
      </nav>
      <h1 style={{ fontSize: "clamp(24px, 5vw, 36px)", margin: "4px 0" }}>Observatório da Cultura — Grande ABC</h1>
      <p style={{ margin: "0 0 12px", fontSize: 16 }}>Modelo popular a partir de Santo André. Só mostramos o que tem documento oficial; o resto aparece como <strong>N/D</strong> (não disponível).</p>

      <div className="my-4 border-y-2 border-foreground py-4 space-y-2">
        <Button type="button" className="pnab-control w-full text-base font-bold" onClick={() => {
          setAba("pnab");
          requestAnimationFrame(() => document.getElementById("pnab-titulo")?.focus());
        }}>Resultados PNAB Santo André — 2026</Button>
        <p className="text-sm">12 editais anunciados · 160 vagas PREVISTAS. Listas nominais ainda não conferidas documentalmente pelo Observatório.</p>
      </div>

      <div role="tablist" aria-label="Seções" style={{ display: "grid", gap: 8, gridTemplateColumns: "repeat(auto-fit, minmax(min(100%, 150px), 1fr))" }}>
        {ABAS.map((a) => (
          <Button key={a.id} id={`abc-aba-${a.id}`} role="tab" type="button" tabIndex={aba === a.id ? 0 : -1} aria-selected={aba === a.id} aria-controls="abc-painel" onClick={() => setAba(a.id)}
            onKeyDown={(event) => {
              const index = ABAS.findIndex((item) => item.id === a.id);
              const next = event.key === "Home" ? 0 : event.key === "End" ? ABAS.length - 1 : event.key === "ArrowRight" ? (index + 1) % ABAS.length : event.key === "ArrowLeft" ? (index + ABAS.length - 1) % ABAS.length : null;
              if (next === null) return;
              event.preventDefault();
              const target = ABAS[next];
              if (!target) return;
              setAba(target.id);
              document.getElementById(`abc-aba-${target.id}`)?.focus();
            }}
            className="h-auto whitespace-normal"
            style={{ minHeight: 48, padding: "10px 12px", borderRadius: 10, border: "2px solid #111", fontWeight: 800, fontSize: 15, background: aba === a.id ? "#111" : "#fff", color: aba === a.id ? "#fff" : "#111", cursor: "pointer", boxShadow: "none" }}>
            {a.nome}
          </Button>
        ))}
      </div>

      <section hidden={aba === "pnab"} style={{ ...box, display: aba === "pnab" ? "none" : "grid", gap: 10, gridTemplateColumns: "repeat(auto-fit, minmax(min(100%, 220px), 1fr))", alignItems: "end" }} aria-label="Pesquisa">
        <label style={{ fontWeight: 700 }}>Cidade
          <select value={cidade} onChange={(e) => { setCidade(e.target.value as CidadeABC | ""); setBusca(null); }} style={campo}>
            <option value="">Escolha sua cidade</option>
            {CIDADES_ABC.map((c) => <option key={c} value={c}>{c}</option>)}
          </select></label>
        <label style={{ fontWeight: 700 }}>Bairro (opcional)
          <input value={bairro} onChange={(e) => setBairro(e.target.value)} placeholder="Ex.: nome do seu bairro" style={campo} /></label>
        <Button type="button" className="h-auto" onClick={() => { setBusca({ c: cidade, b: bairro }); setAba(bairro ? "bairro" : "projetos"); }}
          style={{ minHeight: 48, borderRadius: 10, border: "2px solid #111", background: "#111", color: "#fff", fontWeight: 800, fontSize: 16, boxShadow: "none" }}>🔍 Pesquisar</Button>
      </section>

      <p style={{ fontSize: 14, display: "flex", gap: 8, flexWrap: "wrap", alignItems: "center" }}>
        <strong>Legenda:</strong> <Selo c="verde" /> <Selo c="amarelo" /> <Selo c="vermelho" />
        <span>— a cor mostra só quanto está documentado; <strong>não indica irregularidade</strong>.</span>
      </p>

      <div id="abc-painel" role="tabpanel" aria-labelledby={`abc-aba-${aba}`}>
        {aba === "pnab" && <ResultadosPNAB />}
        {aba === "cidade" && (cidade ? <>
          <h2 style={{ fontSize: 20 }}>{cidade}</h2>
          {fichasCidade.length ? fichasCidade.map((f) => <FichaCard key={f.id} f={f} />) : <Vazio>Ainda não há documentos oficiais cadastrados para {cidade}. Isso não quer dizer que a cidade não tenha política cultural — só que os dados ainda não foram coletados.</Vazio>}
        </> : <Vazio>Escolha uma das sete cidades do Grande ABC acima.</Vazio>)}

        {aba === "bairro" && (busca?.b ? (res.length ? res.map((f) => <FichaCard key={f.id} f={f} />)
          : <Vazio>Nenhum documento oficial liga recursos ou atividades ao bairro “{busca.b}”{busca.c ? ` em ${busca.c}` : ""}. Não atribuímos bairros sem prova.</Vazio>)
          : <Vazio>Digite o nome do seu bairro e toque em Pesquisar.</Vazio>)}

        {aba === "decisoes" && <Vazio>Decisões públicas de {nomeCidade}: atas de conselho, conferências e audiências — <strong>N/D</strong>. Nenhuma ata foi cadastrada ainda.</Vazio>}
        {aba === "plano" && <Vazio>Plano de Cultura de {nomeCidade}: metas e prazos — <strong>N/D</strong>. Nenhum plano foi cadastrado ainda.</Vazio>}

        {aba === "dinheiro" && (cidade ? <section style={box}>
          <h2 style={{ fontSize: 20, margin: "0 0 8px" }}>Dinheiro da cultura — {cidade}</h2>
          <div style={{ display: "grid", gap: 8, gridTemplateColumns: "repeat(auto-fit, minmax(min(100%, 180px), 1fr))" }}>
            {(["previsto", "empenhado", "liquidado", "pago"] as const).map((k) => {
              const v = k === "previsto" ? totalPrevisto(cidade) : 0;
              return <div key={k} style={{ border: "2px solid #111", borderRadius: 10, padding: 10, background: k === "pago" ? "#f2f2f2" : "#fff" }}>
                <strong style={{ display: "block", textTransform: "capitalize" }}>{k}</strong>
                <span style={{ fontSize: 20, fontWeight: 800 }}>{k === "previsto" && v ? moedaABC(v) : "N/D"}</span>
              </div>;
            })}
          </div>
          <p style={{ fontSize: 14, margin: "8px 0 0" }}><strong>Previsto</strong> é o que foi anunciado; <strong>pago</strong> é o que chegou de fato. Cada recurso é contado uma vez só, sem somar de novo por bairro.</p>
        </section> : <Vazio>Escolha uma cidade para ver o dinheiro da cultura.</Vazio>)}

        {aba === "projetos" && (busca ? (res.length ? res.map((f) => <FichaCard key={f.id} f={f} />)
          : <Vazio>Nenhuma ficha com documento oficial para essa pesquisa ainda.</Vazio>)
          : <Vazio>Escolha a cidade e toque em Pesquisar para ver projetos e resultados.</Vazio>)}

        {aba === "como" && <section style={box}>
          <h2 style={{ fontSize: 20, margin: "0 0 8px" }}>Como funciona</h2>
          <p>Cada ficha segue o caminho do recurso:</p>
          <p style={{ fontWeight: 700 }}>{ETAPAS.map((e) => e.nome).join(" → ")} → Fonte documental</p>
          <p>Etapa sem documento oficial aparece como <strong>N/D</strong>. Não inventamos bairros, pagamentos nem resultados.</p>
          <p>Santo André aparece como exemplo verificado: PNAB ciclo 2 (2026), 12 editais, total <strong>previsto</strong> {moedaABC(5790200)} — ainda sem comprovação de pagamento. Fonte: <a href="https://www3.santoandre.sp.gov.br/cultura/pnab/" target="_blank" rel="noopener noreferrer" style={{ color: "#111", fontWeight: 700 }}>Prefeitura de Santo André — PNAB ↗</a></p>
        </section>}
      </div>
    </main>
  );
}
