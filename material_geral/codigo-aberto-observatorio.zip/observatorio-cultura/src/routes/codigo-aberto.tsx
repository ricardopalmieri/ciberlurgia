import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";

export const Route = createFileRoute("/codigo-aberto")({
  head: () => ({
    meta: [
      { title: "Código aberto — Observatório da Cultura | Sarau na Quebrada" },
      { name: "description", content: "Baixe o código-fonte e as bases públicas do Observatório da Cultura Municipal (MIT e CC BY 4.0) e saiba como alterar." },
      { property: "og:title", content: "Código aberto — Observatório da Cultura" },
      { property: "og:description", content: "Baixe, estude, altere e reutilize o código e as bases públicas do Observatório." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: CodigoAberto,
});

type Info = { versao: string; sha256: string; bytes: number; arquivos: number };
const box = { border: "2px solid #111", borderRadius: 12, padding: 16, margin: "14px 0", background: "#fff" } as const;

function CodigoAberto() {
  const [info, setInfo] = useState<Info | null>(null);
  useEffect(() => { fetch("/downloads/pacote-info.json").then((r) => (r.ok ? r.json() : null)).then(setInfo).catch(() => {}); }, []);
  return (
    <main style={{ background: "#fff", color: "#111", minHeight: "100vh", padding: 16, maxWidth: 860, margin: "0 auto", fontFamily: "system-ui, sans-serif", lineHeight: 1.5 }}>
      <nav aria-label="Atalhos" style={{ display: "flex", gap: 12, flexWrap: "wrap", fontSize: 14 }}>
        <Link to="/" style={{ color: "#111" }}>← Início</Link>
        <Link to="/grande-abc" style={{ color: "#111" }}>Grande ABC</Link>
        <Link to="/marco-regulatorio" style={{ color: "#111" }}>Marco Regulatório e Democracia Cultural</Link>
      </nav>
      <h1 style={{ color: "#111", fontSize: "clamp(26px, 5vw, 38px)", margin: "10px 0 4px" }}>Código aberto</h1>
      <p>O Observatório é software livre. Qualquer pessoa pode baixar, estudar, alterar e reutilizar o código e as bases públicas.</p>

      <section style={box} aria-labelledby="baixar">
        <h2 id="baixar" style={{ marginTop: 0, fontSize: 20 }}>Baixar</h2>
        <a href="/downloads/codigo-aberto-observatorio.zip" download="codigo-aberto-observatorio.zip"
          style={{ display: "inline-block", background: "#111", color: "#fff", padding: "12px 18px", borderRadius: 10, fontWeight: 800, textDecoration: "none", minHeight: 48 }}>
          ⬇ Baixar código-fonte e bases (ZIP)
        </a>
        <p style={{ fontSize: 14, margin: "10px 0 0" }}>
          {info ? <>Versão {info.versao} · {info.arquivos} arquivos · {(info.bytes / 1024).toFixed(0)} KB</> : "Pacote versionado"} ·{" "}
          <a href="/downloads/codigo-aberto-observatorio.zip.sha256" style={{ color: "#111" }}>conferência SHA-256</a>
        </p>
        {info && <p style={{ fontSize: 12, wordBreak: "break-all", margin: "4px 0 0" }}>SHA-256: <code>{info.sha256}</code></p>}
      </section>

      <section style={box} aria-labelledby="tem">
        <h2 id="tem" style={{ marginTop: 0, fontSize: 20 }}>O que vem no pacote</h2>
        <ul style={{ paddingLeft: 20, listStyle: "disc" }}>
          <li>Código das páginas e componentes, configurações e testes.</li>
          <li>Bases públicas em JSON e CSV (PNAB Santo André — só vagas e valores <strong>previstos</strong>; fichas do Grande ABC; evidências e registros — listas vazias significam “não verificado”).</li>
          <li>README, LICENSE, COMO-CONTRIBUIR.md, FONTES-E-LIMITES-DOS-DADOS.md e SHA256SUMS.txt.</li>
        </ul>
        <p><strong>Não vem:</strong> senhas, chaves, dados pessoais, imagens do Fusca e da marca, nem os vídeos das séries — esses continuam com os direitos dos seus autores.</p>
      </section>

      <section style={box} aria-labelledby="como">
        <h2 id="como" style={{ marginTop: 0, fontSize: 20 }}>Como alterar</h2>
        <ol style={{ paddingLeft: 20, listStyle: "decimal" }}>
          <li>Baixe e descompacte o ZIP.</li>
          <li>Instale o Bun (bun.sh) e rode <code>bun install</code> e depois <code>bun run dev</code>.</li>
          <li>Edite as telas em <code>src/routes</code> e os dados em <code>src/lib</code> — sempre com fonte oficial, link e data.</li>
          <li>Publique a sua cópia com outro nome, ou envie a sugestão ao Sarau na Quebrada.</li>
        </ol>
        <p role="note" style={{ border: "2px dashed #111", borderRadius: 10, padding: 10 }}>
          <strong>Atenção:</strong> alterar a sua cópia não muda este site. Editar o site publicado exige acesso de manutenção dado pelo Sarau na Quebrada.
        </p>
      </section>

      <section style={box} aria-labelledby="lic">
        <h2 id="lic" style={{ marginTop: 0, fontSize: 20 }}>Licenças e limites</h2>
        <ul style={{ paddingLeft: 20, listStyle: "disc" }}>
          <li><strong>Código:</strong> licença MIT.</li>
          <li><strong>Textos e organização feitos pelo Observatório:</strong> CC BY 4.0.</li>
          <li><strong>Dados e documentos oficiais:</strong> mantêm fonte e licença originais (Prefeituras, IBGE etc.).</li>
          <li>Não há banco de dados online: os dados ficam em arquivos do próprio código.</li>
          <li>Valor previsto não é valor pago; endereço do proponente não prova o local de execução; nenhum resultado nominal da PNAB foi inventado.</li>
        </ul>
      </section>
    </main>
  );
}
