import { createFileRoute, Link } from "@tanstack/react-router";

const VIDEO_EP1 = "/__l5e/assets-v1/f2892c45-59ab-4dca-a3b0-21b1304c67e0/episodio1-cultura-viva.mp4";
const VIDEO_EP2 = "/__l5e/assets-v1/1ff096f7-264c-4feb-82c4-798df0d1c7d1/episodio2-neri-piquena.mp4";

// Programação: só publicar eventos com comprovação real (nome, data, local, inscrição confirmados).

export const Route = createFileRoute("/agenda")({
  head: () => ({
    meta: [
      { title: "Agenda Cultural — Sarau na Quebrada" },
      { name: "description", content: "Séries audiovisuais do Sarau na Quebrada. Programação de eventos a confirmar." },
      { property: "og:type", content: "website" },
      { property: "og:title", content: "Agenda Cultural — Sarau na Quebrada" },
      { property: "og:description", content: "Séries audiovisuais do Sarau na Quebrada. Programação de eventos a confirmar." },
      { property: "og:image", content: "https://sarau-na-quebrada.lovable.app/compartilhar-fusca.jpg" },
      { name: "twitter:image", content: "https://sarau-na-quebrada.lovable.app/compartilhar-fusca.jpg" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Agenda,
});

const S = {
  page: { minHeight: "100vh", background: "#111313", color: "#f4efe6", fontFamily: "system-ui, sans-serif", padding: "24px 16px 60px" },
  card: { background: "#1d2020", border: "2px solid #f2c230", borderRadius: 14, padding: 18, marginBottom: 16 },
  btn: { display: "inline-block", background: "#f2c230", color: "#111313", padding: "10px 16px", borderRadius: 999, fontWeight: 700, textDecoration: "none", marginTop: 10 },
} as const;

type Episodio = { numero: number; titulo?: string; sinopse?: string; capa?: string; video?: string };
type Serie = { id: string; nome: string; apresentacao: string; episodios: Episodio[] };

// Episódios sem "video" aparecem como "em breve". Para publicar, preencha titulo, sinopse, capa e video.
const SERIES: Serie[] = [
  {
    id: "neri-piquena-glaucia",
    nome: "Série Neri, Piquena e Gláucia",
    apresentacao: "As aventuras da turma atrás das políticas culturais do município.",
    episodios: [
      { numero: 1, titulo: "As aventuras de Neri e Piquena atrás do Plano Municipal de Cultura", capa: "/fusca-sarau.png", video: VIDEO_EP1 },
      { numero: 2, titulo: "Neri e Piquena atrás do Conselho de Política Cultural", capa: "/fusca-sarau.png", video: VIDEO_EP2 },
      { numero: 3 },
      { numero: 4 },
    ],
  },
  {
    id: "potencia-de-antonio",
    nome: "A Potência de Antônio",
    apresentacao: "Série de animação inspirada no pensamento de Milton Santos.",
    episodios: [{ numero: 1 }, { numero: 2 }],
  },
];

function CartaoEpisodio({ ep }: { ep: Episodio }) {
  const titulo = ep.titulo ?? "Título a definir";
  return (
    <article style={{ ...S.card, marginBottom: 0, display: "flex", flexDirection: "column" }}>
      <p style={{ color: "#f2c230", fontWeight: 700, margin: 0, fontSize: 13, letterSpacing: 1 }}>EPISÓDIO {ep.numero}</p>
      <h3 style={{ fontSize: 18, margin: "6px 0" }}>{titulo}</h3>
      {ep.sinopse && <p style={{ margin: "4px 0 8px", opacity: 0.85 }}>{ep.sinopse}</p>}
      {ep.video ? (
        <video
          controls
          playsInline
          preload="metadata"
          poster={ep.capa}
          src={ep.video}
          aria-label={`Assistir episódio ${ep.numero}: ${titulo}`}
          style={{ width: "100%", aspectRatio: "16/9", borderRadius: 10, marginTop: "auto", background: "#000" }}
        />
      ) : (
        <div
          role="note"
          style={{ marginTop: "auto", aspectRatio: "16/9", borderRadius: 10, border: "2px dashed #f2c230", display: "grid", placeItems: "center", textAlign: "center", padding: 12, opacity: 0.8 }}
        >
          🎬 Vídeo pendente — ainda não enviado
        </div>
      )}
    </article>
  );
}

function Agenda() {
  return (
    <main style={S.page}>
      <div style={{ maxWidth: 1000, margin: "0 auto" }}>
        <Link to="/" style={{ color: "#f2c230", textDecoration: "none" }}>← Voltar ao Observatório</Link>
        <p style={{ letterSpacing: 3, color: "#f2c230", marginTop: 20, fontSize: 13 }}>SARAU NA QUEBRADA</p>
        <h1 style={{ fontSize: 34, margin: "4px 0 20px" }}>Agenda Cultural</h1>
        <nav aria-label="Séries" style={{ display: "flex", flexWrap: "wrap", gap: 8, marginBottom: 20 }}>
          {SERIES.map((s) => (
            <a key={s.id} href={`#${s.id}`} style={{ ...S.btn, marginTop: 0 }}>{s.nome}</a>
          ))}
          <a href="#eventos" style={{ ...S.btn, marginTop: 0 }}>Programação</a>
          <Link to="/acervo" style={{ ...S.btn, marginTop: 0 }}>🎬 Acervo Audiovisual</Link>
        </nav>
        {SERIES.map((s) => (
          <section key={s.id} id={s.id} aria-labelledby={`${s.id}-t`} style={{ marginBottom: 32 }}>
            <h2 id={`${s.id}-t`} style={{ fontSize: 26, margin: "0 0 4px" }}>{s.nome}</h2>
            <p style={{ margin: "0 0 14px", opacity: 0.85 }}>{s.apresentacao}</p>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(260px, 1fr))", gap: 16 }}>
              {s.episodios.map((ep) => <CartaoEpisodio key={ep.numero} ep={ep} />)}
            </div>
          </section>
        ))}
        <h2 id="eventos" style={{ fontSize: 26, margin: "0 0 14px" }}>Programação</h2>
        <div role="note" style={{ ...S.card, borderStyle: "dashed" }}>
          <p style={{ margin: 0, fontWeight: 700, color: "#f2c230" }}>Programação a confirmar</p>
          <p style={{ margin: "6px 0 0", opacity: 0.85 }}>Os próximos eventos serão divulgados aqui assim que forem confirmados.</p>
        </div>
      </div>
    </main>
  );
}
