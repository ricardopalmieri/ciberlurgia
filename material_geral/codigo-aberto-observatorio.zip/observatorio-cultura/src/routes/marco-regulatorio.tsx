import { VisaoBrasil } from "@/components/VisaoBrasil";
import { Financas } from "@/components/Financas";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { ITENS, STATUS_LABEL, type Status, EVIDENCIAS, statusDoItem, contarAuditadas, normalizar } from "@/lib/marco";
import { MEDIDORES, buscaOficial } from "@/lib/fontes";
import { INDICADORES, STATUS_DC, type StatusDC, statusIndicador, contadoresNacionais, sugerirMunicipios, type Ente } from "@/lib/democracia";

export const Route = createFileRoute("/marco-regulatorio")({
  head: () => ({
    meta: [
      { title: "Democracia Cultural e Marco Regulatório — Sarau na Quebrada" },
      { name: "description", content: "Painel nacional: conselhos, planos, fundos, conferências e a Lei 14.903/2024 em todos os municípios, só com fontes comprovadas." },
      { property: "og:type", content: "website" },
      { property: "og:title", content: "Democracia Cultural e Marco Regulatório — Sarau na Quebrada" },
      { property: "og:description", content: "Painel nacional da cultura nas 27 UFs e em todos os municípios, só com fontes comprovadas." },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Painel,
});

const AM = "#111111";
const AMARELO = "#f2c230";
const campo = { background: "#ffffff", color: "#111111", border: "2px solid #111111", borderRadius: 10, padding: "10px 12px", fontSize: 16, width: "100%" } as const;
const LEI = "https://www.planalto.gov.br/ccivil_03/_ato2023-2026/2024/lei/L14903.htm";
// Itens do Marco exibidos na aba própria (Conselho/Fundo/Plano institucional ficam na aba Democracia).
const ITENS_MARCO = ITENS.filter((i) => !["conselho", "fundo"].includes(i.id));

type Raw = { "municipio-id": number; "municipio-nome": string; "UF-id": number; "UF-sigla": string; "UF-nome": string };
type Selecao = { tipo: "uf" | "municipio"; id: number; nome: string; uf: string };

function Painel() {
  const [lista, setLista] = useState<Ente[]>([]);
  const [erro, setErro] = useState("");
  const [carregando, setCarregando] = useState(true);
  const [uf, setUf] = useState("");
  const [q, setQ] = useState("");
  const [ativo, setAtivo] = useState(-1);
  const [aberta, setAberta] = useState(false);
  const [sel, setSel] = useState<Selecao | null>(null);
  const [pend, setPend] = useState<Ente | null>(null);
  const [msg, setMsg] = useState("");
  
  const carregar = () => {
    setCarregando(true); setErro("");
    fetch("https://servicodados.ibge.gov.br/api/v1/localidades/municipios?view=nivelado", { signal: AbortSignal.timeout(20000) })
      .then((r) => { if (!r.ok) throw new Error(String(r.status)); return r.json() as Promise<Raw[]>; })
      .then((d) => {
        if (!d.length) throw new Error("vazio");
        setLista(d.map((m) => ({ id: m["municipio-id"], nome: m["municipio-nome"], uf: m["UF-sigla"], ufNome: m["UF-nome"], ufId: m["UF-id"] }))
          .sort((a, b) => a.nome.localeCompare(b.nome, "pt-BR")));
      })
      .catch(() => setErro("Não foi possível carregar a lista oficial do IBGE agora. Verifique a internet e tente de novo."))
      .finally(() => setCarregando(false));
  };
  useEffect(carregar, []);

  const ufs = useMemo(() => {
    const m = new Map<string, { nome: string; id: number }>();
    lista.forEach((x) => m.set(x.uf, { nome: x.ufNome, id: x.ufId }));
    return [...m].sort((a, b) => a[1].nome.localeCompare(b[1].nome, "pt-BR"));
  }, [lista]);
  const sugestoes = useMemo(() => sugerirMunicipios(lista, uf, q), [lista, uf, q]);
  useEffect(() => setAtivo(-1), [q, uf]);
  const dc = contadoresNacionais();
  const mr = contarAuditadas();
  const mostrar = aberta && sugestoes.length > 0;
  const instrucao = !uf ? "Primeiro escolha o Estado (UF)." : normalizar(q).length < 3 ? "Digite pelo menos 3 letras" : sugestoes.length ? `${sugestoes.length} sugestão(ões). Use as setas e Enter.` : "Nenhum município encontrado com esse nome neste estado.";
  const ufInfo = ufs.find(([s]) => s === uf)?.[1];

  const alvo = sel;
  const [escopo, setEscopo] = useState<"brasil" | "estado" | "municipio">("brasil");
  const irEscopo = (e: "brasil" | "estado" | "municipio") => { setEscopo(e); if (e === "brasil") { setSel(null); setMsg(""); } else setTimeout(() => document.getElementById(e === "estado" ? "sel-uf" : "busca-municipio")?.focus(), 30); };
  const escolher = (m: Ente) => { setQ(m.nome); setAberta(false); setPend(m); setMsg(""); };
  const buscar = () => {
    setAberta(false);
    if (erro) { setMsg("A lista oficial do IBGE não carregou. Use “Tentar novamente”."); return; }
    if (carregando) { setMsg("Aguarde: carregando a lista do IBGE…"); return; }
    if (!uf || !ufInfo) { setMsg("Escolha primeiro o Estado (UF)."); return; }
    const t = normalizar(q);
    if (!t) { setSel({ tipo: "uf", id: ufInfo.id, nome: ufInfo.nome, uf }); setEscopo("estado"); setMsg(`Mostrando o governo estadual de ${ufInfo.nome}.`); }
    else {
      const m = pend && normalizar(pend.nome) === t && pend.uf === uf ? [pend] : lista.filter((x) => x.uf === uf && normalizar(x.nome) === t);
      if (m.length === 1) { setSel({ tipo: "municipio", id: m[0]!.id, nome: m[0]!.nome, uf }); setEscopo("municipio"); setMsg(`Mostrando o município de ${m[0]!.nome} · ${uf}.`); }
      else if (m.length > 1) { setMsg("Há mais de um município com esse nome. Escolha uma opção da lista de sugestões."); setAberta(true); return; }
      else { setMsg(t.length < 3 ? "Digite pelo menos 3 letras e escolha um município da lista." : "Nenhum município com esse nome exato neste estado. Escolha uma das sugestões."); setAberta(true); return; }
    }
    setTimeout(() => document.getElementById("termo-t")?.scrollIntoView({ behavior: "smooth", block: "start" }), 50);
  };
  const onKey = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "ArrowDown" && sugestoes.length) { e.preventDefault(); setAberta(true); setAtivo((a) => (a + 1) % sugestoes.length); }
    else if (e.key === "ArrowUp" && sugestoes.length) { e.preventDefault(); setAberta(true); setAtivo((a) => (a <= 0 ? sugestoes.length - 1 : a - 1)); }
    else if (e.key === "Enter" && aberta && ativo >= 0 && sugestoes[ativo]) { e.preventDefault(); escolher(sugestoes[ativo]); }
    else if (e.key === "Enter") { e.preventDefault(); buscar(); }
    else if (e.key === "Escape") { setAberta(false); setAtivo(-1); }
  };

  return (
    <main style={{ minHeight: "100vh", background: "#ffffff", color: "#111111", fontFamily: "system-ui, sans-serif", padding: "20px 16px 60px" }}>
      <style>{`.mr a:focus-visible,.mr button:focus-visible,.mr select:focus-visible,.mr input:focus-visible{outline:3px solid #b8860b;outline-offset:2px}.mr header{background:#fff;color:#111;border:0;min-height:0;display:block;padding:0}.mr h1,.mr h2,.mr h3,.mr h4{color:#111 !important}.mr a{color:#111}.mr button{background:#fff;color:#111;box-shadow:none;border:2px solid #111}.mr button:hover{background:#f2c230;color:#111}.mr .mr-fin[aria-expanded=true]{background:#111 !important;color:#fff !important}.mr .mr-buscar{background:#111 !important;color:#fff !important}.mr .mr-buscar:hover{background:#333 !important}.mr h2[tabindex]:focus{outline:none}`}</style>
      <div className="mr" style={{ maxWidth: 1100, margin: "0 auto" }}>
        <nav aria-label="Navegação secundária" style={{ display: "flex", gap: 14, flexWrap: "wrap", fontSize: 14 }}>
          <Link to="/" style={{ color: AM }}>← Início (Fusca)</Link>
          <Link to="/agenda" style={{ color: AM }}>Agenda</Link>
        </nav>
        <div role="banner" style={{ textAlign: "center", margin: "18px 0 10px" }}>
          <p style={{ letterSpacing: 3, fontSize: 12, margin: 0, fontWeight: 700 }}>SARAU NA QUEBRADA</p>
          <h1 style={{ fontSize: "clamp(26px, 6vw, 42px)", margin: "4px 0" }}>Observatório da Cultura Municipal</h1>
          <p style={{ fontSize: "clamp(16px, 3.5vw, 20px)", margin: "0 0 12px", fontWeight: 600 }}>Marco Regulatório e Democracia Cultural</p>
          <nav aria-label="Principal" style={{ display: "flex", gap: 10, justifyContent: "center", flexWrap: "wrap" }}>
            <Link to="/acervo" style={btn}>Arquivo</Link>
            <Link to="/marco-regulatorio" aria-current="page" style={{ ...btn, background: AMARELO }}>Marco Regulatório e Democracia Cultural</Link>
          </nav>
        </div>

        <div role="note" aria-label="Aviso sobre os dados" style={{ border: "2px dashed #111", borderRadius: 12, padding: "10px 14px", fontSize: 14, maxWidth: 820, margin: "14px auto" }}>
          <strong>⚠️ Monitoramento em construção.</strong> Estados e municípios vêm do cadastro oficial do IBGE, só para localizar. Estar cadastrado <strong>não é</strong> verificação.
          “Não verificado” quer dizer que ainda não conferimos documentos oficiais — <strong>não</strong> que o instrumento não exista. Não exibimos percentuais: cada indicador só muda com documento oficial auditado, com link e data.
        </div>

        <div role="group" aria-label="Escopo do termômetro" style={{ display: "flex", gap: 8, flexWrap: "wrap", margin: "16px 0 0" }}>
          {(["brasil", "estado", "municipio"] as const).map((e) => (
            <button key={e} type="button" aria-pressed={escopo === e} className="mr-fin" aria-expanded={escopo === e} onClick={() => irEscopo(e)}
              style={{ flex: "1 1 120px", padding: "10px 14px", borderRadius: 10, fontWeight: 800, border: "2px solid #111", background: escopo === e ? "#111" : "#fff", color: escopo === e ? "#fff" : "#111" }}>
              {e === "brasil" ? "🇧🇷 Brasil" : e === "estado" ? "Estado" : "Município"}</button>))}
        </div>
        <form role="search" aria-label="Escolher estado e município" onSubmit={(e) => { e.preventDefault(); buscar(); }} style={{ display: "grid", gap: 12, gridTemplateColumns: "repeat(auto-fit, minmax(min(100%, 260px), 1fr))", margin: "16px 0" }}>
          <label style={{ fontWeight: 600 }}>1. Estado (UF)
            <select id="sel-uf" value={uf} disabled={carregando || !!erro} onChange={(e) => { setUf(e.target.value); setQ(""); setAberta(false); setSel(null); setPend(null); setMsg(""); }} style={campo}>
              <option value="">Escolha o estado</option>
              {ufs.map(([s, i]) => <option key={s} value={s}>{i.nome} ({s})</option>)}
            </select>
          </label>
          <div style={{ position: "relative" }}>
            <label htmlFor="busca-municipio" style={{ fontWeight: 600 }}>2. Município</label>
            <input id="busca-municipio" type="text" role="combobox" autoComplete="off" aria-autocomplete="list"
              aria-expanded={mostrar} aria-controls="sugestoes-municipio" aria-describedby="instrucao-municipio"
              aria-activedescendant={mostrar && ativo >= 0 ? `sug-${sugestoes[ativo]?.id}` : undefined}
              disabled={!uf} value={q} placeholder={uf ? "Ex.: San" : "Escolha o estado primeiro"}
              onChange={(e) => { setQ(e.target.value); setAberta(true); setPend(null); }} onKeyDown={onKey}
              onBlur={() => setTimeout(() => setAberta(false), 150)} style={{ ...campo, opacity: uf ? 1 : 0.5 }} />
            <div id="instrucao-municipio" aria-live="polite" style={{ fontSize: 13, marginTop: 4 }}>{carregando ? "Carregando municípios do IBGE…" : erro ? "" : instrucao}</div>
            <ul id="sugestoes-municipio" role="listbox" aria-label="Sugestões de municípios" hidden={!mostrar}
              style={{ position: "absolute", left: 0, right: 0, zIndex: 20, listStyle: "none", margin: 0, padding: 4, background: "#fff", border: "2px solid #111", borderRadius: 10, maxHeight: 280, overflowY: "auto" }}>
              {sugestoes.map((m, i) => (
                <li key={m.id} id={`sug-${m.id}`} role="option" aria-selected={i === ativo}
                  onMouseDown={(e) => { e.preventDefault(); escolher(m); }}
                  style={{ padding: "8px 10px", borderRadius: 6, cursor: "pointer", background: i === ativo ? AMARELO : "transparent", color: "#111" }}>{m.nome}</li>
              ))}
            </ul>
          </div>
          <div style={{ alignSelf: "start", paddingTop: 22 }}>
            <button type="submit" style={{ width: "100%", minHeight: 48, padding: "10px 24px", fontSize: 17, fontWeight: 800, borderRadius: 10, background: "#111", color: "#fff", border: "2px solid #111" }} className="mr-buscar">🔍 Buscar</button>
            <div style={{ fontSize: 12, marginTop: 4 }}>Só Estado = governo estadual · Estado + município = prefeitura</div>
          </div>
        </form>
        <p aria-live="polite" role="status" style={{ fontWeight: 700, margin: "0 0 8px", minHeight: 20 }}>{msg}</p>
        {erro && <p role="alert">{erro} <button onClick={carregar} style={{ ...campo, width: "auto" }}>Tentar novamente</button></p>}

        {escopo === "brasil" || !alvo ? <VisaoBrasil lista={lista} ufs={ufs} onVerUf={(u) => { setUf(u); setQ(""); setSel(null); setEscopo("estado"); const i = ufs.find(([x]) => x === u)?.[1]; if (i) setSel({ tipo: "uf", id: i.id, nome: i.nome, uf: u }); setTimeout(() => document.getElementById("termo-t")?.scrollIntoView({ block: "start" }), 50); }} /> : null}
        {escopo !== "brasil" && <Termometro s={alvo} />}
        <Financas s={escopo === "brasil" ? null : alvo} />

        <section aria-labelledby="cont-t" style={{ margin: "16px 0" }}>
          <h2 id="cont-t" style={{ fontSize: 18 }}>Contadores nacionais</h2>
          <div style={{ display: "flex", gap: 12, flexWrap: "wrap" }}>
            <Caixa v={carregando ? "…" : erro ? "—" : String(ufs.length)} t="UFs no cadastro IBGE" />
            <Caixa v={carregando ? "…" : erro ? "—" : String(lista.length)} t="Municípios no cadastro IBGE" />
            {dc.registros + mr.evidencias === 0 ? (
              <p style={{ border: "1px solid #999", borderRadius: 12, padding: "10px 14px", margin: 0, flex: "1 1 260px" }}>
                <strong>Coleta de evidências em andamento.</strong> Ainda não há documentos auditados publicados.
              </p>
            ) : (<>
              <Caixa v={String(dc.registros)} t="Registros comprovados (Democracia)" />
              <Caixa v={String(mr.evidencias)} t="Evidências auditadas (Marco)" />
            </>)}
          </div>
        </section>

        <Paineis s={alvo} />
      </div>
    </main>
  );
}

const btn = { display: "inline-block", padding: "8px 14px", border: "2px solid #111", borderRadius: 999, color: "#111", textDecoration: "none", fontWeight: 700, fontSize: 14, maxWidth: 300, textAlign: "center", lineHeight: 1.25 } as const;


function Caixa({ v, t }: { v: string; t: string }) {
  return (
    <div style={{ border: `2px solid ${AM}`, borderRadius: 12, padding: "10px 14px", minWidth: 150, borderColor: "#111" }}>
      <div style={{ fontSize: 26, fontWeight: 800, color: "#111" }}>{v}</div><div style={{ fontSize: 13 }}>{t}</div>
    </div>
  );
}

// Nível do semicírculo = etapa documental, nunca percentual. 0 = não verificado.
const NIVEL_DC: Record<StatusDC, number> = { nao_verificado: 0, em_implantacao: 1, instituido_legalmente: 2, funcionamento_comprovado: 3 };
const NIVEL_MR: Record<Status, number> = { nao_verificado: 0, em_apuracao: 0, verificado_nao_existe: 0, verificado_existe: 3 };
const GAUGES = [
  { id: "plano", nome: "Plano" }, { id: "conselho", nome: "Conselho" }, { id: "fundo", nome: "Fundo" },
  { id: "conferencias", nome: "Conferência" }, { id: "sistema", nome: "Sistema" }, { id: "lei", nome: "Marco Regulatório" },
] as const;

function Gauge({ nome, nivel, rotulo, ativo, onClick }: { nome: string; nivel: number; rotulo: string; ativo: boolean; onClick: () => void }) {
  const arco = (a0: number, a1: number) => {
    const p = (a: number) => [60 - 48 * Math.cos(a), 60 - 48 * Math.sin(a)];
    const [x0, y0] = p(a0); const [x1, y1] = p(a1);
    return `M${x0} ${y0} A48 48 0 0 1 ${x1} ${y1}`;
  };
  const segs = [0, 1, 2].map((i) => [Math.PI * i / 3 + 0.04, Math.PI * (i + 1) / 3 - 0.04]);
  return (
    <button type="button" onClick={onClick} aria-expanded={ativo} aria-controls="termo-detalhe" aria-label={`${nome}: ${rotulo}. Ver detalhes`}
      style={{ margin: 0, textAlign: "center", border: ativo ? "3px solid #111" : "1px solid #bbb", borderRadius: 12, padding: "10px 6px", background: ativo ? "#fff7d6" : "#fff", color: "#111", cursor: "pointer", minHeight: 0, width: "100%" }}>
      <svg viewBox="0 0 120 68" width="100%" style={{ maxWidth: 150, display: "block", margin: "0 auto" }} aria-hidden="true">
        {segs.map(([a, b], i) => <path key={i} d={arco(a!, b!)} fill="none" strokeWidth={12} stroke={i < nivel ? "#111" : "#e4e4e4"} strokeDasharray={nivel === 0 ? "4 3" : undefined} />)}
        <text x="60" y="62" textAnchor="middle" fontSize="11" fontWeight="700" fill="#111">{nivel === 0 ? "?" : `${nivel}/3`}</text>
      </svg>
      <strong style={{ display: "block", fontSize: 14 }}>{nome}</strong><span style={{ fontSize: 12, fontWeight: 400 }}>{rotulo}</span>
      <span style={{ display: "block", fontSize: 11, textDecoration: "underline", marginTop: 4 }}>{ativo ? "Detalhes abertos" : "Ver detalhes"}</span>
    </button>
  );
}

type Det = { status: string; nivel: number; criterio: string; docs: { link: string; descricao: string; extra: string }[] };
function detalhe(s: Selecao | null, g: (typeof GAUGES)[number]["id"]): Det {
  if (g === "lei") {
    const reg = ITENS.find((i) => i.id === "regulamentacao_local")!; const ed = ITENS.find((i) => i.id === "uso_editais")!;
    const crit = `Lei federal 14.903/2024 vigente em todo o país. Aqui medimos a aplicação local: ${reg.nota} ${ed.nota}`;
    if (!s) return { status: "Não verificado", nivel: 0, criterio: crit, docs: [] };
    const st = statusDoItem(s.id, "regulamentacao_local");
    const docs = EVIDENCIAS.filter((e) => e.municipioId === s.id && (e.item === "regulamentacao_local" || e.item === "uso_editais") && e.auditadoEm && e.link)
      .map((e) => ({ link: e.link, descricao: e.descricao, extra: `Documento: ${e.data} · Auditado: ${e.auditadoEm}` }));
    return { status: STATUS_LABEL[st], nivel: NIVEL_MR[st], criterio: crit, docs };
  }
  const ind = INDICADORES.find((i) => i.id === g)!;
  if (!s) return { status: "Não verificado", nivel: 0, criterio: ind.detalhe, docs: [] };
  const { status, registros } = statusIndicador(s.id, g);
  return { status: STATUS_DC[status], nivel: NIVEL_DC[status], criterio: ind.detalhe,
    docs: registros.map((r) => ({ link: r.link, descricao: r.descricao, extra: `Fonte: ${r.fonte} · Documento: ${r.data} · Atualizado: ${r.atualizadoEm}` })) };
}

const fonteBtn = { display: "inline-block", padding: "8px 12px", border: "2px solid #111", borderRadius: 8, color: "#111", fontWeight: 700, fontSize: 13, textDecoration: "none", background: "#fff" } as const;

function Termometro({ s }: { s: Selecao | null }) {
  const [ativo, setAtivo] = useState<(typeof GAUGES)[number]["id"] | null>(null);
  const abrir = (id: (typeof GAUGES)[number]["id"]) => { setAtivo(ativo === id ? null : id); setTimeout(() => { const el = document.getElementById("termo-detalhe"); el?.scrollIntoView({ behavior: "smooth", block: "start" }); el?.focus({ preventScroll: true }); }, 30); };
  const escopo = s ? (s.tipo === "uf" ? `Escopo: Governo estadual · ${s.nome} (para ver um município, digite o nome acima)` : `Escopo: Município de ${s.nome} · ${s.uf}`) : "Escopo: nenhum ente escolhido. Escolha um estado (e, se quiser, um município).";
  const g = GAUGES.find((x) => x.id === ativo);
  const d = ativo ? detalhe(s, ativo) : null;
  return (
    <section aria-labelledby="termo-t" style={{ margin: "20px 0", border: "2px solid #111", borderRadius: 14, padding: 16 }}>
      <h2 id="termo-t" style={{ margin: "0 0 4px", fontSize: 20 }}>Termômetro das Políticas Culturais</h2>
      <p style={{ fontSize: 14, margin: "0 0 4px", fontWeight: 700 }} aria-live="polite">{escopo}</p>
      <p style={{ fontSize: 13, margin: "0 0 12px" }}>Toque em um medidor para ver os detalhes. Etapas: 1 em implantação · 2 instituído em lei · 3 funcionamento comprovado. Sem documento auditado = “Não verificado” (medidor neutro, sem porcentagem).</p>
      <div style={{ display: "grid", gap: 10, gridTemplateColumns: "repeat(auto-fit, minmax(min(100%, 140px), 1fr))" }}>
        {GAUGES.map((x) => { const dd = detalhe(s, x.id); return <Gauge key={x.id} nome={x.nome} nivel={dd.nivel} rotulo={dd.status} ativo={ativo === x.id} onClick={() => abrir(x.id)} />; })}
      </div>
      {d && g && (
        <div id="termo-detalhe" role="region" aria-label={`Detalhes: ${g.nome}`} tabIndex={-1} style={{ marginTop: 12, border: "2px solid #111", borderRadius: 12, padding: 14, background: "#fff" }}>
          <h3 style={{ margin: "0 0 6px", fontSize: 18 }}>{g.nome} — {s ? (s.tipo === "uf" ? `Governo estadual · ${s.nome}` : `${s.nome} · ${s.uf}`) : "sem ente escolhido"}</h3>
          <p style={{ margin: "4px 0" }}><strong>Status:</strong> {d.status}</p>
          <p style={{ margin: "4px 0", fontSize: 14 }}><strong>Critério:</strong> {d.criterio}</p>
          <p style={{ margin: "8px 0 4px", fontWeight: 700 }}>Documentos oficiais</p>
          {d.docs.length ? <ul style={{ fontSize: 14, margin: 0 }}>{d.docs.map((x) => <li key={x.link}><a href={x.link} target="_blank" rel="noopener noreferrer">{x.descricao}</a> — {x.extra}</li>)}</ul>
            : <p style={{ fontSize: 14, margin: 0 }}>{s ? "Ainda não há documento oficial auditado (com link e data) para este ente. Isso não significa que o instrumento não exista — significa que ainda não foi conferido." : "Escolha um estado ou município para ver os documentos."}</p>}
          {!d.docs.length && <p style={{ margin: "8px 0", padding: "8px 10px", border: "2px dashed #111", borderRadius: 8, fontSize: 14 }}>
            <strong>Situação dos dados: pendente de coleta.</strong> “Não há dados” aqui ≠ “não existe política”.</p>}
          <p style={{ margin: "8px 0 4px", fontWeight: 700 }}>Documento que precisa ser coletado</p>
          <p style={{ fontSize: 14, margin: 0 }}>{MEDIDORES[g.id].documento}</p>
          {MEDIDORES[g.id].aviso && <p style={{ fontSize: 14, margin: "6px 0 0" }}><strong>Atenção:</strong> {MEDIDORES[g.id].aviso}</p>}
          <p style={{ margin: "10px 0 6px", fontWeight: 700 }}>Consultar fonte oficial</p>
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
            {MEDIDORES[g.id].fontes.map((f) => <a key={f.url} href={f.url} target="_blank" rel="noopener noreferrer" style={fonteBtn}>{f.nome} ↗</a>)}
            {s && <a href={buscaOficial(s.tipo === "uf" ? `Governo do Estado ${s.nome}` : s.nome, s.uf, g.nome === "Marco Regulatório" ? "Lei 14.903" : `${g.nome} de Cultura`)} target="_blank" rel="noopener noreferrer" style={fonteBtn}>Pesquisar documentos de {s.nome} ↗</a>}
          </div>
          <p style={{ fontSize: 12, margin: "6px 0 0" }}>As fontes do MinC bloqueiam leitura automática; a conferência é manual e só vira status depois de auditada, com link e data.</p>
          <button type="button" onClick={() => setAtivo(null)} style={{ marginTop: 8, padding: "6px 14px", minHeight: 0, borderRadius: 999 }}>Fechar detalhes</button>
        </div>
      )}
    </section>
  );
}

function Paineis({ s }: { s: Selecao | null }) {
  useEffect(() => { if (s) document.getElementById("paineis-t")?.focus(); }, [s?.id]);
  const busca = (t: string) => "https://www.google.com/search?q=" + encodeURIComponent(`${s?.nome ?? ""} ${s?.uf ?? ""} ${t}`);
  const id = s?.id ?? -1;
  const plano = s ? statusIndicador(id, "plano").registros[0] : undefined;
  const card = { border: "1px solid #ccc", borderRadius: 10, padding: 10 } as const;
  const lnk = { color: "#111", fontSize: 13 } as const;
  return (
    <section aria-labelledby="paineis-t" style={{ marginTop: 20 }}>
      <h2 id="paineis-t" tabIndex={-1} style={{ fontSize: 20 }}>{s ? (s.tipo === "uf" ? `Governo estadual · ${s.nome}` : `${s.nome} · ${s.uf}`) : "Painéis detalhados"}</h2>
      <div style={{ display: "grid", gap: 16, gridTemplateColumns: "repeat(auto-fit, minmax(min(100%, 420px), 1fr))" }}>
        <section aria-labelledby="p-marco" style={{ border: "2px solid #111", borderRadius: 14, padding: 14 }}>
          <h3 id="p-marco" style={{ marginTop: 0 }}>⚖️ Marco Regulatório da Cultura</h3>
          <div style={{ display: "grid", gap: 8 }}>
            {ITENS_MARCO.map((i) => {
              const ev = s ? EVIDENCIAS.find((e) => e.municipioId === id && e.item === i.id && e.auditadoEm && e.link) : undefined;
              return (
                <article key={i.id} style={card}>
                  <h4 style={{ margin: 0, fontSize: 15 }}>{i.nome}</h4>
                  <p style={{ fontSize: 12, margin: "2px 0" }}>{i.nota}</p>
                  <p style={{ margin: "4px 0", fontWeight: 700 }}>Status: {i.id === "lei_federal" ? "Vigente (lei federal)" : s ? STATUS_LABEL[statusDoItem(id, i.id)] : "Não verificado"}</p>
                  {i.id === "lei_federal" ? <a href={LEI} target="_blank" rel="noopener noreferrer" style={lnk}>Texto completo da lei (Planalto)</a>
                    : ev ? <p style={{ fontSize: 13, margin: 0 }}><a href={ev.link} target="_blank" rel="noopener noreferrer" style={lnk}>{ev.descricao}</a><br />Documento: {ev.data} · Auditado: {ev.auditadoEm}</p>
                    : <p style={{ fontSize: 13, margin: 0 }}>Documento oficial: nenhum auditado ainda.{s && <> <a href={busca(i.nome)} target="_blank" rel="noopener noreferrer" style={lnk}>Pesquisar</a></>}</p>}
                </article>
              );
            })}
          </div>
        </section>
        <section aria-labelledby="p-dc" style={{ border: "2px solid #111", borderRadius: 14, padding: 14 }}>
          <h3 id="p-dc" style={{ marginTop: 0 }}>🗳️ Contador da Democracia Cultural</h3>
          <div style={{ display: "grid", gap: 8 }}>
            {INDICADORES.map((i) => {
              const { status, registros } = s ? statusIndicador(id, i.id) : { status: "nao_verificado" as StatusDC, registros: [] };
              return (
                <article key={i.id} style={card}>
                  <h4 style={{ margin: 0, fontSize: 15 }}>{i.nome}</h4>
                  <p style={{ fontSize: 12, margin: "2px 0" }}>{i.detalhe}</p>
                  <p style={{ margin: "4px 0", fontWeight: 700 }}>Status: {STATUS_DC[status]}</p>
                  {registros.length ? registros.map((r) => (
                    <p key={r.link} style={{ fontSize: 13, margin: "4px 0" }}>
                      <a href={r.link} target="_blank" rel="noopener noreferrer" style={lnk}>{r.descricao}</a><br />
                      Fonte: {r.fonte} · Documento: {r.data} · Atualizado: {r.atualizadoEm}
                    </p>
                  )) : <p style={{ fontSize: 13, margin: 0 }}>Documento oficial: nenhum comprovado ainda.{s && <> <a href={busca(i.nome)} target="_blank" rel="noopener noreferrer" style={lnk}>Pesquisar</a></>}</p>}
                </article>
              );
            })}
          </div>
        </section>
      </div>
      <h3 style={{ fontSize: 16, marginTop: 16 }}>Documentos completos</h3>
      <ul style={{ fontSize: 14 }}>
        <li><a href={LEI} target="_blank" rel="noopener noreferrer" style={lnk}>Lei 14.903/2024 (Marco Regulatório do Fomento)</a></li>
        <li>Plano de Cultura completo: {plano ? <a href={plano.link} target="_blank" rel="noopener noreferrer" style={lnk}>abrir documento</a> : "sem fonte registrada ainda"}</li>
      </ul>
      <p style={{ fontSize: 12 }}>“Pesquisar” abre uma busca externa; resultados precisam ser conferidos antes de virar evidência.</p>
    </section>
  );
}
