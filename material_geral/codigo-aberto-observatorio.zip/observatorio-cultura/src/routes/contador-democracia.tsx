import { createFileRoute, redirect } from "@tanstack/react-router";

// O Contador da Democracia Cultural foi unificado ao painel do Marco Regulatório.
export const Route = createFileRoute("/contador-democracia")({
  beforeLoad: () => {
    throw redirect({ to: "/marco-regulatorio", statusCode: 301 });
  },
});
