// Observatório da Cultura — Grande ABC. Só dados com fonte oficial; o resto é N/D.
export const CIDADES_ABC = [
  "Santo André", "São Bernardo do Campo", "São Caetano do Sul", "Diadema", "Mauá", "Ribeirão Pires", "Rio Grande da Serra",
] as const;
export type CidadeABC = (typeof CIDADES_ABC)[number];

export type Etapa = "participacao" | "decisao" | "meta" | "previsto" | "empenhado" | "liquidado" | "pago" | "local" | "atividade" | "resultado";
export const ETAPAS: { id: Etapa; nome: string }[] = [
  { id: "participacao", nome: "Participação" }, { id: "decisao", nome: "Decisão / ata" }, { id: "meta", nome: "Meta do Plano" },
  { id: "previsto", nome: "Valor previsto" }, { id: "empenhado", nome: "Empenhado" }, { id: "liquidado", nome: "Liquidado" },
  { id: "pago", nome: "Pago" }, { id: "local", nome: "Local real de execução" }, { id: "atividade", nome: "Atividade" }, { id: "resultado", nome: "Resultado" },
];

export type Ficha = {
  id: string; cidade: CidadeABC; titulo: string; bairro?: string; // bairro só com prova
  etapas: Partial<Record<Etapa, string>>; valores: Partial<Record<"previsto" | "empenhado" | "liquidado" | "pago", number>>;
  fonte: string; link: string; data: string;
};

export const FICHAS: Ficha[] = [
  {
    id: "sa-pnab-2026", cidade: "Santo André", titulo: "PNAB — ciclo 2 (2026): 12 editais",
    etapas: { previsto: "Total previsto nos 12 editais (não é valor pago)" },
    valores: { previsto: 5790200 },
    fonte: "Prefeitura de Santo André — Cultura / PNAB", link: "https://www3.santoandre.sp.gov.br/cultura/pnab/", data: "2026",
  },
];

export type Cor = "verde" | "amarelo" | "vermelho";
/** verde = todas as etapas documentadas; amarelo = parcial; vermelho = nenhuma. */
export function corDa(f: Ficha): Cor {
  const n = ETAPAS.filter((e) => f.etapas[e.id] || (e.id in f.valores && f.valores[e.id as keyof Ficha["valores"]] != null)).length;
  return n === 0 ? "vermelho" : n === ETAPAS.length ? "verde" : "amarelo";
}

export const fichasDa = (c: CidadeABC | "", bairro = "") => {
  const b = norm(bairro);
  return FICHAS.filter((f) => (!c || f.cidade === c) && (!b || (f.bairro && norm(f.bairro).includes(b))));
};

/** Soma por cidade contando cada ficha uma vez só (sem duplicar entre bairros). */
export function totalPrevisto(c: CidadeABC) {
  const vistos = new Set<string>(); let t = 0;
  for (const f of FICHAS) if (f.cidade === c && !vistos.has(f.id) && f.valores.previsto != null) { vistos.add(f.id); t += f.valores.previsto; }
  return t;
}

export const norm = (s: string) => s.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().trim();
export const moedaABC = (v: number) => v.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
