/** Announced opportunities only. This catalogue is not financial evidence or a list of beneficiaries. */
export const PNAB_FONTE = "https://www3.santoandre.sp.gov.br/cultura/pnab/";
export const PNAB_NOTICIA = "https://www3.santoandre.sp.gov.br/cultura/2026/09/08/santo-andre-republica-editais-do-ciclo-2-da-pnab-com-inscricoes-ate-24-de-setembro/";
export const PNAB_PROJETO = "https://culturaz.santoandre.sp.gov.br/projeto/2615/";
export const PNAB_VERIFICACAO = "07/11/2026";

type Categoria = { nome: string; vagas: number; valorUnitario: number };
export type EditalPNAB = {
  numero: number;
  titulo: string;
  tipo: "Fomento" | "Premiação" | "Bolsa";
  categorias: Categoria[];
  link: string;
};
const oportunidade = (id: number) => `https://culturaz.santoandre.sp.gov.br/oportunidade/${id}/`;
export const EDITAIS_PNAB: readonly EditalPNAB[] = [
  { numero: 18, titulo: "Fomento PF / coletivos sem CNPJ", tipo: "Fomento", categorias: [{ nome: "PF / coletivos sem CNPJ", vagas: 16, valorUnitario: 50000 }], link: oportunidade(2427) },
  { numero: 19, titulo: "Fomento PJ / MEI", tipo: "Fomento", categorias: [{ nome: "PJ / MEI", vagas: 15, valorUnitario: 50000 }], link: oportunidade(2429) },
  { numero: 20, titulo: "Meu Primeiro Edital — PF", tipo: "Fomento", categorias: [{ nome: "PF", vagas: 6, valorUnitario: 15000 }], link: oportunidade(2431) },
  { numero: 21, titulo: "Meu Primeiro Edital — PJ", tipo: "Fomento", categorias: [{ nome: "PJ", vagas: 5, valorUnitario: 15000 }], link: oportunidade(2433) },
  { numero: 22, titulo: "Premiação de agentes, espaços e técnicos", tipo: "Premiação", categorias: [{ nome: "Agentes / espaços / técnicos", vagas: 25, valorUnitario: 15000 }], link: oportunidade(2435) },
  { numero: 23, titulo: "Mestres e mestras da cultura popular", tipo: "Premiação", categorias: [{ nome: "Mestres e mestras", vagas: 15, valorUnitario: 15000 }], link: PNAB_FONTE },
  { numero: 24, titulo: "Bolsa de intercâmbio", tipo: "Bolsa", categorias: [{ nome: "Intercâmbio", vagas: 5, valorUnitario: 15800 }], link: PNAB_FONTE },
  { numero: 25, titulo: "Bolsa para agentes territoriais", tipo: "Bolsa", categorias: [{ nome: "Agentes territoriais", vagas: 5, valorUnitario: 15800 }], link: PNAB_FONTE },
  { numero: 26, titulo: "Ação continuada", tipo: "Fomento", categorias: [{ nome: "Ação continuada", vagas: 6, valorUnitario: 125000 }], link: PNAB_FONTE },
  { numero: 27, titulo: "Fomento a Pontos de Cultura com CNPJ", tipo: "Fomento", categorias: [{ nome: "Pontos de Cultura com CNPJ", vagas: 7, valorUnitario: 90000 }], link: oportunidade(2447) },
  { numero: 28, titulo: "Premiação Cultura Viva", tipo: "Premiação", categorias: [
    { nome: "A1 — sem CNPJ", vagas: 28, valorUnitario: 30000 },
    { nome: "A2 — sem CNPJ", vagas: 6, valorUnitario: 30000 },
    { nome: "B1 — com CNPJ", vagas: 15, valorUnitario: 50000 },
    { nome: "B2 — com CNPJ", vagas: 2, valorUnitario: 50000 },
  ], link: PNAB_FONTE },
  { numero: 29, titulo: "Bolsa Cultura Viva — mestras e mestres", tipo: "Bolsa", categorias: [{ nome: "Mestras e mestres", vagas: 4, valorUnitario: 16800 }], link: oportunidade(2451) },
];

export const CAMPOS_RESULTADO = [
  "Classificação nominal", "Selecionados / contemplados", "Suplentes", "Pontuação / notas",
  "Valores homologados", "Recursos financeiros", "Recursos interpostos / decisões",
  "Bairro de realização", "Execução", "Resultados", "Empenhado", "Liquidado", "Pago",
] as const;
// null means not documentarily verified, never zero beneficiaries/payments.
export const RESULTADOS_COMPROVADOS = { contemplados: null, suplentes: null, pagos: null } as const;
export const vagasPrevistas = (edital: EditalPNAB) => edital.categorias.reduce((s, c) => s + c.vagas, 0);
export const TOTAL_VAGAS_PNAB = EDITAIS_PNAB.reduce((s, e) => s + vagasPrevistas(e), 0);
export function filtrarEditais(numero = "", tipo = "") {
  return EDITAIS_PNAB.filter((e) => (!numero || String(e.numero) === numero) && (!tipo || e.tipo === tipo));
}

/** One row per announced category; no financial aggregation into Grande ABC FICHAS. */
export function quadroPNABCSV(editais: readonly EditalPNAB[] = EDITAIS_PNAB) {
  const rows: (string | number)[][] = [[
    "Natureza do quadro", "Edital", "Tipo", "Título", "Categoria", "Vagas PREVISTAS", "Valor unitário PREVISTO (BRL)",
    ...CAMPOS_RESULTADO, "Fonte das previsões", "Fonte oficial do edital", "Verificação do Observatório (não é publicação do resultado)",
  ]];
  for (const e of editais) for (const c of e.categorias) rows.push([
    "Previsão anunciada — NÃO é resultado homologado", `${e.numero}/2026`, e.tipo, e.titulo, c.nome, c.vagas, c.valorUnitario,
    ...CAMPOS_RESULTADO.map(() => "N/D — não conferido documentalmente"), PNAB_FONTE, e.link, PNAB_VERIFICACAO,
  ]);
  return "\uFEFF" + rows.map((row) => row.map((cell) => `"${String(cell).replace(/"/g, '""')}"`).join(";")).join("\r\n");
}