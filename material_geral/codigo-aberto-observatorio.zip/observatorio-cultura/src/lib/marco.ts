// Módulo de monitoramento do Marco Regulatório do Fomento à Cultura (Lei 14.903/2024).
// Regra: nada é afirmado sem evidência auditada. Status padrão = "nao_verificado".

export type Status = "nao_verificado" | "em_apuracao" | "verificado_existe" | "verificado_nao_existe";

export const STATUS_LABEL: Record<Status, string> = {
  nao_verificado: "Não verificado",
  em_apuracao: "Em apuração",
  verificado_existe: "Verificado — existe",
  verificado_nao_existe: "Verificado — não encontrado",
};

export const ITENS = [
  { id: "lei_federal", nome: "Lei federal 14.903/2024", nota: "Lei federal vigente em todo o país. Isso NÃO significa que o município a regulamentou ou a aplica." },
  { id: "regulamentacao_local", nome: "Regulamentação local do Marco", nota: "Decreto ou lei municipal que regulamenta a Lei 14.903/2024." },
  { id: "uso_editais", nome: "Aplicação em editais", nota: "Editais que citam e seguem a Lei 14.903/2024." },
  { id: "documentos", nome: "Documentos oficiais", nota: "Diário oficial, decretos, portarias." },
  { id: "plano", nome: "Plano de Cultura e metas", nota: "Plano aprovado, vigência e metas." },
  { id: "conselho", nome: "Conselho de Cultura", nota: "Lei, composição, atas." },
  { id: "fundo", nome: "Fundo de Cultura", nota: "Lei e regulamentação do fundo." },
  { id: "orcamento", nome: "Orçamento", nota: "Dotação na LOA; previsto x pago." },
  { id: "pnab", nome: "Execução PNAB", nota: "Repasses, editais e pagamentos." },
  { id: "gastos", nome: "Gastos com cultura", nota: "Despesas empenhadas, liquidadas e pagas, com fonte oficial." },
  { id: "territorio", nome: "Distribuição territorial", nota: "Bairros, periferias e áreas rurais atendidas." },
] as const;

export type ItemId = (typeof ITENS)[number]["id"];

export type Evidencia = {
  municipioId: number; // código IBGE (uso interno, nunca exibido no nome)
  item: ItemId;
  status: Status;
  descricao: string;
  link: string; // URL oficial da evidência
  data: string; // data do documento (AAAA-MM-DD)
  auditadoEm?: string; // só conta nos contadores se preenchido
};

// Registro de evidências auditadas. Vazio até haver apuração real — não inventar.
export const EVIDENCIAS: Evidencia[] = [];

export function statusDoItem(municipioId: number, item: ItemId, ev: Evidencia[] = EVIDENCIAS): Status {
  const e = ev.find((x) => x.municipioId === municipioId && x.item === item && x.auditadoEm && x.link);
  return e ? e.status : "nao_verificado";
}

export function statusGeral(municipioId: number, ev: Evidencia[] = EVIDENCIAS): Status {
  const s = ITENS.map((i) => statusDoItem(municipioId, i.id, ev));
  if (s.every((x) => x === "nao_verificado")) return "nao_verificado";
  if (s.some((x) => x === "nao_verificado" || x === "em_apuracao")) return "em_apuracao";
  return s.includes("verificado_existe") ? "verificado_existe" : "verificado_nao_existe";
}

/** Contadores: apenas evidências auditadas e com link. */
export function contarAuditadas(ev: Evidencia[] = EVIDENCIAS) {
  const ok = ev.filter((e) => e.auditadoEm && e.link);
  return { evidencias: ok.length, municipios: new Set(ok.map((e) => e.municipioId)).size };
}

export const normalizar = (s: string) =>
  s.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().trim();

export type Municipio = { id: number; nome: string; uf: string; ufNome: string };

export function filtrar(lista: Municipio[], q: string, uf: string, status: string, ev: Evidencia[] = EVIDENCIAS) {
  const n = normalizar(q);
  return lista.filter(
    (m) =>
      (!uf || m.uf === uf) &&
      (!n || normalizar(m.nome).includes(n)) &&
      (!status || statusGeral(m.id, ev) === status),
  );
}

/** Busca de município só começa com UF escolhida e 3+ letras. */
export const buscaPronta = (uf: string, q: string) => !!uf && normalizar(q).length >= 3;
