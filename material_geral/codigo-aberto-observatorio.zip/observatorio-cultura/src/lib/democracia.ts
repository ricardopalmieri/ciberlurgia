// Contador da Democracia Cultural.
// Regra: só conta registro com link, fonte, data e atualização. Falta de dado ≠ ausência do instrumento.
import { normalizar } from "./marco";

export type StatusDC = "nao_verificado" | "em_implantacao" | "instituido_legalmente" | "funcionamento_comprovado";

export const STATUS_DC: Record<StatusDC, string> = {
  nao_verificado: "Não verificado",
  em_implantacao: "Em implantação",
  instituido_legalmente: "Instituído legalmente",
  funcionamento_comprovado: "Funcionamento comprovado",
};

export const INDICADORES = [
  { id: "sistema", nome: "Sistema de Cultura", detalhe: "Lei de criação e adesão ao Sistema Nacional de Cultura." },
  { id: "conselho", nome: "Conselho de Cultura", detalhe: "Instituído, em funcionamento, caráter deliberativo ou consultivo, composição paritária (só quando comprovada)." },
  { id: "plano", nome: "Plano de Cultura", detalhe: "Lei, vigência e metas." },
  { id: "fundo", nome: "Fundo de Cultura", detalhe: "Lei e execução." },
  { id: "conferencias", nome: "Conferências de Cultura", detalhe: "Datas e atas." },
  { id: "eleicao_conselho", nome: "Eleição do Conselho", detalhe: "Edital, processo em curso, eleitos e mandato." },
  { id: "participacao", nome: "Participação popular", detalhe: "Audiências, fóruns e escutas." },
  { id: "transparencia", nome: "Transparência", detalhe: "Publicação de documentos, orçamento e gastos." },
  { id: "controle_social", nome: "Controle social", detalhe: "Acompanhamento e fiscalização pela sociedade." },
] as const;
export type IndicadorId = (typeof INDICADORES)[number]["id"];

export type RegistroDC = {
  enteId: number; // código IBGE do município ou da UF (uso interno)
  indicador: IndicadorId;
  status: StatusDC;
  descricao: string;
  fonte: string;
  link: string;
  data: string; // data do documento
  atualizadoEm: string; // data da última conferência
};

// Registros comprovados. Vazio até haver apuração documental — não inventar.
export const REGISTROS: RegistroDC[] = [];

export const comprovado = (r: RegistroDC) => !!(r.link && r.fonte && r.data && r.atualizadoEm);

export function statusIndicador(enteId: number, ind: IndicadorId, regs: RegistroDC[] = REGISTROS) {
  const r = regs.filter((x) => x.enteId === enteId && x.indicador === ind && comprovado(x));
  return { status: (r[0]?.status ?? "nao_verificado") as StatusDC, registros: r };
}

export function contadoresNacionais(regs: RegistroDC[] = REGISTROS) {
  const ok = regs.filter(comprovado);
  const porStatus = Object.fromEntries((Object.keys(STATUS_DC) as StatusDC[]).map((s) => [s, ok.filter((r) => r.status === s).length]));
  return { registros: ok.length, entesVerificados: new Set(ok.map((r) => r.enteId)).size, porStatus };
}

export type Ente = { id: number; nome: string; uf: string; ufNome: string; ufId: number };

export const sugerirMunicipios = (lista: Ente[], uf: string, q: string, max = 8) =>
  !uf || normalizar(q).length < 3 ? [] : lista.filter((m) => m.uf === uf && normalizar(m.nome).includes(normalizar(q))).slice(0, max);
