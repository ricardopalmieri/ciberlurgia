// Orçamento da Cultura e Transferências de Recursos.
// Registros só contam com link, fonte, data e atualizadoEm. Vazio até apuração — não inventar valores.
export type RegOrcamento = {
  enteId: number; exercicio: number; campo: "dotacao_loa" | "empenhado" | "liquidado" | "pago" | "fundo_cultura";
  valor: number; descricao: string; fonte: string; link: string; data: string; atualizadoEm: string;
};
export type RegTransferencia = {
  enteId: number; origem: "União" | "Estado"; destino: string; programa: string; // ex.: PNAB
  campo: "previsto" | "repassado" | "pago"; valor: number; modalidade: string; data: string;
  comprovante: string; vinculoPlano?: string; territorio?: string; fonte: string; link: string; atualizadoEm: string;
};

export const ORCAMENTO: RegOrcamento[] = [];
export const TRANSFERENCIAS: RegTransferencia[] = [];

const ok = (r: { link: string; fonte: string; data: string; atualizadoEm: string }) => !!(r.link && r.fonte && r.data && r.atualizadoEm);
export const orcamentoDo = (id: number, regs: RegOrcamento[] = ORCAMENTO) => regs.filter((r) => r.enteId === id && ok(r));
export const transferenciasDo = (id: number, regs: RegTransferencia[] = TRANSFERENCIAS) => regs.filter((r) => r.enteId === id && ok(r));

export const CAMPOS_ORC = [
  { id: "dotacao_loa", nome: "Dotação na LOA (cultura)" }, { id: "empenhado", nome: "Empenhado" },
  { id: "liquidado", nome: "Liquidado" }, { id: "pago", nome: "Pago" }, { id: "fundo_cultura", nome: "Fundo de Cultura (saldo/execução)" },
] as const;
export const CAMPOS_TRANSF = [
  { id: "previsto", nome: "Valor previsto" }, { id: "repassado", nome: "Valor repassado" }, { id: "pago", nome: "Valor pago" },
] as const;

export const FONTES_ORC = [
  { nome: "Siconfi — Finanças do Brasil (Tesouro)", url: "https://siconfi.tesouro.gov.br/" },
  { nome: "Tesouro Transparente", url: "https://www.tesourotransparente.gov.br/" },
];
export const FONTES_TRANSF = [
  { nome: "Portal da Transparência — Transferências", url: "https://portaldatransparencia.gov.br/transferencias" },
  { nome: "Transferegov", url: "https://www.gov.br/transferegov/" },
  { nome: "PNAB — Política Nacional Aldir Blanc (MinC)", url: "https://www.gov.br/cultura/pt-br/assuntos/pnab" },
];

export const moeda = (v: number) => v.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
