// Visão Brasil: agrega SOMENTE registros documentalmente verificados. Nunca é índice de cumprimento.
import { REGISTROS, comprovado } from "@/lib/democracia";
import { EVIDENCIAS } from "@/lib/marco";
import { ORCAMENTO, TRANSFERENCIAS } from "@/lib/financas";

export type Instrumento = "plano" | "conselho" | "fundo" | "conferencias" | "sistema" | "lei" | "orcamento" | "transferencias";
export const INSTRUMENTOS: { id: Instrumento; nome: string }[] = [
  { id: "plano", nome: "Plano" }, { id: "conselho", nome: "Conselho" }, { id: "fundo", nome: "Fundo" },
  { id: "conferencias", nome: "Conferência" }, { id: "sistema", nome: "Sistema" }, { id: "lei", nome: "Marco Regulatório" },
  { id: "orcamento", nome: "Orçamento da Cultura" }, { id: "transferencias", nome: "Transferências de Recursos" },
];
export type RegV = { instrumento: Instrumento; enteId: number; ano: number; descricao: string; link: string; fonte: string; data: string };

/** Código IBGE de UF (2 dígitos) ou de município (7 dígitos, os 2 primeiros são a UF). */
export const ufIdDe = (enteId: number) => (enteId < 100 ? enteId : Math.floor(enteId / 100000));
const ano = (d: string) => Number(d.slice(0, 4)) || 0;

export function registrosVerificados(): RegV[] {
  const out: RegV[] = [];
  REGISTROS.filter(comprovado).forEach((r) => {
    if (["plano", "conselho", "fundo", "conferencias", "sistema"].includes(r.indicador))
      out.push({ instrumento: r.indicador as Instrumento, enteId: r.enteId, ano: ano(r.data), descricao: r.descricao, link: r.link, fonte: r.fonte, data: r.data });
  });
  EVIDENCIAS.filter((e) => e.auditadoEm && e.link && (e.item === "regulamentacao_local" || e.item === "uso_editais"))
    .forEach((e) => out.push({ instrumento: "lei", enteId: e.municipioId, ano: ano(e.data), descricao: e.descricao, link: e.link, fonte: "Evidência auditada", data: e.data }));
  ORCAMENTO.filter((r) => r.link && r.fonte && r.data && r.atualizadoEm)
    .forEach((r) => out.push({ instrumento: "orcamento", enteId: r.enteId, ano: r.exercicio, descricao: r.descricao, link: r.link, fonte: r.fonte, data: r.data }));
  TRANSFERENCIAS.filter((r) => r.link && r.fonte && r.data && r.atualizadoEm)
    .forEach((r) => out.push({ instrumento: "transferencias", enteId: r.enteId, ano: ano(r.data), descricao: `${r.programa} · ${r.origem} → ${r.destino}`, link: r.link, fonte: r.fonte, data: r.data }));
  return out;
}

export function filtrarRegs(regs: RegV[], f: { ufId?: number | undefined; ano?: number | undefined; instrumento?: Instrumento | undefined }) {
  return regs.filter((r) => (!f.ufId || ufIdDe(r.enteId) === f.ufId) && (!f.ano || r.ano === f.ano) && (!f.instrumento || r.instrumento === f.instrumento));
}
export const entesCom = (regs: RegV[]) => new Set(regs.map((r) => r.enteId)).size;
