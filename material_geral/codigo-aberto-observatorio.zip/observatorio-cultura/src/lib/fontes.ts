// Fontes oficiais e documento necessário por medidor do Termômetro.
// Nada aqui é dado de ente: são apenas os caminhos para coleta e conferência.
// Um medidor só muda com registro comprovado em REGISTROS (democracia.ts) ou EVIDENCIAS (marco.ts).
export type MedidorId = "plano" | "conselho" | "fundo" | "conferencias" | "sistema" | "lei";
export type Fonte = { nome: string; url: string };

const SNC_PAINEL: Fonte = { nome: "Painel oficial do Sistema Nacional de Cultura (MinC)", url: "https://ver-snc.cultura.gov.br/" };
const SNC_DADOS: Fonte = { nome: "Dados abertos do SNC (dados.cultura.gov.br)", url: "https://dados.cultura.gov.br/dataset/sistema-nacional-de-cultura" };
const LEI: Fonte = { nome: "Lei 14.903/2024 (Planalto)", url: "https://www.planalto.gov.br/ccivil_03/_ato2023-2026/2024/lei/L14903.htm" };
const PNAB: Fonte = { nome: "Política Nacional Aldir Blanc (MinC)", url: "https://www.gov.br/cultura/pt-br/assuntos/pnab" };

export const MEDIDORES: Record<MedidorId, { documento: string; fontes: Fonte[]; aviso?: string }> = {
  sistema: {
    documento: "Acordo de adesão ao SNC publicado e lei municipal/estadual que institui o Sistema de Cultura.",
    fontes: [SNC_PAINEL, SNC_DADOS],
    aviso: "Adesão ao SNC NÃO comprova que Conselho, Plano ou Fundo existam ou funcionem — cada um é conferido separadamente.",
  },
  conselho: { documento: "Lei de criação do Conselho, ato de posse/eleição dos conselheiros e atas recentes de reunião.", fontes: [SNC_PAINEL] },
  plano: { documento: "Lei que aprova o Plano de Cultura (texto completo), vigência e metas.", fontes: [SNC_PAINEL] },
  fundo: { documento: "Lei de criação do Fundo de Cultura e comprovante de execução (CNPJ/conta, LOA ou relatório de gastos).", fontes: [SNC_PAINEL, PNAB] },
  conferencias: { documento: "Convocação oficial e relatório/ata da Conferência de Cultura, com data.", fontes: [SNC_PAINEL] },
  lei: { documento: "Decreto ou lei local que regulamenta a Lei 14.903/2024 e editais que a aplicam.", fontes: [LEI, PNAB] },
};

/** Busca no Diário Oficial / web oficial do ente, para o pesquisador conferir manualmente. */
export const buscaOficial = (ente: string, uf: string, termo: string) =>
  "https://www.google.com/search?q=" + encodeURIComponent(`"${ente}" ${uf} ${termo} site:gov.br OR site:leismunicipais.com.br OR diário oficial`);
