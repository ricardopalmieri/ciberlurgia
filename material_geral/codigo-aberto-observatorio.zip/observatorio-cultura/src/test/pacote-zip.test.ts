import { describe, it, expect } from "vitest";
import { execFileSync } from "node:child_process";

const ZIP = "public/downloads/codigo-aberto-observatorio.zip";
const lista = execFileSync("unzip", ["-Z1", ZIP]).toString().split("\n").filter(Boolean);

describe("pacote ZIP de código aberto", () => {
  it.each(["README.md", "LICENSE", "COMO-CONTRIBUIR.md", "FONTES-E-LIMITES-DOS-DADOS.md", "SHA256SUMS.txt",
    "dados/pnab-santo-andre-editais-previstos.csv", "dados/grande-abc-fichas.json", "src/routes/grande-abc.tsx",
    "src/routes/marco-regulatorio.tsx", "src/routes/index.tsx", "scripts/gerar-pacote.mjs"])("inclui %s", (f) =>
    expect(lista).toContain(`observatorio-cultura/${f}`));
  it("não inclui segredos, dependências, imagens ou vídeos", () =>
    expect(lista.filter((f) => /node_modules|\.git\/|\.env|\.lovable|\.(png|jpe?g|mp4|ico)$/i.test(f))).toEqual([]));
  it("LICENSE é MIT", () => expect(execFileSync("unzip", ["-p", ZIP, "observatorio-cultura/LICENSE"]).toString()).toMatch(/^MIT License/));
});
