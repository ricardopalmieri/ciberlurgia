import { describe, expect, it } from "vitest";
import { FICHAS, totalPrevisto } from "@/lib/abc";
import { CAMPOS_RESULTADO, EDITAIS_PNAB, PNAB_FONTE, PNAB_VERIFICACAO, RESULTADOS_COMPROVADOS, TOTAL_VAGAS_PNAB, filtrarEditais, quadroPNABCSV, vagasPrevistas } from "@/lib/pnab-santo-andre";

describe("PNAB Santo André — previsões, não resultados", () => {
  it("contém apenas os 12 editais anunciados 18 a 29/2026", () => {
    expect(EDITAIS_PNAB.map((e) => e.numero)).toEqual([18,19,20,21,22,23,24,25,26,27,28,29]);
  });
  const anuncios = [[18,16,50000],[19,15,50000],[20,6,15000],[21,5,15000],[22,25,15000],[23,15,15000],[24,5,15800],[25,5,15800],[26,6,125000],[27,7,90000],[29,4,16800]];
  it.each(anuncios)("edital %i preserva %i vagas previstas e valor unitário %i", (numero, vagas, valor) => {
    const e = EDITAIS_PNAB.find((x) => x.numero === numero);
    expect(e?.categorias).toHaveLength(1);
    expect(e?.categorias[0]?.vagas).toBe(vagas);
    expect(e?.categorias[0]?.valorUnitario).toBe(valor);
  });
  it("edital 28 tem 51 vagas previstas em quatro categorias, nunca 51 selecionados", () => {
    const e = EDITAIS_PNAB.find((x) => x.numero === 28);
    if (!e) throw new Error("Edital 28 obrigatório");
    expect(e.categorias.map((c) => [c.nome,c.vagas,c.valorUnitario])).toEqual([
      ["A1 — sem CNPJ",28,30000], ["A2 — sem CNPJ",6,30000], ["B1 — com CNPJ",15,50000], ["B2 — com CNPJ",2,50000],
    ]);
    expect(vagasPrevistas(e)).toBe(51);
  });
  it("soma 160 vagas PREVISTAS", () => expect(TOTAL_VAGAS_PNAB).toBe(160));
  it("resultados e pagos não comprovados são desconhecidos, nunca zero", () => {
    expect(RESULTADOS_COMPROVADOS).toEqual({ contemplados: null, suplentes: null, pagos: null });
  });
  it("preserva R$ 5.790.200 previstos e uma única ficha Santo André", () => {
    expect(totalPrevisto("Santo André")).toBe(5790200);
    expect(FICHAS.filter((f) => f.id === "sa-pnab-2026")).toHaveLength(1);
    expect(FICHAS.find((f) => f.id === "sa-pnab-2026")?.valores.pago).toBeUndefined();
  });
  it("usa somente URLs individuais fornecidas e página PNAB para as demais", () => {
    expect(EDITAIS_PNAB.map((e) => e.link)).toEqual([2427,2429,2431,2433,2435,null,null,null,null,2447,null,2451].map((id) => id === null ? PNAB_FONTE : `https://culturaz.santoandre.sp.gov.br/oportunidade/${id}/`));
  });
  it("data é a verificação do Observatório em 07/11/2026", () => expect(PNAB_VERIFICACAO).toBe("07/11/2026"));
  it("filtros combinam número e tipo sem alterar o catálogo", () => {
    expect(filtrarEditais("28", "Premiação").map((e) => e.numero)).toEqual([28]);
    expect(filtrarEditais("28", "Bolsa")).toEqual([]);
    expect(filtrarEditais("", "Bolsa").map((e) => e.numero)).toEqual([24,25,29]);
    expect(EDITAIS_PNAB).toHaveLength(12);
  });
  it("CSV Excel separa categorias, previsões e campos não verificados", () => {
    const csv = quadroPNABCSV();
    expect(csv.charCodeAt(0)).toBe(0xfeff);
    const lines = csv.slice(1).split("\r\n");
    expect(lines).toHaveLength(16); // header + 15 categories
    const rows = lines.slice(1).map((r) => r.slice(1,-1).split('";"'));
    expect(rows.reduce((sum,row) => sum + Number(row[5]),0)).toBe(160);
    for (const row of rows) {
      for (const field of row.slice(7,7 + CAMPOS_RESULTADO.length)) expect(field).toBe("N/D — não conferido documentalmente");
    }
    expect(quadroPNABCSV(filtrarEditais("29" )).split("\r\n")).toHaveLength(2);
  });
});