import { describe, it, expect } from "vitest";
import { sugerirMunicipios, statusIndicador, contadoresNacionais, type RegistroDC } from "@/lib/democracia";

const lista = [
  { id: 3547809, nome: "Santo André", uf: "SP", ufNome: "São Paulo", ufId: 35 },
  { id: 2513406, nome: "Santo André", uf: "PB", ufNome: "Paraíba", ufId: 25 },
];

describe("contador da democracia cultural", () => {
  it("sem UF não sugere", () => expect(sugerirMunicipios(lista, "", "santo")).toEqual([]));
  it("menos de 3 letras não sugere", () => expect(sugerirMunicipios(lista, "SP", "sa")).toEqual([]));
  it("san em SP acha só Santo André/SP", () => expect(sugerirMunicipios(lista, "SP", "san").map((m) => m.id)).toEqual([3547809]));
  it("padrão é não verificado", () => expect(statusIndicador(3547809, "conselho").status).toBe("nao_verificado"));
  it("registro sem fonte/atualização não conta", () => {
    const r: RegistroDC[] = [{ enteId: 1, indicador: "conselho", status: "instituido_legalmente", descricao: "Lei", fonte: "", link: "https://x.gov.br", data: "2024-01-01", atualizadoEm: "" }];
    expect(contadoresNacionais(r).registros).toBe(0);
    expect(statusIndicador(1, "conselho", r).status).toBe("nao_verificado");
  });
});
