import { describe, it, expect } from "vitest";
import { filtrar, statusGeral, contarAuditadas, type Evidencia } from "@/lib/marco";

const lista = [
  { id: 3547809, nome: "Santo André", uf: "SP", ufNome: "São Paulo" },
  { id: 2928901, nome: "Santo André", uf: "PB", ufNome: "Paraíba" },
  { id: 3550308, nome: "São Paulo", uf: "SP", ufNome: "São Paulo" },
];

describe("marco regulatório", () => {
  it("busca Santo André sem acento", () => {
    expect(filtrar(lista, "santo andre", "", "").length).toBe(2);
  });
  it("filtra por UF", () => {
    expect(filtrar(lista, "santo", "SP", "").map((m) => m.id)).toEqual([3547809]);
  });
  it("status padrão é não verificado", () => {
    expect(statusGeral(3547809)).toBe("nao_verificado");
  });
  it("contadores ignoram evidência não auditada", () => {
    const ev: Evidencia[] = [
      { municipioId: 1, item: "fundo", status: "verificado_existe", descricao: "x", link: "https://a.gov.br", data: "2025-01-01" },
    ];
    expect(contarAuditadas(ev).evidencias).toBe(0);
    expect(statusGeral(1, ev)).toBe("nao_verificado");
  });
});

import { buscaPronta } from "@/lib/marco";
describe("busca por UF + 3 letras", () => {
  it("exige UF", () => expect(buscaPronta("", "San")).toBe(false));
  it("exige 3 letras", () => expect(buscaPronta("SP", "Sa")).toBe(false));
  it("San em SP acha Santo André", () => {
    expect(buscaPronta("SP", "San")).toBe(true);
    expect(filtrar(lista, "San", "SP", "").map((m) => m.nome)).toContain("Santo André");
  });
});
