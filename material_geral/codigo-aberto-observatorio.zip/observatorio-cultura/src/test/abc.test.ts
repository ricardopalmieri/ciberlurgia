import { describe, it, expect } from "vitest";
import { FICHAS, corDa, fichasDa, totalPrevisto, CIDADES_ABC } from "@/lib/abc";

describe("Grande ABC", () => {
  it("tem as sete cidades", () => expect(CIDADES_ABC).toHaveLength(7));
  it("Santo André: previsto 5.790.200 e nada pago", () => {
    const f = FICHAS.find((x) => x.id === "sa-pnab-2026")!;
    expect(f.valores.previsto).toBe(5790200);
    expect(f.valores.pago).toBeUndefined();
    expect(f.bairro).toBeUndefined();
  });
  it("ficha parcial é amarela", () => expect(corDa(FICHAS[0]!)).toBe("amarelo"));
  it("bairro sem prova não retorna fichas", () => expect(fichasDa("Santo André", "Centro")).toHaveLength(0));
  it("total previsto não duplica", () => expect(totalPrevisto("Santo André")).toBe(5790200));
});
