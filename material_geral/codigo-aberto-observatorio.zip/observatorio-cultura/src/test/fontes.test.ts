import { describe, it, expect } from "vitest";
import { MEDIDORES } from "@/lib/fontes";
import { statusIndicador, type RegistroDC } from "@/lib/democracia";

describe("fontes e termômetro", () => {
  it("os seis medidores têm documento a coletar e fonte oficial", () => {
    for (const id of ["plano", "conselho", "fundo", "conferencias", "sistema", "lei"] as const) {
      expect(MEDIDORES[id].documento.length).toBeGreaterThan(10);
      expect(MEDIDORES[id].fontes.length).toBeGreaterThan(0);
    }
  });
  it("adesão ao SNC não muda Conselho, Plano nem Fundo", () => {
    const regs: RegistroDC[] = [{ enteId: 1, indicador: "sistema", status: "instituido_legalmente", descricao: "Adesão", link: "https://x", fonte: "MinC", data: "2020-01-01", atualizadoEm: "2026-10-27" } as RegistroDC];
    expect(statusIndicador(1, "sistema", regs).status).toBe("instituido_legalmente");
    for (const i of ["conselho", "plano", "fundo"] as const) expect(statusIndicador(1, i, regs).status).toBe("nao_verificado");
  });
  it("sem link e data o registro não conta", () => {
    const regs = [{ enteId: 1, indicador: "plano", status: "instituido_legalmente", descricao: "x", link: "", fonte: "MinC", data: "", atualizadoEm: "" }] as unknown as RegistroDC[];
    expect(statusIndicador(1, "plano", regs).status).toBe("nao_verificado");
  });
});
