import { useMemo, useState } from "react";
import { INSTRUMENTOS, registrosVerificados, filtrarRegs, entesCom, ufIdDe, type Instrumento } from "@/lib/brasil";
import { MEDIDORES } from "@/lib/fontes";
import { FONTES_ORC, FONTES_TRANSF } from "@/lib/financas";

type Ente = { id: number; uf: string; ufId: number; ufNome: string };
const fonteBtn = { display: "inline-block", padding: "8px 12px", border: "2px solid #111", borderRadius: 8, color: "#111", fontWeight: 700, fontSize: 13, textDecoration: "none", background: "#fff" } as const;
const campo = { background: "#fff", color: "#111", border: "2px solid #111", borderRadius: 10, padding: "8px 10px", fontSize: 15, width: "100%" } as const;
const td = { borderBottom: "1px solid #ccc", padding: "6px 8px", fontSize: 14 } as const;

export function VisaoBrasil({ lista, ufs, onVerUf }: { lista: Ente[]; ufs: [string, { nome: string; id: number }][]; onVerUf: (uf: string) => void }) {
  const [fUf, setFUf] = useState(""); const [fAno, setFAno] = useState(""); const [fInst, setFInst] = useState<Instrumento | "">("");
  const [ativo, setAtivo] = useState<Instrumento | null>(null);
  const regs = useMemo(registrosVerificados, []);
  const anos = [...new Set(regs.map((r) => r.ano).filter(Boolean))].sort();
  const ufId = ufs.find(([s]) => s === fUf)?.[1].id;
  const base = filtrarRegs(regs, { ufId, ano: fAno ? Number(fAno) : undefined });
  const totalEntes = fUf ? 1 + lista.filter((m) => m.uf === fUf).length : ufs.length + lista.length;
  const visiveis = INSTRUMENTOS.filter((i) => !fInst || i.id === fInst);
  const abrir = (id: Instrumento) => { setAtivo(ativo === id ? null : id); setTimeout(() => { const el = document.getElementById("br-detalhe"); el?.scrollIntoView({ behavior: "smooth", block: "start" }); el?.focus({ preventScroll: true }); }, 30); };
  const det = ativo ? base.filter((r) => r.instrumento === ativo) : [];
  const fontes = ativo === "orcamento" ? FONTES_ORC : ativo === "transferencias" ? FONTES_TRANSF : ativo ? MEDIDORES[ativo].fontes : [];

  return (
    <section aria-labelledby="br-t" style={{ margin: "20px 0", border: "2px solid #111", borderRadius: 14, padding: 16 }}>
      <h2 id="br-t" style={{ margin: "0 0 4px", fontSize: 20 }}>Termômetro das Políticas Culturais — Visão Brasil</h2>
      <p style={{ fontSize: 14, margin: "0 0 10px" }}><strong>Escopo: Brasil{fUf ? ` · filtro ${fUf}` : ""}</strong> — {ufs.length} UFs e {lista.length.toLocaleString("pt-BR")} municípios no cadastro IBGE. Contamos só registros com documento oficial verificado (link e data). <strong>Não é índice de cumprimento.</strong></p>
      <div style={{ display: "grid", gap: 10, gridTemplateColumns: "repeat(auto-fit, minmax(min(100%, 180px), 1fr))", marginBottom: 12 }}>
        <label style={{ fontWeight: 600, fontSize: 14 }}>UF<select value={fUf} onChange={(e) => setFUf(e.target.value)} style={campo}><option value="">Todas as 27</option>{ufs.map(([s, i]) => <option key={s} value={s}>{i.nome} ({s})</option>)}</select></label>
        <label style={{ fontWeight: 600, fontSize: 14 }}>Ano<select value={fAno} onChange={(e) => setFAno(e.target.value)} style={campo}><option value="">Todos</option>{anos.map((a) => <option key={a} value={a}>{a}</option>)}</select></label>
        <label style={{ fontWeight: 600, fontSize: 14 }}>Instrumento<select value={fInst} onChange={(e) => setFInst(e.target.value as Instrumento | "")} style={campo}><option value="">Todos os 8</option>{INSTRUMENTOS.map((i) => <option key={i.id} value={i.id}>{i.nome}</option>)}</select></label>
      </div>
      <div style={{ display: "grid", gap: 10, gridTemplateColumns: "repeat(auto-fit, minmax(min(100%, 160px), 1fr))" }}>
        {visiveis.map((i) => { const r = base.filter((x) => x.instrumento === i.id); const n = entesCom(r); const rot = n ? `${n} de ${totalEntes.toLocaleString("pt-BR")} entes com documento` : "Dados insuficientes";
          return <button key={i.id} type="button" aria-expanded={ativo === i.id} aria-controls="br-detalhe" aria-label={`${i.nome}: ${rot}. Ver detalhes`} onClick={() => abrir(i.id)}
            style={{ textAlign: "center", border: ativo === i.id ? "3px solid #111" : "1px solid #bbb", borderRadius: 12, padding: 10, background: ativo === i.id ? "#fff7d6" : "#fff", color: "#111", cursor: "pointer", minHeight: 0 }}>
            <strong style={{ display: "block" }}>{i.nome}</strong><span style={{ fontSize: 13 }}>{rot}</span><br /><span style={{ fontSize: 12 }}>Registros verificados: {r.length || "nenhum ainda"}</span>
            <span style={{ display: "block", fontSize: 11, textDecoration: "underline", marginTop: 4 }}>Ver detalhes</span></button>; })}
      </div>
      {ativo && (
        <div id="br-detalhe" role="region" tabIndex={-1} aria-label="Detalhes nacionais" style={{ marginTop: 12, border: "2px solid #111", borderRadius: 12, padding: 14 }}>
          <h3 style={{ margin: "0 0 6px" }}>{INSTRUMENTOS.find((i) => i.id === ativo)!.nome} — Brasil{fUf ? ` · ${fUf}` : ""}</h3>
          <p style={{ fontSize: 14, margin: "4px 0" }}><strong>Cobertura de verificação:</strong> {entesCom(det) ? `${entesCom(det)} de ${totalEntes.toLocaleString("pt-BR")} entes têm documento verificado.` : `Dados insuficientes — nenhum dos ${totalEntes.toLocaleString("pt-BR")} entes tem documento verificado ainda. Isso não significa ausência da política.`}</p>
          <p style={{ fontWeight: 700, margin: "10px 0 4px" }}>Situação por estado</p>
          <div style={{ overflowX: "auto", maxHeight: 320 }}><table style={{ borderCollapse: "collapse", width: "100%" }}><thead><tr><th style={td}>UF</th><th style={td}>Entes com documento</th><th style={td}></th></tr></thead><tbody>
            {ufs.filter(([s]) => !fUf || s === fUf).map(([s, i]) => { const n = entesCom(det.filter((r) => ufIdDe(r.enteId) === i.id));
              return <tr key={s}><td style={td}>{i.nome}</td><td style={td}>{n || "Dados insuficientes"}</td><td style={td}><button type="button" onClick={() => onVerUf(s)} style={{ minHeight: 0, padding: "4px 10px", borderRadius: 999, fontSize: 13 }}>Ver estado e municípios</button></td></tr>; })}
          </tbody></table></div>
          {det.length > 0 && <><p style={{ fontWeight: 700, margin: "10px 0 4px" }}>Documentos verificados</p><ul style={{ fontSize: 14 }}>{det.slice(0, 50).map((r) => <li key={r.link}><a href={r.link} target="_blank" rel="noopener noreferrer">{r.descricao}</a> — {r.fonte} · {r.data}</li>)}</ul></>}
          <p style={{ fontWeight: 700, margin: "10px 0 6px" }}>Consultar fonte oficial</p>
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>{fontes.map((f) => <a key={f.url} href={f.url} target="_blank" rel="noopener noreferrer" style={fonteBtn}>{f.nome} ↗</a>)}</div>
          <button type="button" onClick={() => setAtivo(null)} style={{ marginTop: 10, padding: "6px 14px", minHeight: 0, borderRadius: 999 }}>Fechar detalhes</button>
        </div>
      )}
    </section>
  );
}
