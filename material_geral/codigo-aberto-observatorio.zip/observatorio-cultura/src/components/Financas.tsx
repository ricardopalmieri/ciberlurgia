import { useState } from "react";
import { CAMPOS_ORC, CAMPOS_TRANSF, FONTES_ORC, FONTES_TRANSF, orcamentoDo, transferenciasDo, moeda } from "@/lib/financas";

type Ente = { tipo: "uf" | "municipio"; id: number; nome: string; uf: string } | null;
type Aba = "orc" | "transf";

const btn = (on: boolean) => ({ padding: "12px 18px", minHeight: 48, borderRadius: 10, fontWeight: 800, fontSize: 16, border: "2px solid #111", background: on ? "#111" : "#fff", color: on ? "#fff" : "#111", cursor: "pointer", flex: "1 1 220px" }) as const;
const fonteBtn = { display: "inline-block", padding: "8px 12px", border: "2px solid #111", borderRadius: 8, color: "#111", fontWeight: 700, fontSize: 13, textDecoration: "none", background: "#fff" } as const;
const th = { textAlign: "left", borderBottom: "2px solid #111", padding: "6px 8px", fontSize: 13 } as const;
const td = { borderBottom: "1px solid #ccc", padding: "6px 8px", fontSize: 14, verticalAlign: "top" } as const;
const NV = <strong>Não verificado</strong>;

export function Financas({ s }: { s: Ente }) {
  const [aba, setAba] = useState<Aba | null>(null);
  const abrir = (a: Aba) => {
    setAba(aba === a ? null : a);
    setTimeout(() => { const el = document.getElementById("fin-detalhe"); el?.scrollIntoView({ behavior: "smooth", block: "start" }); el?.focus({ preventScroll: true }); }, 30);
  };
  const nome = s ? (s.tipo === "uf" ? `Governo estadual · ${s.nome}` : `${s.nome} · ${s.uf}`) : "nenhum ente escolhido";
  const orc = s ? orcamentoDo(s.id) : [];
  const tr = s ? transferenciasDo(s.id) : [];
  const busca = (t: string) => "https://www.google.com/search?q=" + encodeURIComponent(`"${s?.nome ?? ""}" ${s?.uf ?? ""} ${t}`);

  return (
    <section aria-labelledby="fin-t" style={{ margin: "20px 0", border: "2px solid #111", borderRadius: 14, padding: 16 }}>
      <h2 id="fin-t" style={{ margin: "0 0 4px", fontSize: 20 }}>Orçamento e Transferências</h2>
      <p style={{ fontSize: 14, margin: "0 0 10px", fontWeight: 700 }}>Escopo: {nome}</p>
      <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
        <button type="button" className="mr-fin" aria-expanded={aba === "orc"} aria-controls="fin-detalhe" onClick={() => abrir("orc")} style={btn(aba === "orc")}>💰 Orçamento da Cultura</button>
        <button type="button" className="mr-fin" aria-expanded={aba === "transf"} aria-controls="fin-detalhe" onClick={() => abrir("transf")} style={btn(aba === "transf")}>🔁 Transferências de Recursos</button>
      </div>

      {aba && (
        <div id="fin-detalhe" role="region" tabIndex={-1} aria-label={aba === "orc" ? "Orçamento da Cultura" : "Transferências de Recursos"} style={{ marginTop: 12, border: "2px solid #111", borderRadius: 12, padding: 14, background: "#fff" }}>
          <h3 style={{ margin: "0 0 6px", fontSize: 18 }}>{aba === "orc" ? "💰 Orçamento da Cultura" : "🔁 Transferências de Recursos"} — {nome}</h3>
          {!s && <p style={{ fontSize: 14 }}>Escolha um Estado (e, se quiser, um Município) e clique em Buscar.</p>}
          <p style={{ margin: "6px 0 10px", padding: "8px 10px", border: "2px dashed #111", borderRadius: 8, fontSize: 14 }}>
            <strong>Valores sem documento oficial auditado aparecem como “Não verificado”</strong> — nunca como zero. Não há valores estimados nesta página.
          </p>

          {aba === "orc" ? (
            <div style={{ overflowX: "auto" }}>
              <table style={{ borderCollapse: "collapse", width: "100%", minWidth: 480 }}>
                <caption style={{ textAlign: "left", fontSize: 13, paddingBottom: 6 }}>Exercício: {orc[0]?.exercicio ?? "não verificado"}</caption>
                <thead><tr><th style={th}>Campo</th><th style={th}>Valor</th><th style={th}>Fonte / documento</th></tr></thead>
                <tbody>
                  {CAMPOS_ORC.map((c) => { const r = orc.find((x) => x.campo === c.id); return (
                    <tr key={c.id}><td style={td}>{c.nome}</td><td style={td}>{r ? moeda(r.valor) : NV}</td>
                      <td style={td}>{r ? <><a href={r.link} target="_blank" rel="noopener noreferrer">{r.descricao}</a><br />{r.fonte} · {r.data} · conferido {r.atualizadoEm}</> : "Pendente de coleta"}</td></tr>
                  ); })}
                </tbody>
              </table>
              <p style={{ fontSize: 14, margin: "10px 0 4px", fontWeight: 700 }}>Documento que precisa ser coletado</p>
              <p style={{ fontSize: 14, margin: 0 }}>LOA (função 13 – Cultura), Relatório Resumido da Execução Orçamentária (RREO) com empenhado/liquidado/pago, e lei e extrato do Fundo de Cultura.</p>
            </div>
          ) : (
            <div style={{ overflowX: "auto" }}>
              <table style={{ borderCollapse: "collapse", width: "100%", minWidth: 560 }}>
                <thead><tr><th style={th}>Origem → destino</th><th style={th}>Programa / modalidade</th>{CAMPOS_TRANSF.map((c) => <th key={c.id} style={th}>{c.nome}</th>)}<th style={th}>Data · comprovante</th></tr></thead>
                <tbody>
                  {tr.length ? tr.map((r, i) => (
                    <tr key={i}><td style={td}>{r.origem} → {r.destino}</td><td style={td}>{r.programa} · {r.modalidade}</td>
                      {CAMPOS_TRANSF.map((c) => <td key={c.id} style={td}>{r.campo === c.id ? moeda(r.valor) : NV}</td>)}
                      <td style={td}>{r.data} · <a href={r.link} target="_blank" rel="noopener noreferrer">{r.comprovante}</a></td></tr>
                  )) : (
                    <tr><td style={td}>União / Estado → {s ? (s.tipo === "uf" ? "Fundo Estadual" : "Fundo Municipal") : "—"} de Cultura</td><td style={td}>PNAB · {NV}</td>
                      {CAMPOS_TRANSF.map((c) => <td key={c.id} style={td}>{NV}</td>)}<td style={td}>Pendente de coleta</td></tr>
                  )}
                </tbody>
              </table>
              <p style={{ fontSize: 14, margin: "10px 0 4px" }}><strong>Vinculação ao Plano/metas:</strong> {tr.find((r) => r.vinculoPlano)?.vinculoPlano ?? "Não verificado"}</p>
              <p style={{ fontSize: 14, margin: "0 0 4px" }}><strong>Território atendido:</strong> {tr.find((r) => r.territorio)?.territorio ?? "Não verificado"}</p>
              <p style={{ fontSize: 14, margin: "10px 0 4px", fontWeight: 700 }}>Documento que precisa ser coletado</p>
              <p style={{ fontSize: 14, margin: 0 }}>Extrato do repasse (Portal da Transparência/Transferegov), plano de ação PNAB, editais e comprovantes de pagamento, com data.</p>
            </div>
          )}

          <p style={{ margin: "12px 0 6px", fontWeight: 700 }}>Consultar fonte oficial</p>
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
            {(aba === "orc" ? FONTES_ORC : FONTES_TRANSF).map((f) => <a key={f.url} href={f.url} target="_blank" rel="noopener noreferrer" style={fonteBtn}>{f.nome} ↗</a>)}
            {s && <a href={busca(aba === "orc" ? "orçamento cultura LOA RREO" : "PNAB repasse cultura")} target="_blank" rel="noopener noreferrer" style={fonteBtn}>Pesquisar documentos de {s.nome} ↗</a>}
          </div>
          <button type="button" onClick={() => setAba(null)} style={{ marginTop: 10, padding: "6px 14px", minHeight: 0, borderRadius: 999 }}>Fechar</button>
        </div>
      )}
    </section>
  );
}
