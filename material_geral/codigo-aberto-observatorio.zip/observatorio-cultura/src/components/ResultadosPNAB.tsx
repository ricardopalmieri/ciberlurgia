import { useState } from "react";
import { Download, ExternalLink, Printer, FileCheck2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { moedaABC, totalPrevisto } from "@/lib/abc";
import { CAMPOS_RESULTADO, EDITAIS_PNAB, PNAB_FONTE, PNAB_NOTICIA, PNAB_PROJETO, PNAB_VERIFICACAO, RESULTADOS_COMPROVADOS, TOTAL_VAGAS_PNAB, filtrarEditais, quadroPNABCSV, vagasPrevistas } from "@/lib/pnab-santo-andre";

export function ResultadosPNAB() {
  const [numero, setNumero] = useState("");
  const [tipo, setTipo] = useState("");
  const editais = filtrarEditais(numero, tipo);
  function baixarCSV() {
    const url = URL.createObjectURL(new Blob([quadroPNABCSV(editais)], { type: "text/csv;charset=utf-8" }));
    const a = document.createElement("a");
    a.href = url;
    a.download = "pnab-santo-andre-2026-acompanhamento-previsoes.csv";
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 30000);
  }
  return <section className="pnab-results space-y-6 py-6" aria-labelledby="pnab-titulo">
    <header className="space-y-3">
      <p className="text-sm font-bold uppercase">Transparência pública · Santo André</p>
      <h2 id="pnab-titulo" tabIndex={-1} className="text-2xl font-bold leading-tight md:text-3xl">Resultados da PNAB — Santo André | Ciclo 2 (2026)</h2>
      <p className="text-sm"><strong>Verificação do Observatório:</strong> {PNAB_VERIFICACAO}. Esta não é a data oficial de publicação dos resultados.</p>
    </header>

    <div role="note" className="border-l-4 border-foreground bg-pnab-pending p-4 space-y-2">
      <p className="font-bold">Listas nominais ainda não conferidas documentalmente pelo Observatório</p>
      <p>Não foi comprovada a lista nominal de classificação, contemplados e suplentes nesta verificação. Isso não significa que as listas não tenham sido publicadas. Os campos N/D aguardam conciliação documental, sem indicar ausência de ação ou irregularidade.</p>
      <p><strong>Vagas previstas não são contemplados selecionados. Verba prevista não é empenhada, liquidada ou paga.</strong></p>
    </div>

    <dl className="grid grid-cols-2 gap-x-5 gap-y-4 sm:grid-cols-3 lg:grid-cols-5">
      {[
        ["Editais anunciados", EDITAIS_PNAB.length], ["Vagas PREVISTAS", TOTAL_VAGAS_PNAB],
        ["Contemplados COMPROVADOS", RESULTADOS_COMPROVADOS.contemplados ?? "N/D"],
        ["Suplentes COMPROVADOS", RESULTADOS_COMPROVADOS.suplentes ?? "N/D"], ["Pagos", RESULTADOS_COMPROVADOS.pagos ?? "N/D"],
      ].map(([label, value]) => <div key={label} className="border-t-2 border-foreground pt-3 min-w-0"><dt className="text-sm font-semibold break-words">{label}</dt><dd className="mt-1 text-3xl font-bold">{value}</dd></div>)}
    </dl>

    <div className="space-y-2 border-y border-foreground py-4 text-sm">
      <p>Os editais 18/2026 a 29/2026 foram republicados após revisão. <strong>Registro existente do Observatório: {moedaABC(totalPrevisto("Santo André"))} PREVISTOS</strong>, contado uma única vez no Grande ABC.</p>
      <p>A notícia oficial menciona R$ 5,8 milhões; a página PNAB menciona aproximadamente R$ 6 milhões, com saldo remanescente. São referências arredondadas com contextos distintos, não valores exatos adicionais nem comprovação de pagamento.</p>
      <nav aria-label="Fontes gerais da PNAB" className="flex flex-wrap gap-x-5 gap-y-2 font-semibold underline">
        <a href={PNAB_FONTE} target="_blank" rel="noopener noreferrer">Prefeitura — PNAB ↗</a>
        <a href={PNAB_NOTICIA} target="_blank" rel="noopener noreferrer">Notícia oficial da republicação ↗</a>
        <a href={PNAB_PROJETO} target="_blank" rel="noopener noreferrer">Projeto no CulturAZ ↗</a>
      </nav>
    </div>

    <div className="pnab-no-print grid gap-3 sm:grid-cols-2">
      <label className="font-bold">Número do edital<select aria-label="Número do edital" className="pnab-field mt-1" value={numero} onChange={(e) => setNumero(e.target.value)}><option value="">Todos os editais</option>{EDITAIS_PNAB.map((e) => <option key={e.numero} value={e.numero}>{e.numero}/2026</option>)}</select></label>
      <label className="font-bold">Tipo de edital<select aria-label="Tipo de edital" className="pnab-field mt-1" value={tipo} onChange={(e) => setTipo(e.target.value)}><option value="">Todos os tipos</option>{["Fomento", "Premiação", "Bolsa"].map((t) => <option key={t}>{t}</option>)}</select></label>
      <div className="flex flex-wrap gap-3 sm:col-span-2">
        <Button type="button" variant="outline" className="pnab-control" onClick={() => { setNumero(""); setTipo(""); }}>Limpar filtros</Button>
        <Button type="button" variant="outline" className="pnab-control" disabled={!editais.length} onClick={baixarCSV}><Download /> Baixar quadro CSV</Button>
        <Button type="button" variant="outline" className="pnab-control" onClick={() => window.print()}><Printer /> Imprimir / salvar PDF</Button>
      </div>
    </div>
    <p role="status" className="text-sm">{editais.length} de 12 editais nesta consulta. Quadro de acompanhamento de previsões — não é resultado homologado. CSV e impressão respeitam os filtros.</p>
    <p className="text-sm">Legenda documental: <span className="pnab-status bg-pnab-confirmed">Verde: conferido</span> <span className="pnab-status bg-pnab-pending">Amarelo: conciliação pendente</span> <span className="pnab-status bg-pnab-missing">Vermelho: sem prova cadastrada</span>. As cores não indicam irregularidade; os resultados nominais seguem N/D.</p>

    <div className="grid gap-4 md:grid-cols-2">
      {editais.map((e) => <article key={e.numero} className="pnab-edital rounded-lg border-2 border-foreground p-4 space-y-3" aria-labelledby={`pnab-edital-${e.numero}`}>
        <p className="text-sm font-bold">EDITAL {e.numero}/2026 · {e.tipo}</p>
        <h3 id={`pnab-edital-${e.numero}`} className="text-xl font-bold leading-snug">{e.titulo}</h3>
        <p><strong>{vagasPrevistas(e)} vagas PREVISTAS</strong> — não são selecionados comprovados.</p>
        <ul className="space-y-1 text-sm">{e.categorias.map((c) => <li key={c.nome}>{c.nome}: <strong>{c.vagas} vagas</strong> · {moedaABC(c.valorUnitario)} por vaga, <strong>PREVISTOS</strong>.</li>)}</ul>
        <p className="text-sm font-semibold flex gap-2 items-center"><FileCheck2 size={18} aria-hidden="true" /> Previsões: página oficial PNAB</p>
        <p className="pnab-status bg-pnab-pending text-sm">Resultados: conciliação documental pendente</p>
        <dl className="text-sm">{CAMPOS_RESULTADO.map((campo) => <div key={campo} className="flex items-start justify-between gap-3 border-t border-foreground/20 py-2"><dt>{campo}</dt><dd className="font-bold shrink-0">N/D</dd></div>)}</dl>
        <Button asChild variant="outline" className="pnab-control w-full"><a href={e.link} target="_blank" rel="noopener noreferrer" aria-label={`Ver fonte oficial do edital ${e.numero}/2026`}>Ver fonte oficial <ExternalLink /></a></Button>
        <p className="text-xs">N/D = não conferido documentalmente. Verificação do Observatório: {PNAB_VERIFICACAO}.</p>
      </article>)}
    </div>
    {!editais.length && <p role="status" className="border border-dashed border-foreground p-4">Nenhum edital corresponde à combinação dos filtros. As listas nominais continuam não conferidas.</p>}
  </section>;
}