"""Visão Brasil/Estado/Município (desktop e celular). Uso: python3 tests/e2e/brasil.py [URL]"""
import asyncio, sys
from playwright.async_api import async_playwright
BASE = sys.argv[1] if len(sys.argv) > 1 else "http://localhost:8080"
DATA=[{"municipio-id":3547809,"municipio-nome":"Santo André","UF-id":35,"UF-sigla":"SP","UF-nome":"São Paulo"},{"municipio-id":2513406,"municipio-nome":"Santo André","UF-id":25,"UF-sigla":"PB","UF-nome":"Paraíba"}]
async def run(b,w,h):
    pg=await b.new_page(viewport={"width":w,"height":h}); errs=[]; pg.on("pageerror",lambda e: errs.append(str(e)))
    await pg.route("**/servicodados.ibge.gov.br/**",lambda r: r.fulfill(json=DATA))
    await pg.goto(BASE+"/marco-regulatorio"); await pg.wait_for_timeout(1500)
    assert await pg.locator("#br-t").is_visible()
    for n in ["Plano","Conselho","Fundo","Conferência","Sistema","Marco Regulatório","Orçamento da Cultura","Transferências de Recursos"]:
        await pg.get_by_role("button",name=f"{n}: Dados insuficientes").click(); await pg.wait_for_timeout(500)
        t=await pg.locator("#br-detalhe").inner_text(); assert n in t and "Dados insuficientes" in t and "Consultar fonte oficial" in t, n
        await pg.get_by_role("button",name="Fechar detalhes").click()
    await pg.get_by_role("button",name="Estado",exact=True).click(); await pg.select_option("select#sel-uf","SP"); await pg.get_by_role("button",name="🔍 Buscar").click(); await pg.wait_for_timeout(400)
    assert "Governo estadual · São Paulo" in await pg.locator("#termo-t + p").inner_text()
    await pg.fill("#busca-municipio","San"); await pg.get_by_role("option",name="Santo André").click(); await pg.get_by_role("button",name="🔍 Buscar").click(); await pg.wait_for_timeout(400)
    assert "Município de Santo André" in await pg.locator("#termo-t + p").inner_text()
    await pg.get_by_role("button",name="💰 Orçamento da Cultura").click(); await pg.wait_for_timeout(400); assert "Santo André" in await pg.locator("#fin-detalhe").inner_text()
    await pg.get_by_role("button",name="🇧🇷 Brasil").click(); await pg.wait_for_timeout(300); assert await pg.locator("#br-t").is_visible()
    assert "%" not in await pg.locator("main").inner_text() and not errs, errs
    print("ok",w)
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(headless=True); await run(b,1280,900); await run(b,390,844); await b.close(); print("TODOS OK")
asyncio.run(main())
