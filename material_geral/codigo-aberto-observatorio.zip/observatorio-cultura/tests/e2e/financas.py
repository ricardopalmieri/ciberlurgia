"""Teste dos botões Orçamento e Transferências (desktop, celular, teclado). Uso: python3 tests/e2e/financas.py [URL]"""
import asyncio, sys
from playwright.async_api import async_playwright
BASE = sys.argv[1] if len(sys.argv) > 1 else "http://localhost:8080"
DATA=[{"municipio-id":3547809,"municipio-nome":"Santo André","UF-id":35,"UF-sigla":"SP","UF-nome":"São Paulo"}]
async def run(b, w, h):
    pg = await b.new_page(viewport={"width":w,"height":h}); errs=[]
    pg.on("pageerror", lambda e: errs.append(str(e)))
    await pg.route("**/servicodados.ibge.gov.br/**", lambda r: r.fulfill(json=DATA))
    await pg.goto(BASE + "/marco-regulatorio"); await pg.wait_for_timeout(1500)
    await pg.select_option("select","SP"); await pg.fill("#busca-municipio","San")
    await pg.get_by_role("option", name="Santo André").click()
    await pg.get_by_role("button", name="🔍 Buscar").click(); await pg.wait_for_timeout(500)
    await pg.get_by_role("button", name="💰 Orçamento da Cultura").click(); await pg.wait_for_timeout(700)
    d = pg.locator("#fin-detalhe"); t = await d.inner_text(); box = await d.bounding_box()
    assert "Santo André · SP" in t and "Dotação na LOA" in t and "Não verificado" in t and "Siconfi" in t, t
    assert box["y"] < h, box
    await pg.get_by_role("button", name="🔁 Transferências de Recursos").focus(); await pg.keyboard.press("Enter"); await pg.wait_for_timeout(700)
    t = await d.inner_text()
    assert "PNAB" in t and "Valor repassado" in t and "Vinculação ao Plano" in t and "Território" in t and "Portal da Transparência" in t, t
    assert await pg.evaluate("document.activeElement.id") == "fin-detalhe"
    txt = await pg.locator("main").inner_text()
    assert "R$" not in txt and "%" not in txt, "valor inventado"
    assert await pg.get_by_role("button", name="Plano:").count() == 1 and await pg.get_by_role("button", name="Marco Regulatório:").count() == 1
    assert not errs, errs
    await pg.screenshot(path=f"/tmp/fin_{w}.png"); print("ok", w)
async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(headless=True)
        await run(b, 1280, 900); await run(b, 390, 844); await b.close(); print("TODOS OK")
asyncio.run(main())
