"""Teste de interação do Termômetro (desktop 1280x900). Uso: python3 tests/e2e/termometro_desktop.py [URL]
IBGE simulado com 3 municípios reais, para não depender da rede."""
import asyncio, sys
from playwright.async_api import async_playwright
BASE = sys.argv[1] if len(sys.argv) > 1 else "http://localhost:8080"
DATA=[{"municipio-id":3547809,"municipio-nome":"Santo André","UF-id":35,"UF-sigla":"SP","UF-nome":"São Paulo"},{"municipio-id":3548500,"municipio-nome":"Santos","UF-id":35,"UF-sigla":"SP","UF-nome":"São Paulo"},{"municipio-id":2513406,"municipio-nome":"Santo André","UF-id":25,"UF-sigla":"PB","UF-nome":"Paraíba"}]
NOMES=["Plano","Conselho","Fundo","Conferência","Sistema","Marco Regulatório"]
async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(headless=True)
        pg = await b.new_page(viewport={"width":1280,"height":900}); errs=[]
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.route("**/servicodados.ibge.gov.br/**", lambda r: r.fulfill(json=DATA))
        await pg.goto(BASE + "/marco-regulatorio"); await pg.wait_for_timeout(1500)
        await pg.select_option("select","SP"); await pg.fill("#busca-municipio","San"); await pg.wait_for_timeout(200)
        await pg.get_by_role("option", name="Santo André").click()
        await pg.get_by_role("button", name="🔍 Buscar").click(); await pg.wait_for_timeout(500)
        assert "Santo André · SP" in await pg.locator("#termo-t + p").inner_text()
        for n in NOMES:
            await pg.get_by_role("button", name=f"{n}:").click(); await pg.wait_for_timeout(700)
            det = pg.locator("#termo-detalhe")
            assert n in await det.locator("h3").inner_text(), n
            box = await det.bounding_box(); assert box and box["y"] < 900 and box["y"] + 40 > 0, f"{n} fora da tela {box}"
            assert await pg.evaluate("document.activeElement.id") == "termo-detalhe"
            t = await det.inner_text()
            assert "Documento que precisa ser coletado" in t and "Consultar fonte oficial" in t and "Não verificado" in t
            print("ok", n)
        assert "%" not in await pg.locator("main").inner_text()
        assert not errs, errs
        print("TODOS OK"); await b.close()
asyncio.run(main())
