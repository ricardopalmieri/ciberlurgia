import asyncio, csv
from pathlib import Path
from playwright.async_api import async_playwright

OUT = Path('/tmp/browser/pnab')
async def main():
 async with async_playwright() as p:
  browser = await p.chromium.launch(headless=True)
  for width,height in [(1280,1800),(390,844)]:
   page = await browser.new_page(viewport={'width':width,'height':height})
   errors=[]
   page.on('pageerror',lambda e: errors.append(str(e)))
   await page.goto('http://localhost:8080/grande-abc',wait_until='networkidle')
   await page.wait_for_function("Array.from(document.querySelectorAll('button')).some(b => b.textContent.includes('Resultados PNAB Santo André') && Object.keys(b).some(k => k.startsWith('__reactProps')))")
   await page.get_by_role('button',name='Resultados PNAB Santo André — 2026',exact=True).click()
   await page.get_by_role('heading',name='Resultados da PNAB — Santo André | Ciclo 2 (2026)',exact=True).wait_for()
   assert await page.locator('.pnab-edital').count()==12
   assert await page.evaluate('document.documentElement.scrollWidth <= innerWidth'), 'horizontal overflow'
   await page.screenshot(path=str(OUT/f'{width}_overview.png'))
   await page.get_by_label('Número do edital',exact=True).select_option('28')
   assert await page.locator('.pnab-edital').count()==1
   assert '51 vagas PREVISTAS' in await page.locator('.pnab-edital').inner_text()
   await page.locator('.pnab-edital').screenshot(path=str(OUT/f'{width}_edital28.png'))
   await page.get_by_label('Tipo de edital',exact=True).select_option('Bolsa')
   assert await page.locator('.pnab-edital').count()==0
   await page.get_by_role('button',name='Limpar filtros').click()
   assert await page.locator('.pnab-edital').count()==12
   async with page.expect_download() as download:
    await page.get_by_role('button',name='Baixar quadro CSV').click()
   saved = OUT/f'{width}_previsoes.csv'
   await (await download.value).save_as(saved)
   with saved.open(encoding='utf-8-sig',newline='') as f: rows=list(csv.reader(f,delimiter=';'))
   assert len(rows)==16
   assert sum(int(r[5]) for r in rows[1:])==160
   assert all(r[8]=='N/D — não conferido documentalmente' for r in rows[1:])
   await page.get_by_label('Número do edital',exact=True).select_option('29')
   async with page.expect_download() as download:
    await page.get_by_role('button',name='Baixar quadro CSV').click()
   await (await download.value).save_as(OUT/f'{width}_filtered.csv')
   assert len((OUT/f'{width}_filtered.csv').read_text().splitlines())==2
   await page.evaluate('window.print = () => { window.__printCalled = true; }')
   await page.get_by_role('button',name='Imprimir / salvar PDF').click()
   assert await page.evaluate('window.__printCalled')
   await page.emulate_media(media='print')
   await page.screenshot(path=str(OUT/f'{width}_print.png'))
   await page.emulate_media(media='screen')
   await page.get_by_role('tab',name='Escolha sua cidade',exact=True).click()
   await page.get_by_role('combobox').first.select_option('Santo André')
   assert 'R$ 5.790.200,00' in (await page.get_by_role('tabpanel').inner_text()).replace('\xa0',' ')
   await page.get_by_role('tab',name='Dinheiro da cultura',exact=True).click()
   assert 'R$ 5.790.200,00' in (await page.get_by_role('tabpanel').inner_text()).replace('\xa0',' ')
   await page.get_by_role('tab',name='Dinheiro da cultura',exact=True).press('End')
   assert await page.get_by_role('tab',name='Resultados PNAB',exact=True).get_attribute('aria-selected')=='true'
   await page.get_by_role('tab',name='Projetos e Resultados',exact=True).click()
   await page.get_by_role('button',name='Pesquisar').click()
   assert await page.get_by_role('heading',name='PNAB — ciclo 2 (2026): 12 editais').count()==1
   await page.get_by_role('textbox').fill('Centro')
   await page.get_by_role('button',name='Pesquisar').click()
   assert 'Não atribuímos bairros sem prova.' in (await page.get_by_role('tabpanel').inner_text()).replace('\xa0',' ')
   await page.reload(wait_until='networkidle')
   assert await page.get_by_role('button',name='Resultados PNAB Santo André — 2026').count()==1
   assert not errors, errors
   print(f'{width}px: 12 editais, filtro, CSV 160 vagas, impressão, teclado, abas e pesquisa antigos OK; erros: {len(errors)}')
   await page.close()
  await browser.close()
asyncio.run(main())
