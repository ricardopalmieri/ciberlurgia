# Fontes e limites dos dados

## Licenças
- **Código:** MIT (`LICENSE`).
- **Organização e textos produzidos pelo Observatório** (estrutura das fichas, rótulos, notas explicativas): CC BY 4.0 — cite "Observatório da Cultura Municipal — Sarau na Quebrada".
- **Dados e documentos oficiais** (editais, valores, listas de municípios do IBGE etc.): continuam com a fonte e a licença originais. Este projeto NÃO os relicencia; apenas os referencia com link.
- **Vídeos:** o pacote traz só os arquivos-ponteiro (`src/assets/*.asset.json`) com o endereço onde os episódios estão hospedados; os vídeos em si não são redistribuídos.
- **Imagens e vídeos** (Fusca, marca, ícones, séries Neri, Piquena e Gláucia e A Potência de Antônio): não incluídos; direitos reservados aos autores.

## Bases em `dados/`
| Arquivo | Conteúdo | Limite |
|---|---|---|
| pnab-santo-andre-editais-previstos.* | 12 editais, vagas e valores PREVISTOS (Prefeitura de Santo André) | Não é lista de contemplados, suplentes nem pagamentos; resultados nominais não conferidos |
| grande-abc-fichas.json | Fichas do Grande ABC | Valor previsto ≠ pago; bairro só com prova |
| marco-regulatorio-evidencias.json | Itens da Lei 14.903/2024 e evidências auditadas | Lista vazia = não verificado |
| democracia-cultural-registros.json | Indicadores e registros de conselhos/planos/fundos | Lista vazia = não verificado |
| financas.json | Orçamento e transferências | Lista vazia = não verificado, nunca zero |
| fontes-oficiais.json | Onde procurar cada documento | Um link de fonte não muda nenhum status |

Municípios e estados vêm, no site, da API pública do IBGE (servicodados.ibge.gov.br), consultada ao vivo; não estão copiados no pacote.

## Cuidados
- Não há banco de dados online; os dados ficam em arquivos `src/lib/*.ts`.
- Endereço do proponente não comprova o lugar de execução.
- Ausência de documento significa necessidade de conciliação documental, não irregularidade.
