<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Marco Regulatório evidence lives only in src/lib/marco.ts EVIDENCIAS; counters/status count only entries with auditadoEm + link, so nothing is shown as verified without audited proof.
- Contador da Democracia Cultural lives inside /marco-regulatorio (unified panel; /contador-democracia redirects). Its evidence lives only in src/lib/democracia.ts REGISTROS; a record counts only with link, fonte, data and atualizadoEm, and missing data is shown as "não verificado", never as absence.
- Official-source links and the document required per Termômetro gauge live only in src/lib/fontes.ts; they never change a status (only audited REGISTROS/EVIDENCIAS do), so no data is inferred from a source link. Desktop interaction test: tests/e2e/termometro_desktop.py.
- Orçamento/Transferências records live only in src/lib/financas.ts (ORCAMENTO, TRANSFERENCIAS); a value shows only with link, fonte, data and atualizadoEm, otherwise "Não verificado" (never zero). E2E: tests/e2e/financas.py.
- Grande ABC lives in src/lib/abc.ts FICHAS; a stage shows only with official source, else N/D; city totals count each ficha once (no per-bairro double count).
- PNAB announced opportunities live separately in src/lib/pnab-santo-andre.ts and render through ResultadosPNAB inside Grande ABC; they never enter FICHAS or financial totals, preventing forecasts from becoming beneficiary/payment evidence or duplicate sums.
- Open-source package: scripts/gerar-pacote.mjs (run with bun) builds the reproducible public/downloads/codigo-aberto-observatorio.zip from an allowlist plus pacote/ docs; images/videos/env are excluded for rights/secrecy. Re-run it after changing code or data so the download stays current; src/test/pacote-zip.test.ts checks contents.
