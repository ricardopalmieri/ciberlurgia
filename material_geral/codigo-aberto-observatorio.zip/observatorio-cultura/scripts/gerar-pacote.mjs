// Gera public/downloads/codigo-aberto-observatorio.zip de forma reproduzível.
// Uso: bun scripts/gerar-pacote.mjs   (requer o comando "zip" instalado)
import { execFileSync } from "node:child_process";
import { cpSync, mkdirSync, rmSync, writeFileSync, readdirSync, statSync, utimesSync, readFileSync, existsSync } from "node:fs";
import { createHash } from "node:crypto";
import { join, relative } from "node:path";

export const VERSAO = "1.0.0";
const RAIZ = process.cwd();
const SAIDA = join(RAIZ, "public/downloads");
const ZIP = join(SAIDA, "codigo-aberto-observatorio.zip");
const STAGE = "/tmp/pacote-observatorio/observatorio-cultura";

// Somente código, configs e documentação. Imagens e vídeos ficam de fora (direitos reservados aos autores).
const INCLUIR = ["src", "scripts", "tests", "pacote", "public/app.js", "public/sw.js", "public/manifest.webmanifest", "public/robots.txt",
  "package.json", "bun.lock", "bunfig.toml", "tsconfig.json", "vite.config.ts", "vitest.config.ts", "eslint.config.js", "components.json", ".prettierrc", ".prettierignore", "AGENTS.md"];
const PROIBIDO = /(^|\/)(node_modules|\.git|\.env[^/]*|\.lovable|dist|\.output)(\/|$)|\.(png|jpe?g|gif|webp|mp4|mov|ico|zip)$/i;

rmSync("/tmp/pacote-observatorio", { recursive: true, force: true });
mkdirSync(STAGE, { recursive: true });
for (const p of INCLUIR) if (existsSync(join(RAIZ, p)))
  cpSync(join(RAIZ, p), join(STAGE, p), { recursive: true, filter: (s) => !PROIBIDO.test(relative(RAIZ, s)) });
// Documentos da raiz do pacote
for (const f of readdirSync(join(RAIZ, "pacote"))) cpSync(join(RAIZ, "pacote", f), join(STAGE, f));
rmSync(join(STAGE, "pacote"), { recursive: true, force: true });

// Bases públicas exportadas dos arquivos de dados (somente o que já existe; vazio = ainda não verificado).
const dados = join(STAGE, "dados");
mkdirSync(dados, { recursive: true });
const abc = await import(join(RAIZ, "src/lib/abc.ts"));
const pnab = await import(join(RAIZ, "src/lib/pnab-santo-andre.ts"));
const marco = await import(join(RAIZ, "src/lib/marco.ts"));
const dem = await import(join(RAIZ, "src/lib/democracia.ts"));
const fin = await import(join(RAIZ, "src/lib/financas.ts"));
const fontes = await import(join(RAIZ, "src/lib/fontes.ts"));
const j = (n, v) => writeFileSync(join(dados, n), JSON.stringify(v, null, 2) + "\n");
j("grande-abc-fichas.json", abc.FICHAS);
j("pnab-santo-andre-editais-previstos.json", { aviso: "Previsões anunciadas. NÃO são contemplados, suplentes nem pagamentos.", fonte: pnab.PNAB_FONTE, verificadoEm: pnab.PNAB_VERIFICACAO, editais: pnab.EDITAIS_PNAB, resultadosComprovados: pnab.RESULTADOS_COMPROVADOS });
writeFileSync(join(dados, "pnab-santo-andre-editais-previstos.csv"), pnab.quadroPNABCSV());
j("marco-regulatorio-evidencias.json", { itens: marco.ITENS, evidencias: marco.EVIDENCIAS });
j("democracia-cultural-registros.json", { indicadores: dem.INDICADORES, registros: dem.REGISTROS });
j("financas.json", { orcamento: fin.ORCAMENTO, transferencias: fin.TRANSFERENCIAS });
j("fontes-oficiais.json", fontes.MEDIDORES);

// Checksums e datas fixas para ZIP reproduzível
const arquivos = [];
const andar = (d) => { for (const n of readdirSync(d).sort()) { const p = join(d, n); statSync(p).isDirectory() ? andar(p) : arquivos.push(p); } };
andar(STAGE);
const sha = (b) => createHash("sha256").update(b).digest("hex");
writeFileSync(join(STAGE, "SHA256SUMS.txt"), arquivos.map((p) => `${sha(readFileSync(p))}  ${relative(STAGE, p)}`).join("\n") + "\n");
const fixo = new Date("2026-01-01T00:00:00Z");
andar(STAGE); // inclui SHA256SUMS
for (const p of [...new Set(arquivos)]) utimesSync(p, fixo, fixo);
const lista = [...new Set(arquivos)].map((p) => relative("/tmp/pacote-observatorio", p)).sort();
mkdirSync(SAIDA, { recursive: true });
rmSync(ZIP, { force: true });
execFileSync("zip", ["-X", "-q", "-D", ZIP, "-@"], { cwd: "/tmp/pacote-observatorio", input: lista.join("\n") });
const h = sha(readFileSync(ZIP));
writeFileSync(ZIP + ".sha256", `${h}  codigo-aberto-observatorio.zip\n`);
writeFileSync(join(SAIDA, "pacote-info.json"), JSON.stringify({ versao: VERSAO, arquivo: "codigo-aberto-observatorio.zip", sha256: h, bytes: statSync(ZIP).size, arquivos: lista.length }, null, 2) + "\n");
console.log(`ZIP v${VERSAO}: ${lista.length} arquivos, sha256 ${h}`);
