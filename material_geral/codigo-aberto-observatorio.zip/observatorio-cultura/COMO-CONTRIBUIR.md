# Como contribuir

1. Baixe o ZIP, altere sua cópia e teste (`bunx vitest run`).
2. Envie sua sugestão ao Sarau na Quebrada com: o que mudou, por quê e os arquivos alterados.
3. Dados novos só entram com **documento oficial**: link, nome da fonte, data do documento e data em que você conferiu.

Regras do Observatório:
- Nunca inventar nomes, notas, classificações, bairros, pagamentos ou indicadores.
- Falta de documento é "N/D" / "Não verificado" — não é prova de ausência nem de irregularidade.
- Valor previsto não é valor pago. Endereço do proponente não prova o local de execução.
- Não envie dados pessoais sensíveis (CPF, CNPJ de pessoa física, telefone, endereço particular).
- Não envie imagens, vídeos ou textos de terceiros sem autorização de redistribuição.

Só pessoas com acesso de manutenção podem aplicar mudanças no site publicado.
