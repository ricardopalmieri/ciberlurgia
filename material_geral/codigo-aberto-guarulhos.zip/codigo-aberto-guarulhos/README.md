# Observatório da Cultura de Guarulhos | Agenda Cidadã

Observatório cidadão **independente**, não oficial. Sem servidor: anotações ficam no `localStorage` do aparelho (chave `ocg-agenda-cidada-v1`); não há banco comunitário compartilhado.

## Instalar e alterar (sua cópia)
1. Instale o Bun (https://bun.sh). 2. Na pasta: `bun install` e `bun run dev` → abra http://localhost:8080.
3. Dados e textos: `src/lib/data.ts` (todo fato com link e data). Páginas: `src/routes/`.
4. Testes: `bun run test`. Gerar o pacote: `python3 scripts/gerar_pacote.py` e conferir: `python3 scripts/testar_pacote.py`.
Licenças: código MIT (`LICENSE`); textos próprios CC BY 4.0 (`LICENCA-DADOS.md`). Ver também `COMO-CONTRIBUIR.md` e `FONTES-E-LIMITES-DOS-DADOS.md`.
Alterar sua cópia não dá permissão de editar o site original.

## Pacote código aberto (16/11/2026)
- ZIP gerado de forma reprodutível (datas fixas, ordem alfabética): duas gerações seguidas dão o mesmo sha256.
- O gerador bloqueia o pacote se achar padrão de CPF, CNPJ, chave privada, token, e-mail ou telefone; exclui `.env`, `.git`, `node_modules`, `.lovable`.
- Não contém dados do navegador (localStorage) nem PDFs de terceiros — só links.
- Nomes da mesa do CMPC constam por serem ato oficial publicado (fonte citada).
- Não verificado: instalação do zero em outro computador.

## Relatório técnico – rodada de 16/11/2026 (não publicado)

### Validado
- TypeScript (`tsgo -b --noEmit`): sem erros (erro anterior em `busca.tsx` corrigido).
- Testes automatizados (`bunx vitest run`): 17 aprovados — 12 rotas existem; validação de backup (JSON inválido, formato estranho, projetos corrompidos, resumo de conteúdo).
- Navegador (Playwright) em 360, 390, 412 e 1280 px: as 12 rotas abrem, sem rolagem horizontal, sem erros de execução.
- Busca global por termo sem acento ("orcamento") retorna resultados; termo inexistente mostra orientação didática e botão "Limpar filtros".
- Agenda: marcar compromisso → exportar backup JSON → importar (com resumo e confirmação) → recarregar: dado preservado.

### Mudanças
- Menu de seções quebra em linhas (todas visíveis, sem rolagem escondida).
- Aviso "suas anotações ficam só neste aparelho" na Agenda e Territórios.
- Importação valida o arquivo, mostra o que contém e o que será substituído. Falha de gravação avisa o usuário; dado ilegível é copiado em vez de apagado.
- Nova página **Rastro do Dinheiro** (`/rastro`): 8 etapas; "DADO REAL com fonte" só onde há registro com link; demais etapas "não verificado"; exemplo didático rotulado como não real.

### Sem conferência
- Leitor de telas real (TalkBack/NVDA) e Android físico: não testados (só emulação de largura).
- Contraste medido por ferramenta automática: não executado; cores seguem tokens planejados para AA.
- Links externos das fontes: não verificados quanto a disponibilidade atual.
- Divisão de metas por eixo e títulos das metas: conferir no Plano oficial.
- Liquidação, pagamento por edital, bairro de execução e resultados: sem documento.
- Impressão: botão chama `window.print()`; layout impresso não inspecionado.
