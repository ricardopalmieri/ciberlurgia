# Licenças – o que é de quem

| Conteúdo | Licença |
|---|---|
| Código (pasta `src/`, `scripts/`, configs) | MIT (arquivo `LICENSE`) |
| Textos próprios, resumos, glossário, Agenda Cidadã, roteiro de aula, metodologia de completude | Creative Commons Atribuição 4.0 (CC BY 4.0) – https://creativecommons.org/licenses/by/4.0/deed.pt-br |
| Documentos oficiais (leis, Diário Oficial, Plano Municipal, editais) | Atos oficiais; o pacote traz só **links**, não cópias. Leis e atos oficiais não têm proteção de direito autoral (Lei 9.610/1998, art. 8º, IV), mas confira cada fonte. |
| Sites de terceiros (Escavador, Lupa Municipal, etc.) | Direitos dos próprios sites. O pacote traz só **links** e valores citados com crédito. |

Atribuição sugerida: "Observatório da Cultura de Guarulhos | Agenda Cidadã (iniciativa cidadã independente), CC BY 4.0".
