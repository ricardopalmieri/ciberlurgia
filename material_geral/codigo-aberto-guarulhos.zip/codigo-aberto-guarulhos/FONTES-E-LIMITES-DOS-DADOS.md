# Fontes e limites dos dados

- Pesquisa inicial: 01/11/2026. Todos os fatos ficam em `src/lib/data.ts`, cada um com link e data da fonte.
- **Fonte oficial** = site da Prefeitura, Diário Oficial, MinC. **Fonte secundária** = transcrições (Escavador) e agregadores (Lupa Municipal/TCE-SP). Secundárias precisam ser confirmadas no original.
- Valores da PNAB no site são **previstos/planejados** (planos de ação e editais). Pagamentos, contratações e resultados de editais: **não verificados**.
- Despesa da função Cultura 2025 (empenhado/pago) vem de fonte secundária e é total da cidade, não por projeto.
- Liquidação, bairro real de execução e resultados comprovados: sem documento até agora.
- Títulos e eixos de algumas metas do Plano: conferir no PDF oficial.
- Links externos não foram reconferidos depois da pesquisa inicial; podem mudar.
- O pacote **não** contém dados digitados por usuários (ficam só no navegador de cada pessoa) nem cópias de documentos de terceiros.
