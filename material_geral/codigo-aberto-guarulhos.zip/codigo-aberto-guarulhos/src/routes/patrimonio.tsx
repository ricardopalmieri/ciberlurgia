import { createFileRoute } from "@tanstack/react-router";
import { ListaTema } from "@/components/ListaTema";
import { Cartao, Fontes, Pagina } from "@/components/ui-obs";
import { EQUIPAMENTOS, F } from "@/lib/data";
import { head } from "@/lib/head";

export const Route = createFileRoute("/patrimonio")({
  head: head("Patrimônio e Equipamentos", "Equipamentos culturais, acervos e memória de Guarulhos com fontes públicas."),
  component: () => (
    <Pagina titulo="Patrimônio e Equipamentos" intro="Equipamentos públicos de cultura. Uso, programação e manutenção: não verificados.">
      <div className="grid gap-3 sm:grid-cols-2">
        {EQUIPAMENTOS.map((e) => (
          <Cartao key={e.nome} cor="verde"><h2 className="font-bold">{e.nome}</h2><p className="text-sm">{e.tipo}</p><p className="mt-1 selo selo-fase">Situação: não verificado</p></Cartao>
        ))}
      </div>
      <Cartao cor="azul">
        <p className="text-sm">A plataforma de agendamento mostra disponibilidade, mas <strong>não comprova uso</strong> dos espaços.</p>
        <Fontes fontes={[F.agenda, F.obs]} />
      </Cartao>
      <ListaTema tema="Patrimônio e Equipamentos" />
    </Pagina>
  ),
});
