import { createFileRoute } from "@tanstack/react-router";
import { ListaTema } from "@/components/ListaTema";
import { Cartao, Pagina } from "@/components/ui-obs";
import { head } from "@/lib/head";

export const Route = createFileRoute("/sistema")({
  head: head("Sistema e Leis", "As leis que organizam o Sistema Municipal de Cultura de Guarulhos: sistema, plano, conselho e fundo."),
  component: () => (
    <Pagina titulo="Sistema e Leis" intro="O Sistema de Cultura funciona como um tripé: Conselho, Plano e Fundo (o “CPF da cultura”), com conferências.">
      <Cartao cor="azul"><p className="text-sm">Atenção: a Lei 5.947/2003 cria o <strong>FUNCULTURA</strong>. O Plano cita também um <strong>Fundo Municipal de Política Cultural</strong>. São coisas diferentes, e a implantação do segundo é <strong>não verificada</strong>.</p></Cartao>
      <ListaTema tema="Sistema e Leis" />
    </Pagina>
  ),
});
