import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Cartao, Fontes, Pagina } from "@/components/ui-obs";
import { F, GLOSSARIO } from "@/lib/data";
import { head } from "@/lib/head";

export const Route = createFileRoute("/fontes")({
  head: head("Fontes e Glossário", "Todas as fontes oficiais e secundárias do observatório e um glossário de 20 termos em linguagem simples."),
  component: Pag,
});

function Pag() {
  const [q, setQ] = useState("");
  const g = GLOSSARIO.filter((x) => (x.termo + x.def).toLowerCase().includes(q.toLowerCase()));
  return (
    <Pagina titulo="Fontes e Glossário">
      <Cartao cor="azul"><h2 className="font-bold">Fontes</h2><Fontes fontes={Object.values(F)} /></Cartao>
      <h2 className="text-xl font-bold">Glossário ({GLOSSARIO.length} termos)</h2>
      <label htmlFor="g-busca">Filtrar termos</label>
      <input id="g-busca" type="search" value={q} onChange={(e) => setQ(e.target.value)} />
      <dl className="grid gap-2 sm:grid-cols-2">
        {g.map((x) => <div key={x.termo} className="cartao cartao-verde"><dt className="font-bold">{x.termo}</dt><dd>{x.def}</dd></div>)}
      </dl>
      {!g.length && <p>Nenhum termo encontrado.</p>}
    </Pagina>
  );
}
