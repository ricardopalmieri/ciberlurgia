import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Botao, Cartao, Pagina } from "@/components/ui-obs";
import { BAIRROS } from "@/lib/data";
import { head } from "@/lib/head";
import { AvisoAparelho } from "@/components/AvisoAparelho";
import { useDados, type Projeto } from "@/lib/store";

export const Route = createFileRoute("/territorios")({
  head: head("Territórios", "Registre e filtre projetos culturais por bairro de Guarulhos, separando proponente e local da ação."),
  component: Pag,
});

const CAMPOS: [keyof Projeto, string][] = [
  ["nome", "Nome do projeto"], ["instrumento", "Instrumento (edital, convênio…)"], ["ano", "Ano"], ["linguagem", "Linguagem artística"],
  ["previsto", "Valor previsto"], ["contratado", "Valor contratado"], ["empenhado", "Valor empenhado"], ["pago", "Valor pago"],
  ["publico", "Público (agregado)"], ["fonte", "Link da fonte"], ["dataFonte", "Data da fonte"],
];
const novo = (): Projeto => ({ id: "", nome: "", instrumento: "", ano: "", bairroProponente: "", localRealizacao: "", linguagem: "", previsto: "", contratado: "", empenhado: "", pago: "", publico: "", fonte: "", dataFonte: "" });

function Pag() {
  const { dados, salvar } = useDados();
  const [f, setF] = useState<Projeto>(novo);
  const [bairro, setBairro] = useState("");
  const lista = dados.projetos.filter((p) => !bairro || p.bairroProponente === bairro || p.localRealizacao === bairro);
  return (
    <Pagina titulo="Territórios" intro="Não publicamos quantos projetos ou valores chegam a cada bairro sem documento. Aqui você registra os que encontrar em fontes oficiais (fica só no seu aparelho). Não registre dados pessoais. O endereço da entidade proponente NÃO comprova onde a ação aconteceu: registre o local só com documento (relatório, foto datada, lista de presença).">
      <AvisoAparelho />
      <form className="cartao cartao-azul grid gap-2 sm:grid-cols-2" onSubmit={(e) => { e.preventDefault(); salvar((d) => ({ ...d, projetos: [...d.projetos, { ...f, id: String(Date.now()) }] })); setF(novo()); }}>
        <h2 className="font-bold sm:col-span-2">Registrar projeto</h2>
        {CAMPOS.map(([k, l]) => <div key={k}><label htmlFor={`p-${k}`}>{l}</label><input id={`p-${k}`} required={k === "nome"} value={f[k]} onChange={(e) => setF({ ...f, [k]: e.target.value })} /></div>)}
        {(["bairroProponente", "localRealizacao"] as const).map((k) => (
          <div key={k}><label htmlFor={`p-${k}`}>{k === "bairroProponente" ? "Bairro de residência do proponente" : "Bairro onde a ação aconteceu"}</label>
            <select id={`p-${k}`} value={f[k]} onChange={(e) => setF({ ...f, [k]: e.target.value })}><option value="">não verificado</option>{BAIRROS.map((b) => <option key={b}>{b}</option>)}</select></div>
        ))}
        <div className="sm:col-span-2"><Botao type="submit">Salvar projeto</Botao></div>
      </form>
      <label htmlFor="f-bairro">Filtrar por bairro</label>
      <select id="f-bairro" value={bairro} onChange={(e) => setBairro(e.target.value)}><option value="">Todos</option>{BAIRROS.map((b) => <option key={b}>{b}</option>)}</select>
      {!lista.length && <p>Nenhum projeto registrado {bairro && `em ${bairro}`}.</p>}
      {lista.map((p) => (
        <Cartao key={p.id} cor="verde">
          <h3 className="font-bold">{p.nome}</h3>
          <dl className="grid grid-cols-1 gap-x-3 sm:grid-cols-2 text-sm">
            {CAMPOS.slice(1).map(([k, l]) => <div key={k}><dt className="font-semibold">{l}</dt><dd>{p[k] || "não verificado"}</dd></div>)}
            <div><dt className="font-semibold">Proponente</dt><dd>{p.bairroProponente || "não verificado"}</dd></div>
            <div><dt className="font-semibold">Local da ação</dt><dd>{p.localRealizacao || "não verificado"}</dd></div>
          </dl>
          <Botao className="botao-sec mt-2" onClick={() => salvar((d) => ({ ...d, projetos: d.projetos.filter((x) => x.id !== p.id) }))}>Excluir</Botao>
        </Cartao>
      ))}
    </Pagina>
  );
}
