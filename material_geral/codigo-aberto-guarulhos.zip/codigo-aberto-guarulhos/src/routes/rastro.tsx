import { createFileRoute, Link } from "@tanstack/react-router";
import { Cartao, Fontes, Pagina } from "@/components/ui-obs";
import { REGISTROS, type Registro } from "@/lib/data";
import { head } from "@/lib/head";

export const Route = createFileRoute("/rastro")({
  head: head("Rastro do Dinheiro", "Como ler os dados da cultura: da lei ao resultado comprovado no bairro, etapa por etapa, com o que já tem documento e o que não foi verificado."),
  component: Pag,
});

const reg = (id: string) => REGISTROS.find((r) => r.id === id);

type Etapa = { n: string; o: string; pergunta: string; doc: string; real?: { r: Registro; nota: string } };
const ETAPAS: Etapa[] = [
  { n: "Lei", o: "A regra que cria o direito e obriga o poder público.", pergunta: "Qual lei garante isso?", doc: "Lei publicada no Diário Oficial.", real: { r: reg("lei-7834")!, nota: "Plano Municipal de Cultura virou lei." } },
  { n: "Plano e meta", o: "A promessa escrita: o que fazer, até quando.", pergunta: "Qual meta trata disso e qual é o prazo?", doc: "Plano Municipal de Cultura, com número da meta.", real: { r: reg("meta2-15")!, nota: "Exemplo de meta com documento; cumprimento não verificado." } },
  { n: "Orçamento previsto", o: "Dinheiro reservado no papel. Ainda não foi gasto.", pergunta: "Quanto foi previsto, em qual fonte (própria, PNAB…)?", doc: "LOA, plano de ação (PAR) ou edital.", real: { r: reg("pnab-ex1")!, nota: "Valor PLANEJADO da PNAB. Previsto não é pago." } },
  { n: "Empenhado", o: "A Prefeitura separa o dinheiro para alguém específico.", pergunta: "Quem recebeu o empenho e quando?", doc: "Nota de empenho (portal da transparência / TCE).", real: { r: reg("lupa-2025")!, nota: "Total da função Cultura em 2025, fonte secundária. Não mostra projeto por projeto." } },
  { n: "Liquidado", o: "A Prefeitura confirma que o serviço foi entregue.", pergunta: "Quem atestou a entrega e com qual documento?", doc: "Nota de liquidação / atestado de execução." },
  { n: "Pago", o: "O dinheiro saiu da conta pública.", pergunta: "Em que data e para quem foi pago?", doc: "Ordem de pagamento.", real: { r: reg("lupa-2025")!, nota: "Total pago da função Cultura em 2025 (agregado, fonte secundária). Pagamentos por edital: não verificados." } },
  { n: "Bairro REAL da execução", o: "Onde a ação aconteceu de verdade. O endereço da entidade proponente NÃO prova isso.", pergunta: "Onde e quando a atividade aconteceu?", doc: "Relatório de execução, fotos datadas, listas de presença." },
  { n: "Resultado comprovado", o: "O que mudou para o público, com prova.", pergunta: "Quantas pessoas participaram? O que foi entregue?", doc: "Relatório final aprovado, prestação de contas." },
];

function Pag() {
  return (
    <Pagina titulo="Como ler os dados: o rastro do dinheiro" intro="Dinheiro público na cultura passa por várias etapas. Só podemos dizer que algo chegou ao bairro quando cada etapa tem documento. Onde falta papel, escrevemos “não verificado” — que quer dizer “ainda não vimos a prova”, não “não aconteceu”.">
      <Cartao cor="neutro">
        <h2 className="font-bold">Como usar em roda de conversa</h2>
        <p className="text-sm">Parta do que o grupo já vive: “teve oficina no nosso bairro?”. Depois volte pelas etapas e pergunte em cada uma: <strong>que documento mostra isso?</strong> O saber do território e o documento oficial se completam. As cores dos selos medem só se o documento existe — <strong>não são nota para a gestão</strong>.</p>
      </Cartao>
      <ol className="space-y-3">
        {ETAPAS.map((e, i) => (
          <li key={e.n}>
            <Cartao cor={e.real ? "verde" : "amarelo"}>
              <h2 className="font-display text-lg font-bold">{i + 1}. {e.n}</h2>
              <p>{e.o}</p>
              <p className="mt-1 text-sm"><strong>Pergunta:</strong> {e.pergunta}</p>
              <p className="text-sm"><strong>Documento que comprova:</strong> {e.doc}</p>
              {e.real ? (
                <div className="mt-2 rounded border border-border bg-background p-2 text-sm">
                  <span className="selo selo-verde">DADO REAL com fonte</span>
                  <p className="mt-1 font-semibold">{e.real.r.titulo}{e.real.r.valor ? ` — ${e.real.r.valor}` : ""}</p>
                  <p>{e.real.nota} Data: {e.real.r.data ?? "não verificado"}.</p>
                  <Fontes fontes={e.real.r.fontes} />
                </div>
              ) : (
                <p className="mt-2"><span className="selo selo-vermelho">Status: não verificado</span> <span className="text-sm">Ainda não temos documento público desta etapa.</span></p>
              )}
            </Cartao>
          </li>
        ))}
      </ol>
      <Cartao cor="azul">
        <h2 className="font-bold">EXEMPLO DIDÁTICO (não é dado real)</h2>
        <p className="text-sm">Imagine um edital que prevê oficinas “nas periferias”. A entidade vencedora tem sede no Centro. Isso não diz onde as oficinas aconteceram: só o relatório de execução, com lista de presença e endereço da atividade, mostra o bairro real. Sem ele, o bairro fica “não verificado”.</p>
      </Cartao>
      <p className="text-sm">Registre o que você encontrar em <Link to="/territorios" className="link">Territórios</Link> e cobre os documentos na <Link to="/agenda" className="link">Agenda Cidadã</Link>.</p>
    </Pagina>
  );
}
