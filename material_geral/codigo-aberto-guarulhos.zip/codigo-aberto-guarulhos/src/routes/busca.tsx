import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { CartaoRegistro, Cartao, Pagina } from "@/components/ui-obs";
import { AGENDA, EQUIPAMENTOS, GLOSSARIO, METAS, REGISTROS } from "@/lib/data";
import { head } from "@/lib/head";

type S = { q: string; ano: string; tema: string };
export const Route = createFileRoute("/busca")({
  validateSearch: (s: Record<string, unknown>): S => ({ q: String(s["q"] ?? ""), ano: String(s["ano"] ?? ""), tema: String(s["tema"] ?? "") }),
  head: head("Busca", "Busque leis, metas, valores, editais e termos no Observatório da Cultura de Guarulhos."),
  component: Busca,
});

const norm = (s: string) => s.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();

function Busca() {
  const { q, ano, tema } = Route.useSearch();
  const nav = useNavigate({ from: "/busca" });
  const t = norm(q);
  const has = (s: string) => !t || norm(s).includes(t);
  const anos = [...new Set(REGISTROS.map((r) => r.ano))].sort();
  const temas = [...new Set(REGISTROS.map((r) => r.tema))];
  const regs = REGISTROS.filter((r) => has(r.titulo + r.resumo + (r.valor ?? "")) && (!ano || String(r.ano) === ano) && (!tema || r.tema === tema));
  const extras = ano || tema ? [] : [
    ...METAS.filter((m) => has(`meta ${m.n} ${m.titulo ?? ""}`)).map((m) => ({ k: `m${m.n}`, t: `Meta ${m.n}`, d: m.titulo ?? "conferir título no Plano oficial" })),
    ...GLOSSARIO.filter((g) => has(g.termo + g.def)).map((g) => ({ k: g.termo, t: `Glossário: ${g.termo}`, d: g.def })),
    ...EQUIPAMENTOS.filter((e) => has(e.nome + e.tipo)).map((e) => ({ k: e.nome, t: e.nome, d: e.tipo })),
    ...AGENDA.filter((a) => has(a.titulo + a.pergunta)).map((a) => ({ k: `a${a.id}`, t: `Agenda ${a.id}: ${a.titulo}`, d: a.pergunta })),
  ];
  const set = (p: Partial<S>) => nav({ search: (s: S) => ({ ...s, ...p }) });
  return (
    <Pagina titulo={q ? `Resultados para “${q}”` : "Busca e filtros"}>
      <div className="grid gap-2 sm:grid-cols-3">
        <div><label htmlFor="b-q">Palavra</label><input id="b-q" type="search" value={q} onChange={(e) => set({ q: e.target.value })} /></div>
        <div><label htmlFor="b-ano">Ano</label><select id="b-ano" value={ano} onChange={(e) => set({ ano: e.target.value })}><option value="">Todos</option>{anos.map((a) => <option key={a}>{a}</option>)}</select></div>
        <div><label htmlFor="b-tema">Tema</label><select id="b-tema" value={tema} onChange={(e) => set({ tema: e.target.value })}><option value="">Todos</option>{temas.map((a) => <option key={a}>{a}</option>)}</select></div>
      </div>
      <p aria-live="polite" className="font-semibold">{regs.length + extras.length} resultado(s)</p>
      <div className="space-y-3">
        {regs.map((r) => <CartaoRegistro key={r.id} r={r} />)}
        {extras.map((x) => <Cartao key={x.k} cor="neutro"><h2 className="font-bold">{x.t}</h2><p className="text-sm">{x.d}</p></Cartao>)}
      </div>
      {regs.length + extras.length === 0 && (
        <Cartao cor="amarelo">
          <h2 className="font-bold">Nada encontrado{q && ` para “${q}”`}</h2>
          <ul className="ml-5 list-disc text-sm">
            <li>Tente uma palavra mais curta ou geral: “edital”, “meta”, “conselho”, “PNAB”, “pago”.</li>
            <li>Acentos não importam: “orcamento” acha “orçamento”.</li>
            <li>Tire o filtro de ano ou tema.</li>
            <li>Se o assunto não aparece, talvez ainda não tenhamos o documento — isso é “não verificado”, não “não existe”.</li>
          </ul>
          {(ano || tema) && <button type="button" className="botao botao-sec mt-2" onClick={() => set({ ano: "", tema: "" })}>Limpar filtros</button>}
        </Cartao>
      )}
      <p className="text-sm text-muted-foreground">Para filtrar projetos por bairro, use a aba Territórios.</p>
    </Pagina>
  );
}
