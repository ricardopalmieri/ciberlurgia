import { createFileRoute } from "@tanstack/react-router";
import { ListaTema } from "@/components/ListaTema";
import { Cartao, Pagina } from "@/components/ui-obs";
import { head } from "@/lib/head";

const FASES = [
  ["Dotação", "Valor autorizado na LOA", "não verificado"],
  ["Empenho", "Dinheiro reservado", "não verificado (2026)"],
  ["Liquidação", "Entrega confirmada", "não verificado (2026)"],
  ["Pago", "Dinheiro saiu da conta", "não verificado (2026)"],
];

export const Route = createFileRoute("/orcamento")({
  head: head("Fundo e Orçamento", "Orçamento e fundos da cultura de Guarulhos: dotação, empenho, liquidação e pagamento separados."),
  component: () => (
    <Pagina titulo="Fundo e Orçamento" intro="Separamos sempre as fases do gasto. Pagamentos de 2026 só entram com documento oficial.">
      <Cartao cor="azul">
        <h2 className="font-bold">Fases do gasto – 2026</h2>
        <dl className="mt-2 grid grid-cols-2 gap-2 text-sm sm:grid-cols-4">
          {FASES.map(([f, d, v]) => <div key={f} className="rounded-md bg-background p-2"><dt className="font-bold">{f}</dt><dd>{d}</dd><dd className="font-semibold">{v}</dd></div>)}
        </dl>
      </Cartao>
      <ListaTema tema="Fundo e Orçamento" />
      <Cartao cor="neutro">
        <h2 className="font-bold">FUNCULTURA e Fundo de Política Cultural – a levantar</h2>
        <ul className="ml-5 list-disc text-sm"><li>Composição do conselho diretor</li><li>Atas e deliberações</li><li>Relatórios e balancetes anuais</li><li>Prova de implantação do Fundo Municipal de Política Cultural</li></ul>
      </Cartao>
    </Pagina>
  ),
});
