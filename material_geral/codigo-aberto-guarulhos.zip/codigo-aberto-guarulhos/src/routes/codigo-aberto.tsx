import { createFileRoute } from "@tanstack/react-router";
import { Cartao, Pagina } from "@/components/ui-obs";
import { head } from "@/lib/head";

export const Route = createFileRoute("/codigo-aberto")({
  head: head("Código Aberto", "Baixe o pacote completo do Observatório da Cultura de Guarulhos (código MIT e textos CC BY 4.0) e faça a sua própria cópia."),
  component: Pag,
});

function Pag() {
  return (
    <Pagina titulo="Código Aberto" intro="Este observatório é de todo mundo. Você pode baixar o pacote completo e montar a sua própria versão: para o seu bairro, coletivo, escola ou outra cidade.">
      <Cartao cor="verde">
        <h2 className="font-bold">Baixar o pacote</h2>
        <p className="text-sm">Arquivo ZIP com o código, os textos, a lista de fontes e as licenças. <strong>Não</strong> leva suas anotações: elas ficam só no seu aparelho (para levá-las, use “Exportar backup” na Agenda).</p>
        <a href="/downloads/codigo-aberto-guarulhos.zip" download="codigo-aberto-guarulhos.zip" className="botao mt-2">Baixar código aberto (ZIP, cerca de 180 KB)</a>
      </Cartao>
      <Cartao cor="azul">
        <h2 className="font-bold">Como mudar a sua cópia, passo a passo</h2>
        <ol className="ml-5 list-decimal space-y-1 text-sm">
          <li>Baixe o ZIP e descompacte (no celular, o app “Arquivos” faz isso).</li>
          <li>Os textos e dados ficam no arquivo <strong>src/lib/data.ts</strong>. Dá pra abrir em qualquer editor de texto.</li>
          <li>Mude o que quiser. Todo fato precisa de link da fonte e data. Sem documento, escreva “não verificado”.</li>
          <li>Para ver o site no computador: instale o programa gratuito Bun, abra a pasta e rode <code>bun install</code> e depois <code>bun run dev</code>. O README explica.</li>
          <li>Aprendam juntos: uma pessoa que já mexe com computador pode ajudar a roda toda.</li>
        </ol>
      </Cartao>
      <Cartao cor="amarelo">
        <h2 className="font-bold">Importante</h2>
        <ul className="ml-5 list-disc space-y-1 text-sm">
          <li>Mudar a sua cópia <strong>não</strong> muda este site e <strong>não</strong> dá permissão para editar o site original.</li>
          <li>Se publicar a sua versão, deixe claro que é outra iniciativa e cite a origem (licença CC BY 4.0 para os textos, MIT para o código).</li>
          <li>Leis, Diário Oficial e editais são da Prefeitura e de órgãos públicos; o pacote só traz os links. Sites como Escavador e Lupa Municipal têm seus próprios direitos.</li>
          <li>Nunca coloque CPF, telefone, e-mail ou endereço de pessoas, nem senhas.</li>
          <li>Valores da PNAB no pacote são previstos/planejados. Pagamentos e resultados de editais: não verificados.</li>
        </ul>
      </Cartao>
    </Pagina>
  );
}
