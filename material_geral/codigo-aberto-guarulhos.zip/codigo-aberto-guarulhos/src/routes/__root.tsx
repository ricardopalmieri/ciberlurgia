import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  Outlet, Link, createRootRouteWithContext, useRouter, useNavigate, HeadContent, Scripts,
  type ErrorComponentProps,
} from "@tanstack/react-router";
import { useEffect, useState, type ReactNode } from "react";

import appCss from "../styles.css?url";
import { reportLovableError } from "../lib/lovable-error-reporting";
import { DATA_PESQUISA } from "@/lib/data";

export const ABAS = [
  { to: "/", label: "Início" },
  { to: "/sistema", label: "Sistema e Leis" },
  { to: "/plano", label: "Plano e Metas" },
  { to: "/conselho", label: "Conselho e Conferências" },
  { to: "/orcamento", label: "Fundo e Orçamento" },
  { to: "/rastro", label: "Rastro do Dinheiro" },
  { to: "/pnab", label: "PNAB e Cultura Viva" },
  { to: "/territorios", label: "Territórios" },
  { to: "/patrimonio", label: "Patrimônio e Equipamentos" },
  { to: "/agenda", label: "Agenda Cidadã" },
  { to: "/fontes", label: "Fontes e Glossário" },
  { to: "/codigo-aberto", label: "Código Aberto" },
] as const;

function NotFoundComponent() {
  return (
    <div className="py-16 text-center">
      <h1 className="text-3xl font-bold">Página não encontrada</h1>
      <Link to="/" className="botao mt-6">Voltar ao início</Link>
    </div>
  );
}

function ErrorComponent({ error, reset }: ErrorComponentProps) {
  console.error(error);
  const router = useRouter();
  useEffect(() => { reportLovableError(error, { boundary: "tanstack_root_error_component" }); }, [error]);
  return (
    <div className="py-16 text-center">
      <h1 className="text-xl font-semibold">Esta página não carregou</h1>
      <button className="botao mt-6" onClick={() => { router.invalidate(); reset(); }}>Tentar de novo</button>
    </div>
  );
}

export const Route = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { name: "theme-color", content: "#1f8a4c" },
      { title: "Observatório da Cultura de Guarulhos | Agenda Cidadã" },
      { name: "description", content: "Observatório cidadão independente que acompanha leis, plano, orçamento e resultados da cultura em Guarulhos." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
    links: [
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "stylesheet", href: "https://fonts.googleapis.com/css2?family=Atkinson+Hyperlegible:wght@400;700&display=swap" },
      { rel: "stylesheet", href: appCss },
      { rel: "icon", href: "/favicon.ico", type: "image/x-icon" },
    ],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent,
});

function RootShell({ children }: { children: ReactNode }) {
  return (
    <html lang="pt-BR">
      <head><HeadContent /></head>
      <body>{children}<Scripts /></body>
    </html>
  );
}

function Busca() {
  const [q, setQ] = useState("");
  const navigate = useNavigate();
  return (
    <form role="search" className="grid grid-cols-[minmax(0,1fr)_auto] gap-2" onSubmit={(e) => { e.preventDefault(); navigate({ to: "/busca", search: { q, ano: "", tema: "" } }); }}>
      <label htmlFor="busca-global" className="sr-only">Buscar no observatório</label>
      <input id="busca-global" type="search" value={q} onChange={(e) => setQ(e.target.value)} placeholder="Buscar: PNAB, meta, conselho, empenho…" />
      <button className="botao" type="submit">Buscar</button>
    </form>
  );
}

function RootComponent() {
  const { queryClient } = Route.useRouteContext();
  return (
    <QueryClientProvider client={queryClient}>
      <a href="#conteudo" className="sr-only focus:not-sr-only focus:absolute focus:left-2 focus:top-2 botao">Pular para o conteúdo</a>
      <header className="no-print border-b border-border bg-background">
        <div className="mx-auto max-w-4xl space-y-3 px-4 pt-4">
          <div>
            <p className="text-xs font-bold uppercase tracking-wide text-primary">Observatório cidadão INDEPENDENTE · não oficial · sem vínculo com a Prefeitura</p>
            <Link to="/" className="font-display text-xl font-bold leading-tight">Observatório da Cultura de Guarulhos <span className="text-muted-foreground">| Agenda Cidadã</span></Link>
          </div>
          <Busca />
          <nav aria-label="Seções" className="pb-3">
            <ul className="flex flex-wrap gap-2">
              {ABAS.map((a) => (
                <li key={a.to}>
                  <Link to={a.to} className="aba" activeProps={{ className: "aba-ativa", "aria-current": "page" }} activeOptions={{ exact: true }}>{a.label}</Link>
                </li>
              ))}
            </ul>
          </nav>
        </div>
      </header>
      <div role="note" className="sticky top-0 z-10 bg-accent px-4 py-2 text-center text-sm font-bold text-accent-foreground no-print">
        Observatório em construção: valor previsto não é valor pago. Monitoramento requer documentos oficiais e conciliação.
      </div>
      <main id="conteudo" className="mx-auto max-w-4xl px-4 py-6">
        <Outlet />
      </main>
      <footer className="mx-auto max-w-4xl px-4 pb-8 text-sm text-muted-foreground">
        Iniciativa cidadã independente. Pesquisa inicial em {DATA_PESQUISA}. Cores indicam completude dos documentos, não qualidade de governo. Suas anotações ficam só neste aparelho (não há banco comunitário compartilhado) — use “Exportar backup” na Agenda.
      </footer>
    </QueryClientProvider>
  );
}
