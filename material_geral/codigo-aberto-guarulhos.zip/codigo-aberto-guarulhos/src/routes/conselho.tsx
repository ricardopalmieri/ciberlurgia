import { createFileRoute } from "@tanstack/react-router";
import { ListaTema } from "@/components/ListaTema";
import { Cartao, Pagina } from "@/components/ui-obs";
import { head } from "@/lib/head";

export const Route = createFileRoute("/conselho")({
  head: head("Conselho e Conferências", "CMPC de Guarulhos, mesa diretora 2026 e 9ª Conferência Municipal de Cultura."),
  component: () => (
    <Pagina titulo="Conselho e Conferências" intro="O CMPC é paritário (metade governo, metade sociedade civil) e tem funções consultiva, deliberativa e normativa.">
      <ListaTema tema="Conselho e Conferências" />
      <Cartao cor="neutro">
        <h2 className="font-bold">Documentos a levantar</h2>
        <ul className="ml-5 list-disc text-sm">
          <li>Calendário anual de reuniões do CMPC</li><li>Atas e listas de presença</li>
          <li>Resoluções publicadas</li><li>Relatório final e propostas da 9ª Conferência</li>
        </ul>
      </Cartao>
    </Pagina>
  ),
});
