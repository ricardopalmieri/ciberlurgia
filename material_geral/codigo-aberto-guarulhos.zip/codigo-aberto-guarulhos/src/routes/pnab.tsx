import { createFileRoute } from "@tanstack/react-router";
import { ListaTema } from "@/components/ListaTema";
import { Cartao, Pagina } from "@/components/ui-obs";
import { head } from "@/lib/head";

export const Route = createFileRoute("/pnab")({
  head: head("PNAB e Cultura Viva", "Planos e editais da Política Nacional Aldir Blanc e Pontos de Cultura em Guarulhos, com fase de cada valor."),
  component: () => (
    <Pagina titulo="PNAB e Cultura Viva" intro="Todos os valores abaixo são PREVISTOS em planos ou editais. Nenhum pagamento foi comprovado aqui.">
      <Cartao cor="amarelo"><p className="text-sm font-semibold">Não some os totais: planos, revisões e editais podem se sobrepor (o mesmo dinheiro aparece em mais de um documento).</p></Cartao>
      <ListaTema tema="PNAB e Cultura Viva" />
    </Pagina>
  ),
});
