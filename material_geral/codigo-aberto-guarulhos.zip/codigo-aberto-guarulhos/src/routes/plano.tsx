import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Cartao, Fontes, Pagina } from "@/components/ui-obs";
import { EIXOS, F, METAS } from "@/lib/data";
import { head } from "@/lib/head";

export const Route = createFileRoute("/plano")({
  head: head("Plano e Metas", "As 14 metas do Plano Municipal de Cultura de Guarulhos (Lei 7.834/2020) e sua situação de apuração."),
  component: Plano,
});

function Plano() {
  const [eixo, setEixo] = useState("todos");
  const grupos = [...EIXOS.map((e) => ({ id: e.n, nome: `Eixo ${e.n} – ${e.nome}` })), { id: "?", nome: "Eixo a conferir no Plano oficial" }];
  return (
    <Pagina titulo="Plano e Metas" intro="Lei 7.834 de 06/07/2020: plano de 10 anos, 4 eixos, 14 metas e 57 ações. Situação de execução de todas as metas: em apuração até prova documental.">
      <Fontes fontes={[F.plano, F.obs]} />
      <div>
        <label htmlFor="f-eixo">Filtrar por eixo</label>
        <select id="f-eixo" value={eixo} onChange={(e) => setEixo(e.target.value)}>
          <option value="todos">Todos</option>
          {grupos.map((g) => <option key={g.id} value={g.id}>{g.nome}</option>)}
        </select>
      </div>
      {grupos.filter((g) => eixo === "todos" || eixo === g.id).map((g) => {
        const ms = METAS.filter((m) => (m.eixo ?? "?") === g.id);
        if (!ms.length) return null;
        return (
          <div key={g.id} className="space-y-2">
            <h2 className="font-bold">{g.nome}</h2>
            <div className="grid gap-3 sm:grid-cols-2">
              {ms.map((m) => (
                <Cartao key={m.n} cor={m.titulo ? "verde" : "neutro"}>
                  <h3 className="font-bold">Meta {m.n}</h3>
                  <p>{m.titulo ?? <em>conferir título no Plano oficial</em>}</p>
                  <p className="mt-2 flex flex-wrap gap-2"><span className="selo selo-amarelo">Execução: em apuração</span><span className="selo selo-fase">Indicador: não verificado</span></p>
                </Cartao>
              ))}
            </div>
          </div>
        );
      })}
    </Pagina>
  );
}
