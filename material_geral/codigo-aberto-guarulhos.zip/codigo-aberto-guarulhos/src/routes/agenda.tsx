import { createFileRoute } from "@tanstack/react-router";
import { useRef } from "react";
import { Botao, Cartao, Pagina } from "@/components/ui-obs";
import { AGENDA, AULA } from "@/lib/data";
import { head } from "@/lib/head";
import { AvisoAparelho } from "@/components/AvisoAparelho";
import { baixar, dataArquivo, projetosCSV, resumir, useDados, validarBackup, type Ficha } from "@/lib/store";

export const Route = createFileRoute("/agenda")({
  head: head("Agenda Cidadã", "10 compromissos para cobrar da gestão cultural de Guarulhos, ficha de fiscalização e roteiro de aula."),
  component: Pag,
});

const FICHA: [keyof Ficha, string][] = [["equipamento", "Equipamento / projeto visitado"], ["data", "Data da visita"], ["observado", "O que foi observado"], ["documentos", "Documentos pedidos ou recebidos"], ["encaminhamento", "Encaminhamento"]];

function Pag() {
  const { dados, salvar } = useDados();
  const arq = useRef<HTMLInputElement>(null);
  const feitos = AGENDA.filter((a) => dados.agenda[a.id]?.feito).length;
  const upd = (id: number, p: Partial<{ feito: boolean; notas: string }>) =>
    salvar((d) => ({ ...d, agenda: { ...d.agenda, [id]: { feito: false, notas: "", ...d.agenda[id], ...p } } }));
  return (
    <Pagina titulo="Agenda Cidadã" intro={`10 compromissos para cobrar. ${feitos} de 10 marcados como atendidos com documento.`}>
      <AvisoAparelho />
      <div className="no-print grid gap-2 sm:flex sm:flex-wrap">
        <Botao onClick={() => window.print()}>Imprimir agenda e relatório</Botao>
        <Botao className="botao-sec" onClick={() => baixar(`observatorio-backup-${dataArquivo()}.json`, JSON.stringify({ ...dados, exportadoEm: new Date().toISOString(), app: "observatorio-cultura-guarulhos" }, null, 2), "application/json")}>Exportar backup (JSON)</Botao>
        <Botao className="botao-sec" onClick={() => baixar(`projetos-${dataArquivo()}.csv`, projetosCSV(dados.projetos), "text/csv")}>Exportar CSV (projetos)</Botao>
        <Botao className="botao-sec" onClick={() => arq.current?.click()}>Importar backup (JSON)</Botao>
        <input ref={arq} type="file" accept="application/json" className="sr-only" aria-label="Arquivo JSON para importar" onChange={async (e) => {
          const file = e.target.files?.[0]; if (!file) return;
          try {
            const d = validarBackup(await file.text()); const r = resumir(d); const atual = resumir(dados);
            const ok = confirm(`O arquivo contém: ${r.compromissosMarcados} compromisso(s) marcados, ${r.anotacoes} anotação(ões), ${r.projetos} projeto(s)${r.fichaPreenchida ? ", ficha preenchida" : ""}.\n\nIsso SUBSTITUI o que está neste aparelho agora (${atual.compromissosMarcados} marcados, ${atual.anotacoes} anotações, ${atual.projetos} projetos). Dica: exporte um backup antes.\n\nImportar?`);
            if (ok) { salvar(() => d); alert("Backup importado."); }
          } catch (err) { alert(`Não importado: ${(err as Error).message}`); }
          e.target.value = "";
        }} />
      </div>
      <ol className="space-y-3">
        {AGENDA.map((a) => (
          <li key={a.id}><Cartao cor={dados.agenda[a.id]?.feito ? "verde" : "amarelo"}>
            <h2 className="font-bold">{a.id}. {a.titulo}</h2>
            <p className="text-sm"><strong>Pergunta ao gestor:</strong> {a.pergunta}</p>
            <p className="text-sm"><strong>Documento a solicitar:</strong> {a.doc}</p>
            <label className="mt-2 flex items-center gap-2"><input type="checkbox" className="h-6 w-6 shrink-0" style={{ width: "1.5rem", minHeight: 0 }} checked={!!dados.agenda[a.id]?.feito} onChange={(e) => upd(a.id, { feito: e.target.checked })} />Atendido com documento</label>
            <label htmlFor={`n-${a.id}`} className="mt-2 block">Anotações</label>
            <textarea id={`n-${a.id}`} rows={2} value={dados.agenda[a.id]?.notas ?? ""} onChange={(e) => upd(a.id, { notas: e.target.value })} />
          </Cartao></li>
        ))}
      </ol>
      <Cartao cor="azul">
        <h2 className="font-bold">Ficha de fiscalização cidadã</h2>
        {FICHA.map(([k, l]) => <div key={k} className="mt-2"><label htmlFor={`f-${k}`}>{l}</label>
          <textarea id={`f-${k}`} rows={k === "data" || k === "equipamento" ? 1 : 2} value={dados.ficha[k]} onChange={(e) => salvar((d) => ({ ...d, ficha: { ...d.ficha, [k]: e.target.value } }))} /></div>)}
      </Cartao>
      <Cartao cor="verde">
        <h2 className="font-bold">Dinâmica de aula (2 horas)</h2>
        <ol className="ml-5 list-decimal">{AULA.map((x) => <li key={x.tema}><strong>{x.min} min</strong> – {x.tema}</li>)}</ol>
      </Cartao>
    </Pagina>
  );
}
