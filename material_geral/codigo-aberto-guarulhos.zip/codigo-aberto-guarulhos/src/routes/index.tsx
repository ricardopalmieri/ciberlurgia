import { createFileRoute, Link } from "@tanstack/react-router";
import { Cartao, Pagina } from "@/components/ui-obs";
import { CRITERIOS, DATA_PESQUISA, REGISTROS, completude } from "@/lib/data";
import { head } from "@/lib/head";

export const Route = createFileRoute("/")({
  head: head("Início", "Observatório cidadão independente da cultura de Guarulhos: da lei ao resultado comprovado no bairro."),
  component: Index,
});

const CADEIA = ["Lei", "Plano e meta", "Orçamento", "Empenho", "Liquidação", "Pagamento", "Bairro", "Resultado comprovado"];

function Index() {
  const cont = { verde: 0, amarelo: 0, vermelho: 0 };
  REGISTROS.forEach((r) => cont[completude(r).cor]++);
  return (
    <Pagina titulo="Para onde vai a cultura de Guarulhos?" intro={<>Um observatório <strong>cidadão e independente</strong> (não é site da Prefeitura). Seguimos cada promessa da lei até o resultado no bairro. Pesquisa inicial: {DATA_PESQUISA}.</>}>
      <Cartao cor="azul">
        <h2 className="font-bold">O caminho que acompanhamos</h2>
        <ol className="mt-2 flex flex-wrap gap-2 text-sm">
          {CADEIA.map((c, i) => <li key={c} className="selo">{i + 1}. {c}</li>)}
        </ol>
        <Link to="/rastro" className="link mt-2 inline-block">Como ler os dados: o rastro do dinheiro, etapa por etapa</Link>
        <p className="mt-2 text-sm">Sem documento, escrevemos <strong>“não verificado”</strong> — nunca “zero”.</p>
      </Cartao>
      <div className="grid gap-3 sm:grid-cols-2">
        <Cartao cor="verde"><h2 className="font-bold">Plano Municipal</h2><p>4 eixos, 14 metas, 57 ações. Execução: <strong>em apuração</strong>.</p><Link to="/plano" className="link">Ver metas</Link></Cartao>
        <Cartao cor="amarelo"><h2 className="font-bold">PNAB e editais</h2><p>Valores previstos em planos e editais. Pagamentos: não verificados.</p><Link to="/pnab" className="link">Ver valores e fases</Link></Cartao>
        <Cartao cor="azul"><h2 className="font-bold">Conselho (CMPC)</h2><p>Mesa eleita em 19/05/2026, publicada em 22/05/2026.</p><Link to="/conselho" className="link">Ver conselho</Link></Cartao>
        <Cartao cor="verde"><h2 className="font-bold">Agenda Cidadã</h2><p>10 compromissos para cobrar, com checklist salvo no seu celular.</p><Link to="/agenda" className="link">Abrir agenda</Link></Cartao>
      </div>
      <Cartao cor="neutro">
        <h2 className="font-bold">Indicador de completude documental</h2>
        <p className="text-sm">Mede só se os documentos estão completos. <strong>Não é nota do governo.</strong> Cada registro ganha 1 ponto por critério:</p>
        <ul className="ml-5 list-disc text-sm">{CRITERIOS.map((c) => <li key={c}>{c}</li>)}</ul>
        <p className="mt-2 text-sm">Verde = 4/4 · Amarelo = 2 ou 3 · Vermelho = 0 ou 1.</p>
        <p className="mt-2 flex flex-wrap gap-2">
          <span className="selo selo-verde">{cont.verde} completos</span>
          <span className="selo selo-amarelo">{cont.amarelo} parciais</span>
          <span className="selo selo-vermelho">{cont.vermelho} insuficientes</span>
          <span className="selo">de {REGISTROS.length} registros</span>
        </p>
      </Cartao>
    </Pagina>
  );
}
