import { CartaoRegistro } from "@/components/ui-obs";
import { REGISTROS, type Tema } from "@/lib/data";

export function ListaTema({ tema }: { tema: Tema }) {
  return <div className="space-y-3">{REGISTROS.filter((r) => r.tema === tema).map((r) => <CartaoRegistro key={r.id} r={r} />)}</div>;
}
