import type { ReactNode } from "react";
import { completude, type Fonte, type Registro } from "@/lib/data";

export function Pagina({ titulo, intro, children }: { titulo: string; intro?: ReactNode; children: ReactNode }) {
  return (
    <section aria-labelledby="titulo-pagina" className="space-y-4">
      <h1 id="titulo-pagina" className="font-display text-2xl font-bold text-foreground">{titulo}</h1>
      {intro && <p className="text-base text-muted-foreground">{intro}</p>}
      {children}
    </section>
  );
}

export function Cartao({ cor = "verde", children, className = "" }: { cor?: "verde" | "azul" | "amarelo" | "neutro"; children: ReactNode; className?: string }) {
  return <article className={`cartao cartao-${cor} ${className}`}>{children}</article>;
}

export function Fase({ fase }: { fase: string }) {
  return <span className="selo selo-fase">Fase: {fase}</span>;
}

export function Fontes({ fontes }: { fontes: Fonte[] }) {
  return (
    <ul className="mt-2 space-y-1 text-sm">
      {fontes.map((f) => (
        <li key={f.url + f.label}>
          <a href={f.url} target="_blank" rel="noopener noreferrer" className="link">
            {f.label}
          </a>{" "}
          <span className="text-muted-foreground">({f.primaria ? "fonte oficial" : "fonte secundária"}{f.data ? ` · ${f.data}` : ""})</span>
        </li>
      ))}
    </ul>
  );
}

export function Completude({ r }: { r: Registro }) {
  const c = completude(r);
  const rotulo = { verde: "Documentação completa", amarelo: "Documentação parcial", vermelho: "Documentação insuficiente" }[c.cor];
  return <span className={`selo selo-${c.cor}`} title="Completude documental, não avaliação de governo">● {rotulo} ({c.pontos}/4)</span>;
}

export function CartaoRegistro({ r }: { r: Registro }) {
  const cor = r.tema === "PNAB e Cultura Viva" || r.tema === "Fundo e Orçamento" ? "amarelo" : r.tema === "Conselho e Conferências" ? "azul" : "verde";
  return (
    <Cartao cor={cor}>
      <h2 className="font-display text-lg font-bold">{r.titulo}</h2>
      {r.valor && <p className="mt-1 text-xl font-bold">{r.valor}</p>}
      <p className="mt-1">{r.resumo}</p>
      <div className="mt-2 flex flex-wrap gap-2">
        <Fase fase={r.fase} />
        <span className="selo selo-fase">Data: {r.data ?? "não verificado"}</span>
        <Completude r={r} />
      </div>
      {r.aviso && <p className="mt-2 text-sm font-semibold">⚠ {r.aviso}</p>}
      <Fontes fontes={r.fontes} />
    </Cartao>
  );
}

export function Botao({ children, ...p }: React.ButtonHTMLAttributes<HTMLButtonElement>) {
  return <button type="button" {...p} className={`botao ${p.className ?? ""}`}>{children}</button>;
}
