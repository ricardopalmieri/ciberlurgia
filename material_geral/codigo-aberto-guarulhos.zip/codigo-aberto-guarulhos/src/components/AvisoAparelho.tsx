import { Link } from "@tanstack/react-router";

export function AvisoAparelho() {
  return (
    <div role="note" className="cartao cartao-amarelo no-print text-sm">
      <p><strong>Suas anotações ficam só neste aparelho</strong>, neste navegador. Ainda <strong>não</strong> existe banco comunitário compartilhado: ninguém mais vê o que você escreve.</p>
      <p className="mt-1">Limpar dados do navegador, trocar de celular ou usar aba anônima apaga tudo. Faça <Link to="/agenda" className="link">“Exportar backup”</Link> com frequência e guarde o arquivo.</p>
    </div>
  );
}
