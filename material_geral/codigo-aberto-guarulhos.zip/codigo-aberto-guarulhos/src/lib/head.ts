export function head(titulo: string, desc: string) {
  const t = `${titulo} | Observatório da Cultura de Guarulhos`;
  return () => ({
    meta: [
      { title: t },
      { name: "description", content: desc },
      { property: "og:title", content: t },
      { property: "og:description", content: desc },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  });
}
