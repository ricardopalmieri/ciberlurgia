import { useCallback, useEffect, useState } from "react";

export const STORE_KEY = "ocg-agenda-cidada-v1";

export type Projeto = {
  id: string; nome: string; instrumento: string; ano: string; bairroProponente: string;
  localRealizacao: string; linguagem: string; previsto: string; contratado: string;
  empenhado: string; pago: string; publico: string; fonte: string; dataFonte: string;
};
export type Ficha = { equipamento: string; data: string; observado: string; documentos: string; encaminhamento: string };
export type Dados = {
  agenda: Record<number, { feito: boolean; notas: string }>;
  projetos: Projeto[];
  ficha: Ficha;
};

export const VAZIO: Dados = {
  agenda: {}, projetos: [],
  ficha: { equipamento: "", data: "", observado: "", documentos: "", encaminhamento: "" },
};

export function normalizar(x: unknown): Dados {
  const o = (x && typeof x === "object" ? x : {}) as Partial<Dados>;
  return {
    agenda: o.agenda && typeof o.agenda === "object" ? o.agenda : {},
    projetos: Array.isArray(o.projetos) ? o.projetos : [],
    ficha: { ...VAZIO.ficha, ...(o.ficha ?? {}) },
  };
}

export type Resumo = { compromissosMarcados: number; anotacoes: number; projetos: number; fichaPreenchida: boolean };
export function resumir(d: Dados): Resumo {
  const v = Object.values(d.agenda);
  return {
    compromissosMarcados: v.filter((a) => a?.feito).length,
    anotacoes: v.filter((a) => a?.notas?.trim()).length,
    projetos: d.projetos.length,
    fichaPreenchida: Object.values(d.ficha).some((x) => String(x).trim()),
  };
}

/** Valida um backup: lança erro com mensagem em linguagem simples. */
export function validarBackup(texto: string): Dados {
  let x: unknown;
  try { x = JSON.parse(texto); } catch { throw new Error("O arquivo não é um JSON válido. Use um backup exportado por este site."); }
  if (!x || typeof x !== "object" || Array.isArray(x)) throw new Error("O arquivo não tem o formato de backup do Observatório.");
  const o = x as Record<string, unknown>;
  if (!("agenda" in o) && !("projetos" in o) && !("ficha" in o)) throw new Error("O arquivo não contém agenda, projetos nem ficha.");
  if ("projetos" in o && !Array.isArray(o["projetos"])) throw new Error("A lista de projetos do arquivo está corrompida.");
  const d = normalizar(o);
  d.projetos = d.projetos.filter((p) => p && typeof p === "object" && typeof p.nome === "string").map((p) => ({ ...p, id: String(p.id || Math.random()) }));
  return d;
}

const listeners = new Set<(d: Dados) => void>();

export function useDados() {
  const [dados, setDados] = useState<Dados>(VAZIO);
  useEffect(() => {
    const bruto = localStorage.getItem(STORE_KEY);
    try { setDados(normalizar(JSON.parse(bruto || "{}"))); }
    catch { if (bruto) localStorage.setItem(`${STORE_KEY}-recuperar-${Date.now()}`, bruto); /* guarda cópia do dado ilegível em vez de apagar */ }
    listeners.add(setDados);
    return () => { listeners.delete(setDados); };
  }, []);
  const salvar = useCallback((fn: (d: Dados) => Dados) => {
    setDados((prev) => {
      const next = fn(prev);
      try { localStorage.setItem(STORE_KEY, JSON.stringify(next)); }
      catch { alert("Não foi possível gravar no aparelho (memória cheia ou navegação privada). Exporte um backup agora."); }
      listeners.forEach((l) => l !== setDados && l(next));
      return next;
    });
  }, []);
  return { dados, salvar };
}

export const dataArquivo = () => new Date().toISOString().slice(0, 10);
export function baixar(nome: string, conteudo: string, tipo: string) {
  const url = URL.createObjectURL(new Blob([conteudo], { type: tipo }));
  const a = document.createElement("a");
  a.href = url; a.download = nome; document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

export function projetosCSV(p: Projeto[]) {
  const cols: (keyof Projeto)[] = ["nome","instrumento","ano","bairroProponente","localRealizacao","linguagem","previsto","contratado","empenhado","pago","publico","fonte","dataFonte"];
  const esc = (v: string) => `"${(v || "não verificado").replace(/"/g, '""')}"`;
  return [cols.join(";"), ...p.map((r) => cols.map((c) => esc(r[c])).join(";"))].join("\n");
}
