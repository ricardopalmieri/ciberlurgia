// Dados iniciais verificados em 01/11/2026. Nunca inventar valores: ausência = "não verificado".
export const DATA_PESQUISA = "01/11/2026";

export type Fase =
  | "previsto" | "aprovado" | "habilitado" | "contratado" | "pago" | "concluído"
  | "em apuração" | "não verificado" | "publicado";

export type Fonte = { label: string; url: string; data?: string; primaria: boolean };

export type Tema =
  | "Sistema e Leis" | "Plano e Metas" | "Conselho e Conferências" | "Fundo e Orçamento"
  | "PNAB e Cultura Viva" | "Patrimônio e Equipamentos";

export type Registro = {
  id: string;
  tema: Tema;
  ano: number;
  titulo: string;
  resumo: string;
  valor?: string;
  fase: Fase;
  data?: string;
  fontes: Fonte[];
  aviso?: string;
};

export const F = {
  plano: { label: "Plano Municipal de Cultura (PDF integral, Prefeitura)", url: "https://www.guarulhos.sp.gov.br/sites/default/files/2021-04/Plano_Municipal_de_Cultura%20%281%29.pdf", data: "abr/2021", primaria: true },
  obs: { label: "Observatório oficial – publicações técnicas e institucionais", url: "https://observatorio.guarulhos.sp.gov.br/content/publica%C3%A7%C3%B5es-t%C3%A9cnicas-e-institucionais", primaria: true },
  diario: { label: "Diário Oficial do Município de Guarulhos", url: "https://diariooficial.guarulhos.sp.gov.br", primaria: true },
  escCmpc: { label: "Transcrição do Diário Oficial 22/05/2026 (Escavador)", url: "https://www.escavador.com/diarios/6277358/DOMGRU-SP/legal/2026-05-22?page=14", data: "22/05/2026", primaria: false },
  lupa: { label: "Lupa Municipal – Cultura Guarulhos (dados TCE-SP, função 13)", url: "https://lupamunicipal.com/sp/guarulhos/secretarias/cultura/", data: "consultado 01/11/2026", primaria: false },
  escPar: { label: "Transcrição do Diário Oficial 27/01/2026 – PAR PNAB (Escavador)", url: "https://www.escavador.com/diarios/6218899/DOMGRU-SP/legal/2026-01-27?page=5", data: "27/01/2026", primaria: false },
  ed006: { label: "Edital 006/2026 – Mapa da Cultura / culteditais (MinC)", url: "https://culteditais.cultura.gov.br/oportunidade/9755", primaria: true },
  ed008: { label: "Edital 008/2026 republicado – Diário Oficial 24/07/2026 (Escavador)", url: "https://www.escavador.com/diarios/8949301/DOMGRU-SP/legal/2026-07-24?page=16", data: "24/07/2026", primaria: false },
  portalPnab: { label: "Portal de editais PNAB – Prefeitura de Guarulhos", url: "https://www.guarulhos.sp.gov.br/editaispnab", primaria: true },
  lpg: { label: "Mapeamento LPG Guarulhos 2023 (PDF)", url: "https://www.guarulhos.sp.gov.br/sites/default/files/2023-04/Mapeamento%20LPG%20Guarulhos-SP.pdf", data: "abr/2023", primaria: true },
  agenda: { label: "Agenda Espaço – agendamento de equipamentos", url: "https://agendaespaco.guarulhos.sp.gov.br", primaria: true },
} satisfies Record<string, Fonte>;

export const REGISTROS: Registro[] = [
  { id: "lei-7409", tema: "Sistema e Leis", ano: 2015, titulo: "Lei 7.409/2015 – Sistema Municipal de Cultura", resumo: "Cria o Sistema Municipal de Cultura de Guarulhos, que organiza conselho, plano, fundo e conferências.", fase: "publicado", data: "2015", fontes: [F.diario], aviso: "Texto integral da lei a anexar com link direto." },
  { id: "lei-7834", tema: "Sistema e Leis", ano: 2020, titulo: "Lei 7.834/2020 – Plano Municipal de Cultura (10 anos)", resumo: "Plano decenal com 4 eixos, 14 metas e 57 ações.", fase: "publicado", data: "06/07/2020", fontes: [F.plano, F.obs] },
  { id: "lei-6541", tema: "Sistema e Leis", ano: 2009, titulo: "Lei 6.541/2009 (alterada pela Lei 7.471/2016) – CMPC", resumo: "Conselho Municipal de Política Cultural paritário, consultivo, deliberativo e normativo, com participação da sociedade.", fase: "publicado", data: "2009 / 2016", fontes: [F.diario] },
  { id: "lei-5947", tema: "Sistema e Leis", ano: 2003, titulo: "Lei 5.947/2003 – FUNCULTURA", resumo: "Cria o Fundo Municipal de Cultura (FUNCULTURA). Não confundir com o 'Fundo Municipal de Política Cultural' citado no Plano.", fase: "publicado", data: "2003", fontes: [F.diario] },
  { id: "conf-9", tema: "Conselho e Conferências", ano: 2026, titulo: "9ª Conferência Municipal de Cultura", resumo: "Realizada no CEU Ponte Alta. Tema: “Guarulhos: Democracia e Direito à Cultura”. Relatório final e propostas aprovadas: não verificado.", fase: "concluído", data: "11/04/2026", fontes: [F.diario] },
  { id: "mesa-cmpc", tema: "Conselho e Conferências", ano: 2026, titulo: "Mesa diretora do CMPC – Resolução 001/2026", resumo: "Eleita em 19/05/2026. Presidente: Melissa Pires Gomes; vice: Vagner Lopes Roman Junior; secretária-geral: Fabiana Mayumi Takahashi; 2º secretário: Henrique Geraldes de Abreu.", fase: "publicado", data: "22/05/2026", fontes: [F.escCmpc, F.diario], aviso: "Composição publicada em 22/05/2026 — requer atualização." },
  { id: "lupa-2025", tema: "Fundo e Orçamento", ano: 2025, titulo: "Despesa função 13 – Cultura (exercício 2025)", resumo: "R$ 10.818.777 comprometidos (empenhados) e R$ 8.963.947 pagos, segundo dados do TCE-SP organizados pela Lupa Municipal.", valor: "R$ 8.963.947 pagos", fase: "pago", data: "exercício 2025", fontes: [F.lupa], aviso: "Fonte SECUNDÁRIA. Não equivale ao orçamento da Secretaria nem à verba PNAB." },
  { id: "meta2-15", tema: "Fundo e Orçamento", ano: 2020, titulo: "Meta 2 – orçamento próprio da Cultura até 1,5%", resumo: "O Plano prevê aumento progressivo do orçamento próprio da Cultura até 1,5%, condicionado à disponibilidade. Cumprimento: não verificado.", fase: "previsto", data: "06/07/2020", fontes: [F.plano] },
  { id: "pnab-c1", tema: "PNAB e Cultura Viva", ano: 2024, titulo: "PNAB ciclo 1 – Plano de Ação inicial", resumo: "Valor do plano de ação inicial.", valor: "R$ 7.828.900,46", fase: "previsto", fontes: [F.escPar, F.portalPnab], aviso: "Data exata do plano inicial: conferir." },
  { id: "pnab-c1-rev", tema: "PNAB e Cultura Viva", ano: 2025, titulo: "PNAB ciclo 1 – PAR revisado", resumo: "Inclui rendimentos até maio/2025.", valor: "R$ 8.657.871,36", fase: "previsto", data: "mai/2025", fontes: [F.escPar] },
  { id: "pnab-plur", tema: "PNAB e Cultura Viva", ano: 2026, titulo: "PNAB ciclo contínuo – total plurianual", resumo: "PAR enviado em jun/2025 e publicado em jan/2026.", valor: "R$ 31.195.210,40", fase: "previsto", data: "27/01/2026", fontes: [F.escPar] },
  { id: "pnab-ex1", tema: "PNAB e Cultura Viva", ano: 2026, titulo: "PNAB ciclo contínuo – PAR exercício 1", resumo: "Valor planejado para o exercício 1 do ciclo contínuo.", valor: "R$ 7.798.802,60", fase: "previsto", data: "27/01/2026", fontes: [F.escPar] },
  { id: "pnab-pontos", tema: "PNAB e Cultura Viva", ano: 2026, titulo: "Pontos de Cultura (Cultura Viva) – exercício 1", resumo: "Valor PLANEJADO. Não há comprovação de pagamento.", valor: "R$ 2.000.000,00", fase: "previsto", data: "27/01/2026", fontes: [F.escPar], aviso: "Planejado não é pago." },
  { id: "ed-006", tema: "PNAB e Cultura Viva", ano: 2026, titulo: "Edital 006/2026 – oficinas nas periferias", resumo: "Inscrições encerradas. Resultado, contratações e pagamentos: não verificados.", valor: "R$ 300.000,00", fase: "previsto", fontes: [F.ed006] },
  { id: "ed-008", tema: "PNAB e Cultura Viva", ano: 2026, titulo: "Edital 008/2026 – Movimento Cultural", resumo: "Até 2 projetos. R$ 3,2 milhões PNAB + R$ 846.335,28 recursos próprios. Republicado em julho.", valor: "R$ 4.046.335,28", fase: "previsto", data: "24/07/2026", fontes: [F.ed008, F.portalPnab] },
  { id: "lpg-2023", tema: "Patrimônio e Equipamentos", ano: 2023, titulo: "Mapeamento Lei Paulo Gustavo 2023", resumo: "Documento público de mapeamento cultural da LPG em Guarulhos.", fase: "publicado", data: "abr/2023", fontes: [F.lpg] },
];

export const EIXOS = [
  { n: "I", nome: "Gestão política" },
  { n: "II", nome: "Infraestrutura" },
  { n: "III", nome: "Diversidade, fomento e produção" },
  { n: "IV", nome: "Patrimônio e memória" },
];

// Títulos confirmados apenas para 1, 2, 3, 5, 10, 13, 14. Eixo informado só quando coerente com o título; demais: conferir.
export type Meta = { n: number; titulo: string | null; eixo: string | null };
const T: Record<number, [string, string]> = {
  1: ["Quadro de pessoal da Secretaria de Cultura", "I"],
  2: ["Sistema municipal de financiamento à cultura", "I"],
  3: ["Sistema municipal de informações e indicadores culturais", "I"],
  5: ["Equipamentos públicos de cultura reformados", "II"],
  10: ["Circuito Cultural Guarulhense", "III"],
  13: ["Espaços museológicos", "IV"],
  14: ["Gestão e difusão de acervos", "IV"],
};
export const METAS: Meta[] = Array.from({ length: 14 }, (_, i) => {
  const n = i + 1;
  return { n, titulo: T[n]?.[0] ?? null, eixo: T[n]?.[1] ?? null };
});

export const BAIRROS = [
  "Pimentas", "Bonsucesso", "Cumbica", "São João", "Taboão", "Cabuçu", "Cecap", "Centro",
  "Vila Galvão", "Presidente Dutra", "Ponte Alta", "Jardim Presidente Dutra", "Lavras", "Vila Rio", "Outro",
];

export const EQUIPAMENTOS = [
  { nome: "Teatro Padre Bento", tipo: "Teatro" },
  { nome: "Arquivo Histórico Municipal", tipo: "Memória e acervo" },
  { nome: "Biblioteca Monteiro Lobato", tipo: "Biblioteca" },
  { nome: "Centro de Cultura Popular Carpição", tipo: "Cultura popular" },
  { nome: "Casa de Cultura Popular São Rafael", tipo: "Cultura popular" },
];

export const AGENDA = [
  { id: 1, titulo: "Lei do Plano acessível", pergunta: "Onde está publicado o texto integral e atualizado da Lei 7.834/2020, em formato acessível?", doc: "Lei 7.834/2020 integral, anexos e versão em linguagem simples." },
  { id: 2, titulo: "Relatório das 14 metas e 57 ações", pergunta: "Qual a situação comprovada de cada meta e ação do Plano?", doc: "Relatório de monitoramento com indicador, linha de base, evidência e data por meta." },
  { id: 3, titulo: "Atas e calendário do CMPC", pergunta: "Quando o Conselho se reúne e onde estão as atas e resoluções?", doc: "Calendário anual, atas, listas de presença e resoluções do CMPC." },
  { id: 4, titulo: "Prestação de contas dos Fundos", pergunta: "Quanto entrou e saiu do FUNCULTURA e quem compõe o conselho diretor?", doc: "Balancetes, atas e deliberações do conselho diretor, relatórios anuais dos Fundos." },
  { id: 5, titulo: "PPA, LDO e LOA populares", pergunta: "Quanto está previsto para a Cultura em cada programa e ação orçamentária?", doc: "PPA, LDO e LOA da função 13 – Cultura, em versão cidadã." },
  { id: 6, titulo: "Rastrear empenho → liquidação → pagamento", pergunta: "Cada edital/fomento foi empenhado, liquidado e pago? Em que datas e valores?", doc: "Notas de empenho, liquidação e ordens de pagamento por projeto." },
  { id: 7, titulo: "Projetos e atividades por bairro", pergunta: "Em quais bairros moram os proponentes e onde as ações aconteceram?", doc: "Base aberta de projetos com bairro do proponente e local de realização." },
  { id: 8, titulo: "Ações afirmativas e acessibilidade", pergunta: "Como foram cumpridas cotas e medidas de acessibilidade?", doc: "Dados agregados (raça/cor, gênero, faixa etária, PCD) com metodologia." },
  { id: 9, titulo: "Patrimônio, memória e equipamentos", pergunta: "Qual a situação, programação e uso real de cada equipamento e acervo?", doc: "Inventário de bens, relatório de uso e manutenção dos equipamentos." },
  { id: 10, titulo: "Audiência pública com devolutiva", pergunta: "Haverá audiência pública periódica com resposta às demandas apresentadas?", doc: "Calendário de audiências e relatório de devolutiva." },
];

export const AULA = [
  { min: 15, tema: "Direitos culturais e Sistema Nacional de Cultura (SNC)" },
  { min: 20, tema: "Plano Municipal e suas metas" },
  { min: 25, tema: "Orçamento e Fundo: previsto x empenhado x pago" },
  { min: 30, tema: "Grupos por território: o que chega ao meu bairro?" },
  { min: 20, tema: "Plenária da Agenda Cidadã" },
  { min: 10, tema: "Compromissos e próximos passos" },
];

export const GLOSSARIO: { termo: string; def: string }[] = [
  { termo: "Dotação", def: "Valor autorizado no orçamento para uma despesa. É uma previsão, não dinheiro gasto." },
  { termo: "Empenho", def: "Primeiro passo do gasto: a prefeitura reserva o dinheiro para um fornecedor ou projeto." },
  { termo: "Liquidação", def: "Confirmação de que o serviço foi entregue e o pagamento pode ser feito." },
  { termo: "Pagamento", def: "Quando o dinheiro sai de fato da conta pública para quem executou." },
  { termo: "LOA", def: "Lei Orçamentária Anual: diz quanto a cidade pode gastar em cada área no ano." },
  { termo: "LDO", def: "Lei de Diretrizes Orçamentárias: define prioridades para montar a LOA." },
  { termo: "PPA", def: "Plano Plurianual: planejamento do governo para 4 anos." },
  { termo: "PNAB", def: "Política Nacional Aldir Blanc: repasse federal contínuo para a cultura de estados e municípios." },
  { termo: "PAR", def: "Plano Anual de Aplicação de Recursos da PNAB, enviado pelo município ao Ministério da Cultura." },
  { termo: "LPG", def: "Lei Paulo Gustavo: repasse federal emergencial para a cultura (2023)." },
  { termo: "Cultura Viva", def: "Política nacional que reconhece e apoia Pontos e Pontões de Cultura." },
  { termo: "Ponto de Cultura", def: "Grupo ou coletivo cultural reconhecido pela Política Cultura Viva." },
  { termo: "SNC", def: "Sistema Nacional de Cultura: acordo entre União, estados e municípios com conselho, plano e fundo (CPF da cultura)." },
  { termo: "CMPC", def: "Conselho Municipal de Política Cultural: governo e sociedade decidem e fiscalizam juntos." },
  { termo: "Paritário", def: "Com o mesmo número de representantes do governo e da sociedade civil." },
  { termo: "FUNCULTURA", def: "Fundo Municipal de Cultura criado pela Lei 5.947/2003." },
  { termo: "Edital", def: "Chamada pública com regras para inscrever e selecionar projetos." },
  { termo: "Meta", def: "Resultado que o Plano promete alcançar, idealmente medido por um indicador." },
  { termo: "Indicador", def: "Número ou sinal que mostra se uma meta avançou. Sem indicador publicado, não há como medir." },
  { termo: "Conciliação", def: "Conferir se o valor anunciado bate com empenho, liquidação, pagamento e entrega comprovada." },
];

// Indicador de completude documental (metodologia pública). Não mede qualidade de governo.
export const CRITERIOS = [
  "Tem fonte com link clicável",
  "Tem data do documento",
  "Tem fase declarada (previsto, pago etc.)",
  "Tem ao menos uma fonte primária (oficial)",
];
export function completude(r: Registro) {
  const c = [
    r.fontes.length > 0,
    !!r.data,
    r.fase !== "não verificado",
    r.fontes.some((f) => f.primaria),
  ];
  const pontos = c.filter(Boolean).length;
  const cor = pontos === 4 ? "verde" : pontos >= 2 ? "amarelo" : "vermelho";
  return { pontos, cor, criterios: c } as const;
}
