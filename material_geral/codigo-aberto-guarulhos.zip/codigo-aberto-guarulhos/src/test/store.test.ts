import { describe, expect, it } from "vitest";
import { validarBackup, resumir } from "@/lib/store";

describe("backup", () => {
  it("rejeita JSON inválido", () => expect(() => validarBackup("{x")).toThrow());
  it("rejeita arquivo sem dados do observatório", () => expect(() => validarBackup('{"a":1}')).toThrow());
  it("rejeita projetos corrompidos", () => expect(() => validarBackup('{"projetos":"x"}')).toThrow());
  it("aceita backup e resume conteúdo", () => {
    const d = validarBackup(JSON.stringify({ agenda: { 1: { feito: true, notas: "ok" } }, projetos: [{ id: "1", nome: "P" }] }));
    expect(resumir(d)).toEqual({ compromissosMarcados: 1, anotacoes: 1, projetos: 1, fichaPreenchida: false });
  });
});
