#!/usr/bin/env python3
"""Gera public/downloads/codigo-aberto-guarulhos.zip de forma reprodutível.
Uso: python3 scripts/gerar_pacote.py   (rodar na raiz do projeto)
Mesmo conteúdo => mesmo ZIP (datas fixas, ordem alfabética, sem dados do usuário)."""
import hashlib, re, sys, zipfile
from pathlib import Path

RAIZ = Path(__file__).resolve().parent.parent
SAIDA = RAIZ / "public/downloads/codigo-aberto-guarulhos.zip"
INCLUIR_DIRS = ["src", "public", "scripts"]
INCLUIR_ARQ = ["package.json", "bun.lock", "bunfig.toml", "tsconfig.json", "vite.config.ts", "vitest.config.ts",
               "eslint.config.js", "components.json", ".prettierrc", ".prettierignore", ".gitignore",
               "README.md", "LICENSE", "LICENCA-DADOS.md", "COMO-CONTRIBUIR.md", "FONTES-E-LIMITES-DOS-DADOS.md"]
EXCLUIR = re.compile(r"(^|/)(\.git|node_modules|dist|\.output|\.wrangler|\.lovable|\.workspace|downloads)(/|$)|(^|/)\.env|\.dev\.vars|\.local$|\.log$|\.zip$")
SEGREDOS = [
    ("CPF", re.compile(r"\b\d{3}\.\d{3}\.\d{3}-\d{2}\b")),
    ("CNPJ", re.compile(r"\b\d{2}\.\d{3}\.\d{3}/\d{4}-\d{2}\b")),
    ("chave privada", re.compile(r"-----BEGIN [A-Z ]*PRIVATE KEY-----")),
    ("token", re.compile(r"\b(sk_live_|sk-[A-Za-z0-9]{20,}|sb_secret_|ghp_[A-Za-z0-9]{20,}|AKIA[0-9A-Z]{16})")),
    ("e-mail", re.compile(r"[\w.+-]+@[\w-]+\.(com|br|org|net)(\.br)?\b")),
    ("telefone", re.compile(r"\(?\b\d{2}\)?\s?9?\d{4}-\d{4}\b")),
]
FIXA = (2026, 1, 1, 0, 0, 0)

def arquivos():
    out = [RAIZ / a for a in INCLUIR_ARQ if (RAIZ / a).is_file()]
    for d in INCLUIR_DIRS:
        out += [p for p in (RAIZ / d).rglob("*") if p.is_file()]
    rel = sorted({p.relative_to(RAIZ).as_posix() for p in out})
    return [r for r in rel if not EXCLUIR.search(r)]

def verificar(rel, dados):
    if rel.endswith((".ico", ".png", ".jpg", ".lock")) or rel == "scripts/gerar_pacote.py": return []  # o próprio gerador contém os padrões
    txt = dados.decode("utf-8", "ignore")
    achados = [n for n, rx in SEGREDOS if rx.search(txt)]
    # e-mails de exemplo/licença permitidos
    if achados == ["e-mail"] and not re.search(r"[\w.+-]+@(?!example)[\w-]+\.(com|br|org)", txt.replace("noreply@", "")): return []
    return achados

def main():
    lista, problemas = arquivos(), []
    SAIDA.parent.mkdir(parents=True, exist_ok=True)
    tmp = SAIDA.with_suffix(".tmp")
    with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for rel in lista:
            dados = (RAIZ / rel).read_bytes()
            if (a := verificar(rel, dados)): problemas.append(f"{rel}: {', '.join(a)}")
            info = zipfile.ZipInfo(f"codigo-aberto-guarulhos/{rel}", FIXA)
            info.external_attr = 0o644 << 16; info.compress_type = zipfile.ZIP_DEFLATED
            z.writestr(info, dados)
    if problemas:
        tmp.unlink(); print("BLOQUEADO – possíveis dados sensíveis:\n" + "\n".join(problemas)); sys.exit(1)
    tmp.replace(SAIDA)
    print(f"{len(lista)} arquivos · {SAIDA.stat().st_size} bytes · sha256 {hashlib.sha256(SAIDA.read_bytes()).hexdigest()}")

if __name__ == "__main__":
    main()
