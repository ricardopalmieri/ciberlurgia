#!/usr/bin/env python3
"""Confere integridade e conteúdo do ZIP. Uso: python3 scripts/testar_pacote.py"""
import re, sys, zipfile
from pathlib import Path
Z = Path(__file__).resolve().parent.parent / "public/downloads/codigo-aberto-guarulhos.zip"
P = "codigo-aberto-guarulhos/"
OBRIG = ["LICENSE", "LICENCA-DADOS.md", "COMO-CONTRIBUIR.md", "FONTES-E-LIMITES-DOS-DADOS.md", "README.md",
         "package.json", "bun.lock", "src/lib/data.ts", "src/routes/codigo-aberto.tsx", "scripts/gerar_pacote.py"]
erros = []
with zipfile.ZipFile(Z) as z:
    if (r := z.testzip()): erros.append(f"arquivo corrompido: {r}")
    nomes = z.namelist()
    for o in OBRIG:
        if P + o not in nomes: erros.append(f"faltando: {o}")
    for n in nomes:
        if not n.startswith(P): erros.append(f"fora da pasta: {n}")
        if re.search(r"(^|/)(\.env|\.git/|node_modules/|\.lovable/|\.dev\.vars)|\.zip$", n): erros.append(f"proibido: {n}")
    if "MIT License" not in z.read(P + "LICENSE").decode(): erros.append("LICENSE não é MIT")
    if "CC BY 4.0" not in z.read(P + "LICENCA-DADOS.md").decode(): erros.append("sem CC BY 4.0")
print("\n".join(erros) or f"OK: {len(nomes)} arquivos íntegros")
sys.exit(1 if erros else 0)
