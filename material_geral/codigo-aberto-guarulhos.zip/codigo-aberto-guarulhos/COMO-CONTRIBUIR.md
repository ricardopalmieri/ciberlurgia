# Como contribuir

1. **Achou um erro ou documento novo?** Anote: o que está errado, o link oficial e a data do documento.
2. **Na sua cópia:** os dados ficam em `src/lib/data.ts`. Cada fato precisa de `fontes` (link) e `data`. Sem documento, escreva "não verificado" — nunca invente valor.
3. **Regras:** previsto ≠ empenhado ≠ pago. Endereço da entidade proponente não prova onde a ação aconteceu. Cores = completude do documento, não nota para a gestão.
4. **Não inclua:** CPF, CNPJ de pessoa física, telefone, e-mail ou endereço particular, senhas, PDFs de terceiros sem permissão.
5. Rode `bun run test` e `python3 scripts/gerar_pacote.py` antes de compartilhar.

Alterar a sua cópia **não** muda o site original. Para sugerir mudanças no original, envie sua proposta e as fontes para quem mantém o observatório.
